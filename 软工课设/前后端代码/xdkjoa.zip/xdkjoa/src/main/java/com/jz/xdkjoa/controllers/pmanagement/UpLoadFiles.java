package com.jz.xdkjoa.controllers.pmanagement;


import org.springframework.stereotype.Controller;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

@CrossOrigin
@RestController
@RequestMapping("/upload")
public class UpLoadFiles {
    //MultipartFile  接收二进制
    //HttpServletRequest  request对象
    @PostMapping("saveimage")
    public String upload(MultipartFile file,
                         HttpServletRequest req){

        //req.getServletContext()  获取服务器地址
        String realPath=req.getServletContext().getRealPath("/upload");
        //realPath="F:\\软工课设\\XDKJ_OA\\xdkj_oa\\src\\assets\\img";
        realPath="D:\\学习材料\\2021-6-燕大实训\\小岛办公自动化资料\\汇总代码\\最新项目\\xdkj_oa\\src\\assets\\img";
        try {
            File path=new File(realPath);
            if(!path.exists())
                path.mkdir();//新建目录

            String str=new Date().getTime()+""; //

            String originName=file.getOriginalFilename();//被上传的文件原始文件名 a.jpg

            String ext=originName.substring(originName.lastIndexOf("."));//文件后缀名
            String newName=str+ext;
            System.out.println(realPath+"/"+newName);
            file.transferTo(new File(realPath,newName));//文件上传
            return newName;
        } catch (IOException e) {
            e.printStackTrace();
            return "上传失败";
        }
    }
}
