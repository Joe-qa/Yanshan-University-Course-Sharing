﻿using System;
using System.Drawing;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace client
{
    public partial class Form1 : Form
    {
        int[] area = { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        int click = 0;
        bool flag = true;
        public void draw()
        {
            for (int i = 0; i < 9; i++)
            {
                area[i] = 0;
            }
            int iHeight = map.Height;
            int iWidth = map.Width;
            Random rand = new Random(); //随机器
            int maxn = 200; 
            Bitmap bmp = new Bitmap(map.Width, map.Height);
            Graphics g = Graphics.FromImage(bmp); //建立Graphics对象
            Pen p = new Pen(Color.Red); //---创建画笔
            for (int i = 0; i < maxn; i++)
            {
                int x = rand.Next(iWidth); //随机生成X轴上的点
                int y = rand.Next(iHeight); //随机生成Y轴上的点
                cal(x, y);
                g.FillEllipse(Brushes.Red, x, y, 5, 5); ; //在画布坐标(x, y)上画一个大小只有1的圆（就是点）
            }
            g.Save();
            g.Dispose(); //把Graphics释放掉
            map.Image = bmp;
        }

        public void cal(int x, int y)
        {
            if (x <= this.map.Width / 3 && x >= 0 && y >= 0 && y <= this.map.Height / 3)
                area[0]++;
            else if (x > this.map.Width / 3 && x <= (this.map.Width * 2 / 3) && y >= 0 && y <= this.map.Height / 3)
                area[1]++;
            else if (x > (this.map.Width * 2 / 3) && x <= this.map.Width && y >= 0 && y <= this.map.Height / 3)
                area[2]++;
            else if (x <= this.map.Width / 3 && x >= 0 && y > this.map.Height / 3 && y <= (this.map.Height * 2 / 3))
                area[3]++;
            else if (x > this.map.Width / 3 && x <= (this.map.Width * 2 / 3) && y > this.map.Height / 3 && y <= (this.map.Height * 2 / 3))
                area[4]++;
            else if (x > (this.map.Width * 2 / 3) && x <= this.map.Width && y > this.map.Height / 3 && y <= (this.map.Height * 2 / 3))
                area[5]++;
            else if (x <= this.map.Width / 3 && x >= 0 && y > (this.map.Height * 2 / 3) && y <= this.map.Height)
                area[6]++;
            else if (x > this.map.Width / 3 && x <= (this.map.Width * 2 / 3) && y > (this.map.Height * 2 / 3) && y <= this.map.Height)
                area[7]++;
            else if (x > (this.map.Width * 2 / 3) && x <= this.map.Width && y > (this.map.Height * 2 / 3) && y <= this.map.Height)
                area[8]++;
        }

        public Form1()
        {
            InitializeComponent();
        }
        Socket client = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        private void Form1_Load(object sender, EventArgs e)
        {
            map.Width = 900;
            map.Height = 600;
            draw();
            plane.BackColor = Color.Transparent;
            plane.Parent = map;
            dia.Parent = plane;
            this.plane.Left = 50;
            this.plane.Top = 25;
            Control.CheckForIllegalCrossThreadCalls = false;
            map.Controls.Add(plane);
        }
        public void sendMsg(int index)
        {
            string msg = "";
            msg += "第" + index.ToString() + "个区域的人数：" + area[index - 1] + "\n";
            if (client != null)
            {
                try
                {
                    byte[] buffer = Encoding.UTF8.GetBytes(msg);
                    client.Send(buffer);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
        }
        private void map_Click(object sender, EventArgs e)
        {
            click++;
            if (click == 1)
            {
               
                timer1.Start();
                timer2.Start();
            }
        }

        void ReceiveMsg()
        {
            while (true)
            {
                try
                {
                    byte[] buffer = new byte[1024 * 1024];
                    int n = client.Receive(buffer);
                    string s = Encoding.UTF8.GetString(buffer, 0, n);
                    char num ;
                    num = s[0];
                   
                    s = s.Substring(2);
                    dia.Text =s ;
                    if (num == '1')
                    {
                        this.plane.Left = 50;
                        this.plane.Top = 25;
                    }
                    else if (num == '2')
                    {
                        this.plane.Left = 350;
                        this.plane.Top = 25;
                    }
                    else if (num =='3' )
                    {
                        this.plane.Left = 650;
                        this.plane.Top = 25;
                    }
                    else if (num == '4')
                    {
                        this.plane.Left = 50;
                        this.plane.Top = 225;
                    }
                    else if (num == '5')
                    {
                        this.plane.Left = 350;
                        this.plane.Top = 225;
                    }
                    else if (num == '6')
                    {
                        this.plane.Left = 650;
                        this.plane.Top = 225;
                    }
                    else if (num == '7')
                    {
                        this.plane.Left = 50;
                        this.plane.Top = 425;
                    }
                    else if (num == '8')
                    {
                        this.plane.Left = 350;
                        this.plane.Top = 425;
                    }
                    else if (num == '9')
                    {
                        this.plane.Left = 650;
                        this.plane.Top = 425;
                    }
                    lastnum = int.Parse(num.ToString());
                   
                    flag = false;
                 
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    break;
                }
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Enabled = false;
            draw();
            timer1.Enabled = true;
        }
        int lastnum=1;
        public void draw_plane()
        {
            int num = Judge_area(plane.Left, plane.Top);
            if (!flag)
            {
                flag = true;
                timer2.Interval = 2000;
            }
            else
            {
                dia.Text = "";
                if (lastnum != num)
                {
                    timer2.Interval = 2000;
                    sendMsg(lastnum);
                }
                else
                {
                    timer2.Interval = 100;
                }
            }

            if (num == 1 || num == 2 || num == 7 || num == 8)
                this.plane.Left += 10;
            else if (num == 3 || num == 4)
                this.plane.Top += 10;
            else if (num == 5 || num == 6)
                this.plane.Left -= 10;
            else if (num == 9)
            {
                if(this.plane.Left==650)
                {
                    this.plane.Left += 10;
                }
                else
                {
                    this.plane.Left = 50;
                    this.plane.Top = 25;
                }
            }
           
            lastnum = num;
            
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2.Enabled = false;
            draw_plane();
            timer2.Enabled = true;
        }
        public int Judge_area(int x, int y)
        {
           
            if (this.plane.Left >= 50 && this.plane.Left < 350 && this.plane.Top >= 25 && this.plane.Top < 225)
            {
               
                return 1;
            }
            else if (this.plane.Left >= 350 && this.plane.Left < 650 && this.plane.Top >= 25 && this.plane.Top < 225)
            {
               
                return 2;
            }
            else if (this.plane.Left >= 650 && this.plane.Top >= 25 && this.plane.Top < 225)
            {
              
                return 3;
            }
            else if (this.plane.Left <= 50 && this.plane.Top >= 225 && this.plane.Top < 425)
            {
              
                return 4;
            }
            else if (this.plane.Left <= 350 && this.plane.Left > 50 && this.plane.Top >= 225 && this.plane.Top < 425)
            {
             
                return 5;
            }
            else if (this.plane.Left <= 650 && this.plane.Left > 350 && this.plane.Top >= 225 && this.plane.Top < 425)
            {
                
                return 6;
            }
            else if (this.plane.Left >= 50 && this.plane.Left < 350 && this.plane.Top >= 425 && this.plane.Top < 625)
            {
                return 7;
            }
            else if (this.plane.Left >= 350 && this.plane.Left < 650 && this.plane.Top >= 425 && this.plane.Top < 625)
            {
               
                return 8;
            }
            else if (this.plane.Left >= 650 && this.plane.Top >= 425 && this.plane.Top < 625)
            {
               
                return 9;
            }
            else return 1;

        }

        private void btn_Connection_Click(object sender, EventArgs e)
        {
            IPAddress ip = IPAddress.Parse("127.0.0.1");
            IPEndPoint point = new IPEndPoint(ip, int.Parse("8090"));
            try
            {
                client.Connect(point);
                Thread th = new Thread(ReceiveMsg);
                th.IsBackground = true;
                th.Start();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private void btn_stop_Click(object sender, EventArgs e)
        {
            if (btn_stop.Text == "暂停飞行")
            {
                timer1.Stop();
                timer2.Stop();
                btn_stop.Text = "继续飞行";
            }
            else
            {
                timer1.Start();
                timer2.Start();
                btn_stop.Text = "暂停飞行";
            }
        }
    }
}
