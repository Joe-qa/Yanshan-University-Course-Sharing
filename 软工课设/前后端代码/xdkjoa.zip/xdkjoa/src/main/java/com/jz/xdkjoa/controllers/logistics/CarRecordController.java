package com.jz.xdkjoa.controllers.logistics;

import com.jz.xdkjoa.pojo.logistics.CarRecord;
import com.jz.xdkjoa.service.logistics.CarMsgService;
import com.jz.xdkjoa.service.logistics.CarRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @Author zxq
 * @Date 2021-6-19 15:32
 */
@CrossOrigin
@RestController
@RequestMapping("/CarRecord")
public class CarRecordController {
    @Autowired
    CarRecordService carRecordService;
    @Autowired
    CarMsgService carMsgService;
    @PostMapping("addCarRecord")
    public String addCarRecord(@RequestBody CarRecord carRecord){
        System.out.println(carRecord.getCar_num());
        carRecordService.addCarRecordBiz(carRecord);
        carMsgService.updateCarStateBiz(carRecord.getCar_num());
        System.out.println("这是car_num呀");
        return "借车成功";
    }


    @GetMapping("delCarRecord")
    public String delCarRecord(Integer record_num){
        carRecordService.delCarRecordBiz(record_num);
        return "hello";
    }

    @GetMapping("showByCarNumRecord")
    public List showByCarNumRecord(@RequestParam String car_num){

        List<CarRecord> list=carRecordService.showByCarNumRecordBiz(car_num);
        for(CarRecord e:list){
            System.out.println(e.toString());
        }
        return list;
    }

    @GetMapping("showAllCarRecord")
    public List showAllCarRecord(@RequestParam String situation){
        List<CarRecord> list=carRecordService.showAllCarRecordBiz(situation);
        for(CarRecord e:list){
            System.out.println(e.toString());
        }
        return list;
    }

}
