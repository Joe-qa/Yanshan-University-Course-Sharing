package com.jz.xdkjoa.controllers.poffice;

import com.jz.xdkjoa.pojo.administration.BusinessCalendar;
import com.jz.xdkjoa.pojo.poffice.PersonalSchedule;
import com.jz.xdkjoa.service.poffice.PersonalScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.sql.Date;
import java.sql.SQLOutput;
import java.sql.Time;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/personalschedule")
public class PersonalScheduleController {

    @Autowired(required = false)
    PersonalScheduleService personalScheduleService;

    @GetMapping("showpersonalschedule")
    public List<PersonalSchedule> showPersonalSchedule(Integer job_num, String schedule_type) {
        List<PersonalSchedule> list=personalScheduleService.showPersonalScheduleBiz(job_num,schedule_type);
        return list;
    }

    @PostMapping("addpersonalschedule")
    public void addPersonalSchedule(@RequestBody PersonalSchedule personalSchedule)
    {
           System.out.println(personalSchedule);
            personalScheduleService.addPersonalScheduleBiz(personalSchedule);
            System.out.println("添加成功");

    }

    @PostMapping("updatepersonalschedule")
    public String updatePersonalSchedule(@RequestBody PersonalSchedule personalSchedule)
    {
        System.out.println(personalSchedule.toString());
        personalScheduleService.updatePersonalScheduleBiz(personalSchedule);

        return "0000";
    }

    @GetMapping("delpersonalschedule")
    public String delPersonalSchedule(@RequestParam Integer schedule_id )
    {
        personalScheduleService.delPersonalScheduleBiz(schedule_id);
        return "000";
    }

    @GetMapping("showbusinessschedule")
    public List<PersonalSchedule> showPersonalSchedule( Integer job_num) {
        List<PersonalSchedule> list=personalScheduleService.showBusinessScheduleBiz(job_num);
        return list;
    }

    @GetMapping("showdepartnum")
    public List<BusinessCalendar> showDepartNum(@RequestParam Integer job_num)
    {
        List <Integer> list = personalScheduleService.showDepartNumBiz(job_num);
        System.out.println(list);
        //System.out.println(list.get(1));
        List <BusinessCalendar> list1 = personalScheduleService.showBusinessCalendarBiz(list.get(0));
        return list1;
    }

}


