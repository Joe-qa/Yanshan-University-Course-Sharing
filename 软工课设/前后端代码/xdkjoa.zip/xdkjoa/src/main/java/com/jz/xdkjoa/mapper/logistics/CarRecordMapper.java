package com.jz.xdkjoa.mapper.logistics;

import com.jz.xdkjoa.pojo.logistics.CarRecord;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CarRecordMapper {
    /**
     * 添加借车记录
     * @param carrecord
     */
    void addCarRecord(CarRecord carrecord);

    /**
     * 删除借车信息
     * @param record_num
     */
    void delCarRecord(Integer record_num);

    /**
     * 通过车牌号查询车辆借车信息
     * @param car_num
     * @return
     */
    List<CarRecord>showByCarNumRecord(String car_num);

    /**
     * 通过状态查询所有借车信息
     * @return
     */
    List<CarRecord>showAllCarRecord(String situation);

}
