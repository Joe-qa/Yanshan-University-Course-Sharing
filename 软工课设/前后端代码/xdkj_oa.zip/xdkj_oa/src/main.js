// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import Vuex from 'vuex'
import App from './App'
import router from './router'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css'
import axios from 'axios'
import VueAxios from "vue-axios";
import Vue2OrgTree from 'vue-tree-color'
Vue.prototype.$axios=axios
Vue.use(Vue2OrgTree)
Vue.use(ElementUI)
Vue.use(VueAxios, axios)
Vue.use(Vuex)
Vue.config.productionTip = false
import FileSaver from 'file-saver'
import XLSX from 'xlsx'
Vue.prototype.$FileSaver = FileSaver  //设置全局
Vue.prototype.$XLSX = XLSX

import echarts from 'echarts'
Vue.prototype.$echarts=echarts;

router.beforeEach((to,from,next)=>{
	let isLogin=localStorage.getItem('isLogin');
	//注销
	if(to.path=='/logout'){
		window.localStorage.removeItem('isLogin')
		//跳转到登录页面
		next({path:'/login'})
	}else if(to.path=='/login'){
		if(isLogin!=null){
			//登录信息不为空，跳转到首页
			next({path:'/index'});
		}
		
	}
	else if(isLogin==null){
			//登录信息不为空，跳转到首页
			next({path:'/login'});
		
	}
	next();
})
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})


