package com.jz.xdkjoa.service.pmanagement;

import com.jz.xdkjoa.pojo.pmanagement.Staff;

import java.util.List;

public interface StaffService {
    void addStaffBiz(Staff staff);
    List<Staff> showStaffsBiz();
    Staff showStaffByIdBiz(Integer job_num);
    List<Staff> showStaffByNameBiz(String staff_name,Integer depart_num);
    void updateStaffBiz(Staff staff);
    void delStaffBiz(Integer job_num);
    List<Staff> showStaffByDeptBiz(String depart_name);
    List<Staff> validateStaff(String account);
    void saveImageBiz(String image,Integer job_num);
    List<Staff> findStaffByDepartmentBiz(Integer depart_num);
}
