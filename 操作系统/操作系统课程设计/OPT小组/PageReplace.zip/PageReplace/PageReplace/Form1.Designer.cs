﻿namespace PageReplace
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title3 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title4 = new System.Windows.Forms.DataVisualization.Charting.Title();
            this.label1 = new System.Windows.Forms.Label();
            this.AddressTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pagesTextbox = new System.Windows.Forms.TextBox();
            this.btnRandom = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.pictureBoxPagetable = new System.Windows.Forms.PictureBox();
            this.addressLowwerTextbox = new System.Windows.Forms.TextBox();
            this.addressUpperTextbox = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.noFast = new System.Windows.Forms.RadioButton();
            this.useFast = new System.Windows.Forms.RadioButton();
            this.LAnumTextbox = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.PagesizeNumTextbox = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.memblockTextbox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.pageNumTextbox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnFIFO = new System.Windows.Forms.Button();
            this.btnStopFIFO = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btncmd = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.btnStopALL = new System.Windows.Forms.Button();
            this.btnALL = new System.Windows.Forms.Button();
            this.btnStopOPT = new System.Windows.Forms.Button();
            this.btnOPT = new System.Windows.Forms.Button();
            this.btnStopLRU = new System.Windows.Forms.Button();
            this.btnLRU = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.labelFIFO = new System.Windows.Forms.Label();
            this.labelLRU = new System.Windows.Forms.Label();
            this.btnPage = new System.Windows.Forms.Button();
            this.labelOPT = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.FIFOLacklabel = new System.Windows.Forms.Label();
            this.lableFIFOsleep = new System.Windows.Forms.Label();
            this.LRULacklabel = new System.Windows.Forms.Label();
            this.lableLRUsleep = new System.Windows.Forms.Label();
            this.OPTLacklabel = new System.Windows.Forms.Label();
            this.lableOPTsleep = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBoxFIFO = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBoxLRU = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBoxOPT = new System.Windows.Forms.PictureBox();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPagetable)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxFIFO)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLRU)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOPT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(97, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "逻辑地址序列";
            // 
            // AddressTextBox
            // 
            this.AddressTextBox.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.AddressTextBox.Location = new System.Drawing.Point(127, 30);
            this.AddressTextBox.Name = "AddressTextBox";
            this.AddressTextBox.Size = new System.Drawing.Size(683, 25);
            this.AddressTextBox.TabIndex = 2;
            this.AddressTextBox.Text = "7254H 04A2H 1B5EH 25B3H 0347H 31CEH 03EAH 43A4H 234AH 324BH 034BH 3397H 218BH 134" +
    "AH 2781H 0634H 134BH 7478H 0349H 1324H";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "对应的页号";
            // 
            // pagesTextbox
            // 
            this.pagesTextbox.Location = new System.Drawing.Point(127, 69);
            this.pagesTextbox.Name = "pagesTextbox";
            this.pagesTextbox.Size = new System.Drawing.Size(683, 25);
            this.pagesTextbox.TabIndex = 4;
            // 
            // btnRandom
            // 
            this.btnRandom.Location = new System.Drawing.Point(816, 24);
            this.btnRandom.Name = "btnRandom";
            this.btnRandom.Size = new System.Drawing.Size(160, 39);
            this.btnRandom.TabIndex = 7;
            this.btnRandom.Text = "随机生成逻辑地址 ";
            this.btnRandom.UseVisualStyleBackColor = true;
            this.btnRandom.Click += new System.EventHandler(this.btnRandom_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.panel4);
            this.groupBox1.Controls.Add(this.addressLowwerTextbox);
            this.groupBox1.Controls.Add(this.addressUpperTextbox);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.noFast);
            this.groupBox1.Controls.Add(this.useFast);
            this.groupBox1.Controls.Add(this.LAnumTextbox);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.PagesizeNumTextbox);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.textBox8);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.textBox7);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.textBox6);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.memblockTextbox);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.pageNumTextbox);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Location = new System.Drawing.Point(1015, 15);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(296, 495);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "各类参数设置";
            // 
            // panel4
            // 
            this.panel4.AutoScroll = true;
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.pictureBoxPagetable);
            this.panel4.Location = new System.Drawing.Point(31, 311);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(239, 168);
            this.panel4.TabIndex = 27;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(111, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 15);
            this.label3.TabIndex = 1;
            this.label3.Text = "页表";
            // 
            // pictureBoxPagetable
            // 
            this.pictureBoxPagetable.Location = new System.Drawing.Point(74, 28);
            this.pictureBoxPagetable.Name = "pictureBoxPagetable";
            this.pictureBoxPagetable.Size = new System.Drawing.Size(100, 50);
            this.pictureBoxPagetable.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxPagetable.TabIndex = 0;
            this.pictureBoxPagetable.TabStop = false;
            // 
            // addressLowwerTextbox
            // 
            this.addressLowwerTextbox.Location = new System.Drawing.Point(150, 51);
            this.addressLowwerTextbox.Name = "addressLowwerTextbox";
            this.addressLowwerTextbox.Size = new System.Drawing.Size(55, 25);
            this.addressLowwerTextbox.TabIndex = 26;
            this.addressLowwerTextbox.Text = "0000H";
            // 
            // addressUpperTextbox
            // 
            this.addressUpperTextbox.Location = new System.Drawing.Point(224, 51);
            this.addressUpperTextbox.Name = "addressUpperTextbox";
            this.addressUpperTextbox.Size = new System.Drawing.Size(47, 25);
            this.addressUpperTextbox.TabIndex = 25;
            this.addressUpperTextbox.Text = "FFFFH";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(211, 61);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(15, 15);
            this.label16.TabIndex = 24;
            this.label16.Text = "~";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(256, 115);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(23, 15);
            this.label22.TabIndex = 22;
            this.label22.Text = "nm";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(256, 146);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(23, 15);
            this.label21.TabIndex = 21;
            this.label21.Text = "nm";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(256, 181);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(23, 15);
            this.label20.TabIndex = 20;
            this.label20.Text = "nm";
            // 
            // noFast
            // 
            this.noFast.AutoSize = true;
            this.noFast.Location = new System.Drawing.Point(205, 271);
            this.noFast.Name = "noFast";
            this.noFast.Size = new System.Drawing.Size(43, 19);
            this.noFast.TabIndex = 19;
            this.noFast.TabStop = true;
            this.noFast.Text = "否";
            this.noFast.UseVisualStyleBackColor = true;
            // 
            // useFast
            // 
            this.useFast.AutoSize = true;
            this.useFast.Checked = true;
            this.useFast.Location = new System.Drawing.Point(145, 271);
            this.useFast.Name = "useFast";
            this.useFast.Size = new System.Drawing.Size(43, 19);
            this.useFast.TabIndex = 18;
            this.useFast.TabStop = true;
            this.useFast.Text = "是";
            this.useFast.UseVisualStyleBackColor = true;
            // 
            // LAnumTextbox
            // 
            this.LAnumTextbox.Location = new System.Drawing.Point(150, 236);
            this.LAnumTextbox.Name = "LAnumTextbox";
            this.LAnumTextbox.Size = new System.Drawing.Size(100, 25);
            this.LAnumTextbox.TabIndex = 17;
            this.LAnumTextbox.Text = "16";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(28, 239);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(97, 15);
            this.label19.TabIndex = 16;
            this.label19.Text = "逻辑地址位数";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(13, 54);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(127, 15);
            this.label12.TabIndex = 14;
            this.label12.Text = "访问序列地址范围";
            // 
            // PagesizeNumTextbox
            // 
            this.PagesizeNumTextbox.Location = new System.Drawing.Point(150, 205);
            this.PagesizeNumTextbox.Name = "PagesizeNumTextbox";
            this.PagesizeNumTextbox.Size = new System.Drawing.Size(100, 25);
            this.PagesizeNumTextbox.TabIndex = 13;
            this.PagesizeNumTextbox.Text = "12";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(28, 208);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(112, 15);
            this.label17.TabIndex = 12;
            this.label17.Text = "页面大小的位数";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(28, 271);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(97, 15);
            this.label9.TabIndex = 11;
            this.label9.Text = "是否启用快表";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(150, 174);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(100, 25);
            this.textBox8.TabIndex = 9;
            this.textBox8.Text = "5";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(28, 177);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(97, 15);
            this.label8.TabIndex = 8;
            this.label8.Text = "访问快表时间";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(150, 143);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 25);
            this.textBox7.TabIndex = 7;
            this.textBox7.Text = "1000";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(28, 146);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(97, 15);
            this.label7.TabIndex = 6;
            this.label7.Text = "缺页中断时间";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(150, 112);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 25);
            this.textBox6.TabIndex = 5;
            this.textBox6.Text = "50";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(28, 115);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 15);
            this.label6.TabIndex = 4;
            this.label6.Text = "访问内存时间";
            // 
            // memblockTextbox
            // 
            this.memblockTextbox.Location = new System.Drawing.Point(150, 80);
            this.memblockTextbox.Name = "memblockTextbox";
            this.memblockTextbox.Size = new System.Drawing.Size(100, 25);
            this.memblockTextbox.TabIndex = 3;
            this.memblockTextbox.Text = "3";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(53, 83);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 15);
            this.label5.TabIndex = 2;
            this.label5.Text = "页框数";
            // 
            // pageNumTextbox
            // 
            this.pageNumTextbox.Location = new System.Drawing.Point(150, 20);
            this.pageNumTextbox.Name = "pageNumTextbox";
            this.pageNumTextbox.Size = new System.Drawing.Size(100, 25);
            this.pageNumTextbox.TabIndex = 1;
            this.pageNumTextbox.Text = "20";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 15);
            this.label4.TabIndex = 0;
            this.label4.Text = "访问序列地址个数";
            // 
            // btnFIFO
            // 
            this.btnFIFO.Location = new System.Drawing.Point(66, 24);
            this.btnFIFO.Name = "btnFIFO";
            this.btnFIFO.Size = new System.Drawing.Size(76, 40);
            this.btnFIFO.TabIndex = 9;
            this.btnFIFO.Text = "启动";
            this.btnFIFO.UseVisualStyleBackColor = true;
            this.btnFIFO.Click += new System.EventHandler(this.btnFIFO_Click);
            // 
            // btnStopFIFO
            // 
            this.btnStopFIFO.Location = new System.Drawing.Point(148, 24);
            this.btnStopFIFO.Name = "btnStopFIFO";
            this.btnStopFIFO.Size = new System.Drawing.Size(75, 40);
            this.btnStopFIFO.TabIndex = 10;
            this.btnStopFIFO.Text = "挂起";
            this.btnStopFIFO.UseVisualStyleBackColor = true;
            this.btnStopFIFO.Click += new System.EventHandler(this.btnStopFIFO_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btncmd);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.btnStopALL);
            this.groupBox2.Controls.Add(this.btnALL);
            this.groupBox2.Controls.Add(this.btnStopOPT);
            this.groupBox2.Controls.Add(this.btnOPT);
            this.groupBox2.Controls.Add(this.btnStopLRU);
            this.groupBox2.Controls.Add(this.btnLRU);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.btnFIFO);
            this.groupBox2.Controls.Add(this.btnStopFIFO);
            this.groupBox2.Location = new System.Drawing.Point(25, 130);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(959, 126);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "控制台";
            this.groupBox2.Enter += new System.EventHandler(this.groupBox2_Enter);
            // 
            // btncmd
            // 
            this.btncmd.Location = new System.Drawing.Point(828, 73);
            this.btncmd.Name = "btncmd";
            this.btncmd.Size = new System.Drawing.Size(75, 46);
            this.btncmd.TabIndex = 25;
            this.btncmd.Text = "启动";
            this.btncmd.UseVisualStyleBackColor = true;
            this.btncmd.Click += new System.EventHandler(this.btncmd_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(775, 31);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(167, 30);
            this.label15.TabIndex = 24;
            this.label15.Text = "  页面置换控制台程序\r\n(FIFO,LRU,OPT,CLOCK)";
            // 
            // btnStopALL
            // 
            this.btnStopALL.Location = new System.Drawing.Point(474, 82);
            this.btnStopALL.Name = "btnStopALL";
            this.btnStopALL.Size = new System.Drawing.Size(80, 37);
            this.btnStopALL.TabIndex = 23;
            this.btnStopALL.Text = "挂起";
            this.btnStopALL.UseVisualStyleBackColor = true;
            this.btnStopALL.Click += new System.EventHandler(this.btnStopALL_Click);
            // 
            // btnALL
            // 
            this.btnALL.Location = new System.Drawing.Point(375, 82);
            this.btnALL.Name = "btnALL";
            this.btnALL.Size = new System.Drawing.Size(79, 37);
            this.btnALL.TabIndex = 22;
            this.btnALL.Text = "启动";
            this.btnALL.UseVisualStyleBackColor = true;
            this.btnALL.Click += new System.EventHandler(this.btnALL_Click);
            // 
            // btnStopOPT
            // 
            this.btnStopOPT.Location = new System.Drawing.Point(616, 33);
            this.btnStopOPT.Name = "btnStopOPT";
            this.btnStopOPT.Size = new System.Drawing.Size(75, 38);
            this.btnStopOPT.TabIndex = 21;
            this.btnStopOPT.Text = "挂起";
            this.btnStopOPT.UseVisualStyleBackColor = true;
            this.btnStopOPT.Click += new System.EventHandler(this.btnStopOPT_Click);
            // 
            // btnOPT
            // 
            this.btnOPT.Location = new System.Drawing.Point(535, 33);
            this.btnOPT.Name = "btnOPT";
            this.btnOPT.Size = new System.Drawing.Size(75, 38);
            this.btnOPT.TabIndex = 20;
            this.btnOPT.Text = "启动";
            this.btnOPT.UseVisualStyleBackColor = true;
            this.btnOPT.Click += new System.EventHandler(this.btnOPT_Click);
            // 
            // btnStopLRU
            // 
            this.btnStopLRU.Location = new System.Drawing.Point(379, 28);
            this.btnStopLRU.Name = "btnStopLRU";
            this.btnStopLRU.Size = new System.Drawing.Size(75, 43);
            this.btnStopLRU.TabIndex = 17;
            this.btnStopLRU.Text = "挂起";
            this.btnStopLRU.UseVisualStyleBackColor = true;
            this.btnStopLRU.Click += new System.EventHandler(this.btnStopLRU_Click);
            // 
            // btnLRU
            // 
            this.btnLRU.Location = new System.Drawing.Point(295, 28);
            this.btnLRU.Name = "btnLRU";
            this.btnLRU.Size = new System.Drawing.Size(75, 38);
            this.btnLRU.TabIndex = 16;
            this.btnLRU.Text = "启动";
            this.btnLRU.UseVisualStyleBackColor = true;
            this.btnLRU.Click += new System.EventHandler(this.btnLRU_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(221, 93);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(127, 15);
            this.label14.TabIndex = 15;
            this.label14.Text = "全部算法同时执行";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(498, 42);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(31, 15);
            this.label13.TabIndex = 14;
            this.label13.Text = "OPT";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(258, 38);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(31, 15);
            this.label11.TabIndex = 12;
            this.label11.Text = "LRU";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(15, 31);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(39, 15);
            this.label10.TabIndex = 11;
            this.label10.Text = "FIFO";
            // 
            // labelFIFO
            // 
            this.labelFIFO.AutoSize = true;
            this.labelFIFO.BackColor = System.Drawing.Color.Transparent;
            this.labelFIFO.Font = new System.Drawing.Font("黑体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelFIFO.Location = new System.Drawing.Point(400, 259);
            this.labelFIFO.Name = "labelFIFO";
            this.labelFIFO.Size = new System.Drawing.Size(188, 24);
            this.labelFIFO.TabIndex = 12;
            this.labelFIFO.Text = "FIFO(先进先出)";
            // 
            // labelLRU
            // 
            this.labelLRU.AutoSize = true;
            this.labelLRU.BackColor = System.Drawing.Color.Transparent;
            this.labelLRU.Font = new System.Drawing.Font("黑体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelLRU.Location = new System.Drawing.Point(350, 497);
            this.labelLRU.Name = "labelLRU";
            this.labelLRU.Size = new System.Drawing.Size(262, 24);
            this.labelLRU.TabIndex = 13;
            this.labelLRU.Text = "LRU(最近最久未使用）";
            // 
            // btnPage
            // 
            this.btnPage.Location = new System.Drawing.Point(816, 68);
            this.btnPage.Name = "btnPage";
            this.btnPage.Size = new System.Drawing.Size(160, 36);
            this.btnPage.TabIndex = 14;
            this.btnPage.Text = "生成对应页号";
            this.btnPage.UseVisualStyleBackColor = true;
            this.btnPage.Click += new System.EventHandler(this.btnPage_Click);
            // 
            // labelOPT
            // 
            this.labelOPT.AutoSize = true;
            this.labelOPT.BackColor = System.Drawing.Color.Transparent;
            this.labelOPT.Font = new System.Drawing.Font("黑体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labelOPT.ForeColor = System.Drawing.Color.Black;
            this.labelOPT.Location = new System.Drawing.Point(396, 738);
            this.labelOPT.Name = "labelOPT";
            this.labelOPT.Size = new System.Drawing.Size(175, 24);
            this.labelOPT.TabIndex = 16;
            this.labelOPT.Text = "OPT(最佳置换)";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label1);
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.btnPage);
            this.groupBox3.Controls.Add(this.AddressTextBox);
            this.groupBox3.Controls.Add(this.pagesTextbox);
            this.groupBox3.Controls.Add(this.btnRandom);
            this.groupBox3.Location = new System.Drawing.Point(27, 14);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(982, 113);
            this.groupBox3.TabIndex = 17;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "页面逻辑地址及对应物理地址";
            // 
            // FIFOLacklabel
            // 
            this.FIFOLacklabel.AutoSize = true;
            this.FIFOLacklabel.Location = new System.Drawing.Point(34, 464);
            this.FIFOLacklabel.Name = "FIFOLacklabel";
            this.FIFOLacklabel.Size = new System.Drawing.Size(122, 15);
            this.FIFOLacklabel.TabIndex = 18;
            this.FIFOLacklabel.Text = "FIFO当前缺页率:";
            // 
            // lableFIFOsleep
            // 
            this.lableFIFOsleep.AutoSize = true;
            this.lableFIFOsleep.Location = new System.Drawing.Point(34, 479);
            this.lableFIFOsleep.Name = "lableFIFOsleep";
            this.lableFIFOsleep.Size = new System.Drawing.Size(137, 15);
            this.lableFIFOsleep.TabIndex = 19;
            this.lableFIFOsleep.Text = "FIFO当前累计用时:";
            // 
            // LRULacklabel
            // 
            this.LRULacklabel.AutoSize = true;
            this.LRULacklabel.Location = new System.Drawing.Point(37, 706);
            this.LRULacklabel.Name = "LRULacklabel";
            this.LRULacklabel.Size = new System.Drawing.Size(114, 15);
            this.LRULacklabel.TabIndex = 20;
            this.LRULacklabel.Text = "LRU当前缺页率:";
            // 
            // lableLRUsleep
            // 
            this.lableLRUsleep.AutoSize = true;
            this.lableLRUsleep.Location = new System.Drawing.Point(34, 721);
            this.lableLRUsleep.Name = "lableLRUsleep";
            this.lableLRUsleep.Size = new System.Drawing.Size(129, 15);
            this.lableLRUsleep.TabIndex = 21;
            this.lableLRUsleep.Text = "LRU当前累计用时:";
            // 
            // OPTLacklabel
            // 
            this.OPTLacklabel.AutoSize = true;
            this.OPTLacklabel.Location = new System.Drawing.Point(34, 940);
            this.OPTLacklabel.Name = "OPTLacklabel";
            this.OPTLacklabel.Size = new System.Drawing.Size(114, 15);
            this.OPTLacklabel.TabIndex = 22;
            this.OPTLacklabel.Text = "OPT当前缺页率:";
            // 
            // lableOPTsleep
            // 
            this.lableOPTsleep.AutoSize = true;
            this.lableOPTsleep.Location = new System.Drawing.Point(37, 955);
            this.lableOPTsleep.Name = "lableOPTsleep";
            this.lableOPTsleep.Size = new System.Drawing.Size(129, 15);
            this.lableOPTsleep.TabIndex = 23;
            this.lableOPTsleep.Text = "OPT当前累计用时:";
            // 
            // panel1
            // 
            this.panel1.AutoScroll = true;
            this.panel1.AutoScrollMargin = new System.Drawing.Size(300, 100);
            this.panel1.Controls.Add(this.pictureBoxFIFO);
            this.panel1.Location = new System.Drawing.Point(30, 286);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(969, 175);
            this.panel1.TabIndex = 24;
            // 
            // pictureBoxFIFO
            // 
            this.pictureBoxFIFO.Location = new System.Drawing.Point(2, 3);
            this.pictureBoxFIFO.Name = "pictureBoxFIFO";
            this.pictureBoxFIFO.Size = new System.Drawing.Size(100, 50);
            this.pictureBoxFIFO.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxFIFO.TabIndex = 0;
            this.pictureBoxFIFO.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.AutoScroll = true;
            this.panel2.Controls.Add(this.pictureBoxLRU);
            this.panel2.Location = new System.Drawing.Point(27, 524);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(969, 179);
            this.panel2.TabIndex = 25;
            // 
            // pictureBoxLRU
            // 
            this.pictureBoxLRU.Location = new System.Drawing.Point(0, 3);
            this.pictureBoxLRU.Name = "pictureBoxLRU";
            this.pictureBoxLRU.Size = new System.Drawing.Size(100, 50);
            this.pictureBoxLRU.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxLRU.TabIndex = 0;
            this.pictureBoxLRU.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.AutoScroll = true;
            this.panel3.Controls.Add(this.pictureBoxOPT);
            this.panel3.Location = new System.Drawing.Point(27, 765);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(969, 172);
            this.panel3.TabIndex = 26;
            // 
            // pictureBoxOPT
            // 
            this.pictureBoxOPT.Location = new System.Drawing.Point(0, 0);
            this.pictureBoxOPT.Name = "pictureBoxOPT";
            this.pictureBoxOPT.Size = new System.Drawing.Size(100, 50);
            this.pictureBoxOPT.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBoxOPT.TabIndex = 0;
            this.pictureBoxOPT.TabStop = false;
            // 
            // chart1
            // 
            this.chart1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            chartArea3.AxisX.Title = "页面置换算法";
            chartArea3.AxisY.Title = "缺页率（%）";
            chartArea3.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea3);
            this.chart1.Location = new System.Drawing.Point(1015, 789);
            this.chart1.Name = "chart1";
            this.chart1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;
            series3.ChartArea = "ChartArea1";
            series3.Name = "Series1";
            this.chart1.Series.Add(series3);
            this.chart1.Size = new System.Drawing.Size(314, 219);
            this.chart1.TabIndex = 0;
            this.chart1.Text = "chart1";
            title3.Name = "Title1";
            title3.Text = "缺页率-页面置换算法柱状图";
            this.chart1.Titles.Add(title3);
            // 
            // chart2
            // 
            this.chart2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            chartArea4.AxisX.Title = "页面置换算法";
            chartArea4.AxisY.Title = "总时间（ns）";
            chartArea4.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea4);
            this.chart2.Location = new System.Drawing.Point(1015, 554);
            this.chart2.Name = "chart2";
            this.chart2.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Excel;
            series4.ChartArea = "ChartArea1";
            series4.Name = "Series1";
            this.chart2.Series.Add(series4);
            this.chart2.Size = new System.Drawing.Size(296, 219);
            this.chart2.TabIndex = 28;
            this.chart2.Text = "chart2";
            title4.Name = "Title1";
            title4.Text = "用时-页面置换算法柱状图";
            this.chart2.Titles.Add(title4);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1015, 512);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(88, 36);
            this.button1.TabIndex = 30;
            this.button1.Text = "分析数据";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.AutoScrollMargin = new System.Drawing.Size(30, 10);
            this.AutoScrollMinSize = new System.Drawing.Size(30, 10);
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1340, 1055);
            this.Controls.Add(this.chart1);
            this.Controls.Add(this.chart2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lableOPTsleep);
            this.Controls.Add(this.OPTLacklabel);
            this.Controls.Add(this.lableLRUsleep);
            this.Controls.Add(this.LRULacklabel);
            this.Controls.Add(this.lableFIFOsleep);
            this.Controls.Add(this.FIFOLacklabel);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.labelOPT);
            this.Controls.Add(this.labelLRU);
            this.Controls.Add(this.labelFIFO);
            this.Controls.Add(this.groupBox1);
            this.ForeColor = System.Drawing.SystemColors.Desktop;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Text = "页面置换算法程序";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPagetable)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxFIFO)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxLRU)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxOPT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox AddressTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox pagesTextbox;
        private System.Windows.Forms.Button btnRandom;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox memblockTextbox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox pageNumTextbox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnFIFO;
        private System.Windows.Forms.Button btnStopFIFO;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnStopOPT;
        private System.Windows.Forms.Button btnOPT;
        private System.Windows.Forms.Button btnStopLRU;
        private System.Windows.Forms.Button btnLRU;
        private System.Windows.Forms.Label labelFIFO;
        private System.Windows.Forms.Label labelLRU;
        private System.Windows.Forms.TextBox PagesizeNumTextbox;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button btnStopALL;
        private System.Windows.Forms.Button btnALL;
        private System.Windows.Forms.Button btnPage;
        private System.Windows.Forms.Label labelOPT;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox LAnumTextbox;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.RadioButton noFast;
        private System.Windows.Forms.RadioButton useFast;
        private System.Windows.Forms.Label FIFOLacklabel;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lableFIFOsleep;
        private System.Windows.Forms.Label LRULacklabel;
        private System.Windows.Forms.Label lableLRUsleep;
        private System.Windows.Forms.Label OPTLacklabel;
        private System.Windows.Forms.Label lableOPTsleep;
        private System.Windows.Forms.Button btncmd;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox addressLowwerTextbox;
        private System.Windows.Forms.TextBox addressUpperTextbox;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBoxFIFO;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBoxLRU;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBoxOPT;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox pictureBoxPagetable;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart2;
        private System.Windows.Forms.Button button1;
    }
}

