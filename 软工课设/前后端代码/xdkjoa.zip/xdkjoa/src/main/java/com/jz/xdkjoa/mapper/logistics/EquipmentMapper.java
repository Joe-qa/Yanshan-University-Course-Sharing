package com.jz.xdkjoa.mapper.logistics;

import com.jz.xdkjoa.pojo.logistics.Equipment;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface EquipmentMapper {
    /**
     * 添加设备信息
     * @param equipment
     */
    void addEquipmentMsg(Equipment equipment);

    /**
     * 查询设备信息
     * @return
     */
    List<Equipment>showAllEquipment();

}
