package com.jz.xdkjoa.mapper.logistics;

import com.jz.xdkjoa.pojo.logistics.Repair;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface RepairMapper {
    /**
     * 添加维修记录
     * @param repair
     */
    void addRepairRecord(Repair repair);

    /**
     * 删除维修记录
     * @param repair_num
     */
    void delRepairRecord(Integer repair_num);

    /**
     * 展示维修记录
     * @return
     */
    List<Repair>showRepairRecord();

    void updateRepairRecord(Repair repair);


}
