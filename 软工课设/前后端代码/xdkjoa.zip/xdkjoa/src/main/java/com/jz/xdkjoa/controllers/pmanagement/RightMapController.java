package com.jz.xdkjoa.controllers.pmanagement;

import com.jz.xdkjoa.pojo.pmanagement.RightMap;
import com.jz.xdkjoa.service.pmanagement.RightMapService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/right")
public class RightMapController {
    @Autowired(required = false)
    RightMapService rightMapService;
    @GetMapping("/findright")
     public List<RightMap> findRight(String account){
        //System.out.println(rightMapService.findRightBiz(account));
         return rightMapService.findRightBiz(account);
     }
}
