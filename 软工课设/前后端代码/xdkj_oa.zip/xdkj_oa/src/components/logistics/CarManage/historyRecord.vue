<template>
	<div>
	<el-table :data="carRecordList" height="500" tooltip-effect="dark" style="width: 100%">
		<el-table-column prop="carMsg.car_num" label="车牌号" width="120">
		</el-table-column>
		<el-table-column prop="carMsg.car_model" label="车辆型号" width="180">
		</el-table-column>
		<el-table-column prop="carMsg.department" label="部门" width="120">
		</el-table-column>
		<el-table-column prop="job_num" label="借用人工号" width="120">
		</el-table-column>
		<!-- <el-table-column prop="staffname" label="借用人姓名">
		</el-table-column> -->
		<el-table-column prop="use_reason" label="使用原因">
		</el-table-column>
		<el-table-column prop="borrow_time":formatter="dateFormatter" label="借用时间" width="120">
		</el-table-column>
		<el-table-column prop="return_time":formatter="dateFormatter" label="应还时间" width="120">
		</el-table-column>
		<el-table-column prop="really_time":formatter="dateFormatter" label="实际归还时间" width="120">
		</el-table-column>
		<!-- <el-table-column prop="situation" label="情况">
		</el-table-column> -->
	</el-table>
	<!--分页控件 -->
			<div class="block" style="justify-content: center; display: flex; margin-top: 10px;">
				<el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
					:current-page="currentPage" :page-sizes="[2, 6, 7]" :page-size="pageSize"
					layout="total, sizes, prev, pager, next, jumper" :total="carRecord.length">
				</el-pagination>
			</div>
	</div>
</template>

<script>
	export default {
		created() {
			var test = sessionStorage.getItem('testKey')
			console.log('这是测试', test)
			var car_num = this.$route.query.car_num
			console.log(car_num)
			let that = this
			this.$axios({
				method: 'get',
				url: 'http://localhost:8888/CarRecord/showByCarNumRecord?car_num=' + car_num,

			}).then(function(res) {
				console.log(res)
				that.carRecord = res.data
				that.carRecordList=that.carRecord.slice(0,that.pageSize);
			})
		},
		data() {
			return {
				carRecord: [],
				carRecordList:[],
				currentPage:1,
				pageSize:2,
			}
		},
		methods: {
			dateFormatter(row) {
				let datetime = row.borrow_time;
				if (datetime) {
					datetime = new Date(datetime);
					let y = datetime.getFullYear() + '-';
					let mon = datetime.getMonth() + 1 + '-';
					let d = datetime.getDate();
					return y + mon + d;
				}
				return ''
			},
			//每页条数切换
			handleSizeChange(pageSize) {
				this.pageSize = pageSize;
				this.handleCurrentChange(this.currentPage);
			},
			//页码切换
			handleCurrentChange(currentPage) {
				this.currentPage = currentPage;
				this.currentChangePage(this.carRecord, currentPage);
			},
			//分页实现
			currentChangePage(list, currentPage) {
				let from = (currentPage - 1) * this.pageSize;
				let to = currentPage * this.pageSize;
				this.carRecordList = this.carRecord.slice(from, to);
			},
		}
	}
</script>
