package com.jz.xdkjoa.pojo.administration;

import java.util.Date;

public class BusinessCalendar {
 private int  schedule_num;
 private  int depart_num;
 private String headline;
 private String business_describe;
 private String business_level;
 private Date start_time;
 private  Date end_time;

   public BusinessCalendar(int schedule_num, int depart_num, String headline, String business_describe, String business_level, Date start_time, Date end_time) {
      this.schedule_num = schedule_num;
      this.depart_num = depart_num;
      this.headline = headline;
      this.business_describe = business_describe;
      this.business_level = business_level;
      this.start_time = start_time;
      this.end_time = end_time;
   }
   public BusinessCalendar(){}

   public int getSchedule_num() {
      return schedule_num;
   }

   public void setSchedule_num(int schedule_num) {
      this.schedule_num = schedule_num;
   }

   public int getDepart_num() {
      return depart_num;
   }

   public void setDepart_num(int depart_num) {
      this.depart_num = depart_num;
   }

   public String getHeadline() {
      return headline;
   }

   public void setHeadline(String headline) {
      this.headline = headline;
   }

   public String getBusiness_describe() {
      return business_describe;
   }

   public void setBusiness_describe(String business_describe) {
      this.business_describe = business_describe;
   }

   public String getBusiness_level() {
      return business_level;
   }

   public void setBusiness_level(String business_level) {
      this.business_level = business_level;
   }

   public Date getStart_time() {
      return start_time;
   }

   public void setStart_time(Date start_time) {
      this.start_time = start_time;
   }



    public Date getEnd_time() {
      return end_time;
   }

   public void setEnd_time(Date end_time) {
      this.end_time = end_time;
   }
    @Override
    public String toString() {
        return "BusinessCalendar{" +
                "schedule_num=" + schedule_num +
                ", depart_num=" + depart_num +
                ", headline='" + headline + '\'' +
                ", business_describe='" + business_describe + '\'' +
                ", business_level='" + business_level + '\'' +
                ", start_time=" + start_time +
                ", end_time=" + end_time +
                '}';
    }
}
