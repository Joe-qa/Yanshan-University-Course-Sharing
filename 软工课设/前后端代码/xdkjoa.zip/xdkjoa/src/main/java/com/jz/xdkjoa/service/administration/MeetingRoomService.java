package com.jz.xdkjoa.service.administration;



public interface MeetingRoomService {


}
