<template>
  <div style="margin-top: 0px;">
    <el-container >
      <el-main style="height: 700px;">
        <el-form :rules="rules" ref="staff" :model="staff" label-width="80px"
          style="margin-left: 80px; margin-top: 0px;">
          <el-row>
            <el-col span="20">
              <el-form-item label="员工工号" prop="job_num">
                <el-input v-model="staff.job_num"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col span="20">
              <el-form-item label="员工账号" prop="account">
                <el-input v-model="staff.account"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col span="20">
              <el-form-item label="账号密码" prop="staff_password">
                <el-input v-model="staff.staff_password" show-password></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col span="10">
              <el-form-item label="员工类型" prop="staff_type">
                <el-select v-model="staff.staff_type">
                  <el-option label="正式员工" value="正式员工"></el-option>
                  <el-option label="临时员工" value="临时员工"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col span="10">
              <el-form-item label="是否在职" prop="in_office">
                <el-select v-model="staff.in_office">
                  <el-option label="是" value="是"></el-option>
                  <el-option label="否" value="否"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col span="10">
              <el-form-item label="部门名称" prop="depart_num">
                <el-select v-model="staff.depart_num">
                  <el-option v-for="d in depts" :key="d.depart_num" :label="d.depart_name" :value="d.depart_num">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col span="10">
              <el-form-item label="职位名称" prop="post_num">
                <el-select v-model="staff.post_num">
                  <el-option v-for="j in jobs" :key="j.post_num" :label="j.post_name" :value="j.post_num">
                  </el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col span="20">
              <el-form-item label="邮箱" prop="email">
                <el-input v-model="staff.email"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col span="20">
              <el-form-item label="电话" prop="staff_tel">
                <el-input v-model="staff.staff_tel"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <br>
          <el-form-item style="margin-left: 150px;">
            <el-button type="primary" @click="back">返回上一页</el-button>
            <el-button type="primary" @click="onSubmit('staff')">立即创建</el-button>
            <el-button @click="cancel">取消</el-button>
          </el-form-item>
        </el-form>
      </el-main>
      <el-aside style="height: 500px;">
        <div style="height:400px; width: 150px;margin-top: 50px;">
          <el-steps direction="vertical" :active="2">
            <el-step title="员工基本信息录入"></el-step>
            <el-step title="职位信息录入"></el-step>
          </el-steps>
        </div>
      </el-aside>
    </el-container>
  </div>
</template>

<script>
  export default {
    data() {
      return {
        dialogImageUrl: '',
        dialogVisible: false,
        jobs: [],
        depts: [],
        staff: '',
        // staff: {
        // job_num: '',
        // depart_num: '',
        // post_num: '',
        // staff_name: '',
        // account: '',
        // staff_password: '',
        // staff_type: '',
        // gender: '1',
        // nationality: '',
        // nation: '',
        // identity_num: '',
        // birthday: '',
        // native_place: '',
        // politics_statues: '',
        // email: '',
        // in_office: '',
        // service_length: '',
        // staff_tel: '',
        //},
        rules: {
          job_num: [{required: true, message: '请输入员工工号', trigger: 'blur'},  
		            {max:10, message: '员工工号不超过10个字符'},
					{ pattern: /^[^\u4e00-\u9fa5]+$/, message: '不允许输入中文', trigger: 'blur' },
					{ pattern: /^[A-Za-z0-9\u4e00-\u9fa5]+$/, message: '不允许输入空格等特殊符号', trigger: 'blur' }
					],
          depart_num: [{
            required: true,
            message: '请选择所属部门',
            trigger: 'blur'
          }, ],
          post_num: [{
            required: true,
            message: '请选择职位',
            trigger: 'change'
          }, ],
          staff_password: [
		   {required: true,message: '请输入员工登录密码',trigger: 'blur'}, 
		   { min:6,max:20,message: '密码长度不低于6个字符', trigger: 'blur' },
		   { pattern: /^[A-Za-z0-9\u4e00-\u9fa5]+$/, message: '不允许输入空格等特殊符号', trigger: 'blur' }
		   ],
          account: [
		  { required: true,message: '请输入员工的登录账号',trigger: 'blur'},  
		  { pattern: /^[A-Za-z0-9\u4e00-\u9fa5]+$/, message: '不允许输入空格等特殊符号', trigger: 'blur' },
		  ],
          staff_type: [{
            required: true,
            message: '请选择员工类型类型',
            trigger: 'change'
          }],
          email: 
		  [
			{required: true,message: '请输入邮箱',trigger: 'blur'},
			{ pattern: /^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/, message: '邮箱格式不正确', trigger: 'blur' },
		  ],
          in_office: [{
            required: true,
            message: '请选择在职情况',
            trigger: 'change'
          }, ]
        }
      }
    },
    methods: {
      back() {
        this.$router.push({
          name: 'addStaff1'
        })
      },
      onSubmit(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let that = this
            this.$axios({
              method: 'post',
              url: 'http://localhost:8888/staff/addstaff',
              data: that.staff
            }).then(function() {
              that.$message({
                showClose: true,
                message: '创建成功',
                type: 'success',
                offset: 300
              });
              that.staff.job_num = ''
              that.staff.depart_num = ''
              that.staff.post_num = ''
              that.staff.staff_name = ''
              that.staff.account = ''
              that.staff.staff_password = ''
              that.staff.staff_type = ''
              that.staff.gender = ''
              that.staff.nationality = ''
              that.staff.nation = ''
              that.staff.identity_num = ''
              that.staff.birthday = ''
              that.staff.native_place = ''
              that.staff.politics_statues = ''
              that.staff.email = ''
              that.staff.in_office = ''
              that.staff.service_length = '0'
              that.staff.staff_tel = ''
              sessionStorage.setItem('staff', JSON.stringify(that.staff))
			  sessionStorage.removeItem('staff')
            })
          } else {
            console.log('error submit!!');
            return false;
          }
        });
      },
      fun() {
        console.log(this.gender + '>>>>>>>>>>>')
      },
      handleRemove(file, fileList) {
        console.log(file, fileList);
      },
      handlePictureCardPreview(file) {
        this.dialogImageUrl = file.url;
        this.dialogVisible = true;
      },
      cancel() {
        let that=this
        that.staff.job_num = ''
        that.staff.depart_num = ''
        that.staff.post_num = ''
        that.staff.staff_name = ''
        that.staff.account = ''
        that.staff.staff_password = ''
        that.staff.staff_type = ''
        that.staff.gender = ''
        that.staff.nationality = ''
        that.staff.nation = ''
        that.staff.identity_num = ''
        that.staff.birthday = ''
        that.staff.native_place = ''
        that.staff.politics_statues = ''
        that.staff.email = ''
        that.staff.in_office = ''
        that.staff.service_length = '0'
        that.staff.staff_tel = ''
        sessionStorage.setItem('staff', JSON.stringify(that.staff))
		sessionStorage.removeItem('staff')
         this.$router.push({name:'addStaff1'})
      }
    },
    created: function() {
      let that = this
      let staffJson = sessionStorage.getItem('staff')
      that.staff = JSON.parse(staffJson)
      //获取部门信息
      this.$axios({
        method: 'post',
        url: 'http://localhost:8888/department/showalldepartments',
      }).then(function(response) {
        console.log(response.data)
        that.depts = response.data
      })

      //获取职位信息
      this.$axios({
        method: 'post',
        url: 'http://localhost:8888/job/showalljob'

      }).then(function(response) {
        that.jobs = response.data
      })
    }
  }
</script>

<style>
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }

  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }

  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }

  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
</style>
