package com.jz.xdkjoa.pojo.pmanagement;

public class RightMap {
    String account;
    int right_id;
    Staff staff;
    StaffRight staffRight;

    @Override
    public String toString() {
        return "RightMap{" +
                "account=" + account +
                ", right_id=" + right_id +
                ", staff=" + staff +
                ", staffRight=" + staffRight +
                '}';
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public int getRight_id() {
        return right_id;
    }

    public void setRight_id(int right_id) {
        this.right_id = right_id;
    }

    public Staff getStaff() {
        return staff;
    }

    public void setStaff(Staff staff) {
        this.staff = staff;
    }

    public StaffRight getStaffRight() {
        return staffRight;
    }

    public void setStaffRight(StaffRight staffRight) {
        this.staffRight = staffRight;
    }

    public RightMap() {
    }

    public RightMap(String account, int right_id, Staff staff, StaffRight staffRight) {
        this.account = account;
        this.right_id = right_id;
        this.staff = staff;
        this.staffRight = staffRight;
    }
}
