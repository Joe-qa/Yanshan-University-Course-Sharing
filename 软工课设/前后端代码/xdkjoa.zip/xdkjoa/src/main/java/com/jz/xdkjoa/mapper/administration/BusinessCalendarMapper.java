package com.jz.xdkjoa.mapper.administration;

import com.jz.xdkjoa.pojo.administration.BusinessCalendar;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;

import java.util.Calendar;
import java.util.List;

@Mapper
public interface BusinessCalendarMapper {
    void addHeadline(BusinessCalendar headline);
    @Delete("delete from business_calendar where schedule_num=#{schedule_num}")
    void delCalendar(int schedule_num);
    List<BusinessCalendar> showBusinessCalendar();
    void updateCalendar(BusinessCalendar calendar);
}
