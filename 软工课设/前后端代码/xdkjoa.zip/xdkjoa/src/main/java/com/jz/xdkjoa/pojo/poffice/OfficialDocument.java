package com.jz.xdkjoa.pojo.poffice;

import java.sql.Date;

public class OfficialDocument {
    private int official_document_id;
    private String document_concrete_des;
    private String theme;
    private String send_person;
    private String draft_person;
    private Boolean del_state;
    private Boolean attention_state;
    private String document_state;
    private String document_type_name;
    private Date document_draft_date;
    private Date send_date;
    private Date read_date;
    private int job_num;

    public OfficialDocument() {
    }

    public OfficialDocument(int official_document_id, String document_concrete_des, String theme, String send_person, String draft_person, Boolean del_state, Boolean attention_state, String document_state, String document_type_name, Date document_draft_date, Date send_date, Date read_date, int job_num) {
        this.official_document_id = official_document_id;
        this.document_concrete_des = document_concrete_des;
        this.theme = theme;
        this.send_person = send_person;
        this.draft_person = draft_person;
        this.del_state = del_state;
        this.attention_state = attention_state;
        this.document_state = document_state;
        this.document_type_name = document_type_name;
        this.document_draft_date = document_draft_date;
        this.send_date = send_date;
        this.read_date = read_date;
        this.job_num = job_num;
    }

    @Override
    public String toString() {
        return "OfficialDocument{" +
                "official_document_id=" + official_document_id +
                ", document_concrete_des='" + document_concrete_des + '\'' +
                ", theme='" + theme + '\'' +
                ", send_person='" + send_person + '\'' +
                ", draft_person='" + draft_person + '\'' +
                ", del_state=" + del_state +
                ", attention_state=" + attention_state +
                ", document_state='" + document_state + '\'' +
                ", document_type_name='" + document_type_name + '\'' +
                ", document_draft_date=" + document_draft_date +
                ", send_date=" + send_date +
                ", read_date=" + read_date +
                ", job_num=" + job_num +
                '}';
    }

    public int getOfficial_document_id() {
        return official_document_id;
    }

    public void setOfficial_document_id(int official_document_id) {
        this.official_document_id = official_document_id;
    }

    public String getDocument_concrete_des() {
        return document_concrete_des;
    }

    public void setDocument_concrete_des(String document_concrete_des) {
        this.document_concrete_des = document_concrete_des;
    }

    public String getTheme() {
        return theme;
    }

    public void setTheme(String theme) {
        this.theme = theme;
    }

    public String getSend_person() {
        return send_person;
    }

    public void setSend_person(String send_person) {
        this.send_person = send_person;
    }

    public String getDraft_person() {
        return draft_person;
    }

    public void setDraft_person(String draft_person) {
        this.draft_person = draft_person;
    }

    public Boolean getDel_state() {
        return del_state;
    }

    public void setDel_state(Boolean del_state) {
        this.del_state = del_state;
    }

    public Boolean getAttention_state() {
        return attention_state;
    }

    public void setAttention_state(Boolean attention_state) {
        this.attention_state = attention_state;
    }

    public String getDocument_state() {
        return document_state;
    }

    public void setDocument_state(String document_state) {
        this.document_state = document_state;
    }

    public String getDocument_type_name() {
        return document_type_name;
    }

    public void setDocument_type_name(String document_type_name) {
        this.document_type_name = document_type_name;
    }

    public Date getDocument_draft_date() {
        return document_draft_date;
    }

    public void setDocument_draft_date(Date document_draft_date) {
        this.document_draft_date = document_draft_date;
    }

    public Date getSend_date() {
        return send_date;
    }

    public void setSend_date(Date send_date) {
        this.send_date = send_date;
    }

    public Date getRead_date() {
        return read_date;
    }

    public void setRead_date(Date read_date) {
        this.read_date = read_date;
    }

    public int getJob_num() {
        return job_num;
    }

    public void setJob_num(int job_num) {
        this.job_num = job_num;
    }
}
