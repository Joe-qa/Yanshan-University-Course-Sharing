package com.jz.xdkjoa.pojo.pmanagement;

public class StaffRight {
    int right_id;
    String right_content;

    @Override
    public String toString() {
        return "StaffRight{" +
                "right_id=" + right_id +
                ", right_content='" + right_content + '\'' +
                '}';
    }

    public StaffRight() {
    }

    public StaffRight(int right_id, String right_content) {
        this.right_id = right_id;
        this.right_content = right_content;
    }

    public int getRight_id() {
        return right_id;
    }

    public void setRight_id(int right_id) {
        this.right_id = right_id;
    }

    public String getRight_content() {
        return right_content;
    }

    public void setRight_content(String right_content) {
        this.right_content = right_content;
    }
}
