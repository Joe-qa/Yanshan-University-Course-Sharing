<template>
<div>
<el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="400px" class="demo-ruleForm" 
    style="margin-left: 100px; margin-top: 50px;">
  <el-form-item label="活动主题" prop="inform_des" style="width: 53%;" :label-width="formLabelWidth">
    <el-input v-model="ruleForm.inform_des"></el-input>
  </el-form-item>
 <!-- <el-form-item label="员工接收状态" prop="inform_state"  style="width: 50%;" >
    <el-input v-model="ruleForm.inform_state" placeholder="未关注"></el-input>
  </el-form-item> -->
  <el-form-item label="通知类型" prop="inform_type_name" :label-width="formLabelWidth">
    <el-select v-model="ruleForm.inform_type_name" placeholder="请选择通知类型">
      <el-option label="通知" value="通知"></el-option>
      <el-option label="公告" value="公告"></el-option>
    </el-select>
  </el-form-item>
<!--  <el-form-item label="发送部门" prop="depart_num">
    <el-select v-model="ruleForm.depart_num" placeholder="请选择通知部门">
      <el-option label="人事部" value="2"></el-option>
      <el-option label="行政部" value="3"></el-option>
      <el-option label="后勤部" value="4"></el-option>
      <el-option label="总裁办" value="1"></el-option>
    </el-select>
  </el-form-item> -->
  
  <el-form-item label="接收部门" prop="depart_num" :label-width="formLabelWidth">
  	<el-select v-model="ruleForm.depart_num" placeholder="请选择部门">
  		<el-option v-for="(item,index) in department" :key="index" :label="item.depart_name"
  			:value="item.depart_num"></el-option>
  	</el-select>
  </el-form-item>
  
  <el-form-item label="发送日期" prop="inform_receive_date" :label-width="formLabelWidth">
  <el-date-picker default-value=""
          v-model="ruleForm.inform_receive_date"
          type="date"
          placeholder="选择日期">
    </el-date-picker>
   </el-form-item>

  <el-form-item label="通知细则" prop="inform_concrete_des" style="width: 53%;height: auto;" :label-width="formLabelWidth">
    <el-input type="textarea" v-model="ruleForm.inform_concrete_des"></el-input>
  </el-form-item>
  <el-row></el-row>
  <el-row></el-row>
  <el-form-item>
    <el-button type="primary" @click="addinform()">发送通知</el-button>
    <el-button @click="resetForm()">重置</el-button>
  </el-form-item>
</el-form>
</div>
</template>


<script>
  export default {
	  created() {
		 let that=this
	  	this.$axios({
	  		method: 'post',
	  		url: 'http://localhost:8888/department/showalldepartments'
	  	}).then(function(res) {
	  		that.department = res.data
	  		//console.log(res.data)
	  	})
	  },
    data() {
      return {
		  department:'',
        ruleForm: {
		  job_num:'',
          inform_des: '',
          inform_type_name: '',
          inform_receive_date:'',
          inform_concrete_des: '',
          depart_num:'',
          inform_state:'未关注'
        },
        rules: {
          inform_des: [
            { required: true, message: '请输入活动名称', trigger: 'blur' }

          ],
          inform_type_name:[
            {required: true, message: '请选择类型', trigger: 'change'}
            ],

          inform_concrete_des: [
            { required: true, message: '请填写活动细则', trigger: 'blur' }
          ],
          inform_receive_date:[
            {required: true, message: '请选择日期', trigger: 'change'}
          ],
          depart:[
            {required: true, message: '请选择类型', trigger: 'change'}
          ]
        }
      };
    },
    methods: {

      addinform(){
			
        let that =this
       this.$axios({
         method: 'get',
         url: 'http://localhost:8888/staff/findstaffbydepartment?depart_num='+that.ruleForm.depart_num,
       }).then(function(res) {
		    
		   for(var i=0;i<res.data.length;i++){
			  //  that.ruleForm.job_num=res.data[i].job_num
			  // console.log(i)
     //           that.ruleForm.inform_des=res.data[o].staff_name
			  //  console.log(res.data[i].job_num)
			  //  hat.ruleForm.job_num=res.data[o].job_num
			  //  console.log(that.ruleForm)
			   that.$axios({
				   method:'post',
				   url:'http://localhost:8888/inform/addinform',
				   data:{
					   'job_num':res.data[i].job_num,
					   'inform_des':that.ruleForm.inform_des,
					   'inform_type_name':that.ruleForm.inform_type_name,
					   'inform_state':'未关注',
					   'inform_receive_date':that.ruleForm.inform_receive_date,
					   'depart_num':that.ruleForm.depart_num,
					   'inform_concrete_des':that.ruleForm.inform_concrete_des
				   }
			   }).then(function(res){
					 that.$message.success('发送成功!!!')
					 that.ruleForm.job_num=''
          that.ruleForm.inform_des='',
           that.ruleForm.inform_type_name='',
           that.ruleForm.inform_receive_date='',
           that.ruleForm.inform_concrete_des='',
           that.ruleForm.depart_num='',
				   console.log(res.data)
			   }) 
		   }
        
       })
      },
      resetForm(formName) {
        this.$refs[formName].resetFields();
      }
    }
  }
</script>
<style>


</style>
