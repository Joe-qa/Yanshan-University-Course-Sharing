package com.jz.xdkjoa.serviceImpl.logistics;

import com.jz.xdkjoa.mapper.logistics.EquipmentMapper;
import com.jz.xdkjoa.pojo.logistics.Equipment;
import com.jz.xdkjoa.service.logistics.EquipmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EquipmentServiceImpl implements EquipmentService {
    @Autowired(required = false)
    EquipmentMapper equipmentMapper;

    @Override
    public void addEquipmentMsgBiz(Equipment equipment){
        equipmentMapper.addEquipmentMsg(equipment);
    }
    @Override
    public List<Equipment> showAllEquipmentBiz(){
        return equipmentMapper.showAllEquipment();
    }
}
