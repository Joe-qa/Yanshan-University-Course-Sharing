<template>
	<div style="display: flex;flex-direction: column;justify-content: center;align-items: center;">
		<div style="margin-right: auto;">
			<el-button @click="selectCar" type="primary" icon="el-icon-circle-plus-outline">借用车辆</el-button>
			<el-button type="primary" icon="el-icon-upload" @click="exportExcel()">
				导出</el-button>
		</div>
		<div>
			<el-table ref="multipleTable" :data="freeCarList" tooltip-effect="dark"
				 @selection-change="handleSelectionChange" id="outExcel">
				<el-table-column type="selection" width="55">
				</el-table-column>
				<el-table-column label="车牌号" width="250">
					<template slot-scope="scope">{{ scope.row.car_num }}</template>
				</el-table-column>
				<el-table-column prop="car_model" label="车辆型号" width="300">
				</el-table-column>
				<el-table-column prop="department" label="部门" width="250">
				</el-table-column>
				<el-table-column prop="situation" label="状态" width="250">
				</el-table-column>
			</el-table>
		</div>

		<!--分页控件 -->
		<div class="block" style="justify-content: center; padding-bottom: 10px;">
			<el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
				:current-page="currentPage" :page-sizes="[5,10]" :page-size="pageSize"
				layout="total, sizes, prev, pager, next, jumper" :total="freeCar.length">
			</el-pagination>
		</div>

		<el-dialog title="借车信息" :visible.sync="dialogFormVisible">
			<el-form :model="borrowCar" :rules="rules" ref="borrowCar" label-width="80px" class="demo-ruleForm">
				<el-form-item label="员工工号" prop="job_num">
					<el-input v-model="borrowCar.job_num"></el-input>
				</el-form-item>

				<el-form-item label="开始时间" required>
					<el-col :span="11">
						<el-form-item prop="borrow_time">
							<el-date-picker type="date" placeholder="选择日期" v-model="borrowCar.borrow_time"
								style="width: 100%;"></el-date-picker>
						</el-form-item>
					</el-col>
				</el-form-item>
				<el-form-item label="结束时间" required>
					<el-col :span="11">
						<el-form-item prop="return_time">
							<el-date-picker type="date" placeholder="选择日期" v-model="borrowCar.return_time"
								style="width: 100%;"></el-date-picker>
						</el-form-item>
					</el-col>
				</el-form-item>

				<el-form-item label="借用原因" prop="use_reason">
					<el-input type="textarea" v-model="borrowCar.use_reason"></el-input>
				</el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click="reset">取消借车</el-button>
				<el-button :plain="true" type="primary" @click="borrow('borrowCar')">确定借车</el-button>
			</div>
		</el-dialog>
	</div>
</template>
<script>
	export default {
		inject: ['reload'], //页面刷新
		created() {
			let that = this
			this.$axios({
				method: 'get',
				url: 'http://localhost:8888/CarMsg/showByState?situation=' + '空闲中',

			}).then(function(res) {
				console.log(res)
				that.freeCar = res.data
				that.freeCarList = that.freeCar.slice(0, that.pageSize);
			})
		},
		data() {
			return {
				freeCarList: [],
				currentPage: 1,
				pageSize: 5,

				freeCar: [],

				multipleSelection: [],
				dialogFormVisible: false,
				form: {
					name: '',
					region: '',
					date1: '',
					date2: '',
					delivery: false,
					type: [],
					resource: '',
					desc: ''
				},
				formLabelWidth: '120px',
				borrowCar: {
					job_num: '',
					car_num: '',
					really_time: '',
					return_time: '',
					borrow_time: '',
					use_reason: '',
					// staffname:'',
				},
				rules: {
					job_num: [{
							required: true,
							message: '请输入员工工号',
							trigger: 'blur'
						},
						//{ min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
					],
					borrow_time: [{
						type: 'date',
						required: true,
						message: '请选择日期',
						trigger: 'change'
					}],
					return_time: [{
						type: 'date',
						required: true,
						message: '请选择日期',
						trigger: 'change'
					}],
					use_reason: [{
						required: true,
						message: '请填写借用原因',
						trigger: 'blur'
					}]
				}

			}
		},

		methods: {
			exportExcel: function() {
				let tables = document.querySelector("#outExcel") //根据id选取到要导出的表格
				let table_book = this.$XLSX.utils.table_to_book(tables)
				let table_write = this.$XLSX.write(table_book, {
					bookType: "xlsx",
					bookSST: true,
					type: "array"
				})
				try {
					this.$FileSaver.saveAs(new Blob([table_write], {
						type: "application/octet-stream"
					}), "freeCarMsg.xlsx")
				} catch (e) {
					console.log(e, table_write)
				}
				return table_write
			},
			//每页条数切换
			handleSizeChange(pageSize) {
				this.pageSize = pageSize;
				this.handleCurrentChange(this.currentPage);
			},
			//页码切换
			handleCurrentChange(currentPage) {
				this.currentPage = currentPage;
				this.currentChangePage(this.freeCar, currentPage);
			},
			//分页实现
			currentChangePage(list, currentPage) {
				let from = (currentPage - 1) * this.pageSize;
				let to = currentPage * this.pageSize;
				this.freeCarList = this.freeCar.slice(from, to);
			},

			handleSelectionChange(val) {
				this.multipleSelection = val;
			},
			//查看存入选中的车辆信息
			selectCar() {
				this.dialogFormVisible = true
				console.log('这是mul选择的车辆：', this.multipleSelection)
			},
			//确认借车
			borrow(formName) {
				this.$refs[formName].validate((valid) => {
					if (valid) {
						alert('submit!');
						let that = this
						// console.log(that.borrowCar)
						for (var i = 0; i < that.multipleSelection.length; i++) {
							// this.$router.push('borrowMsg')
							that.borrowCar.car_num = that.multipleSelection[i].car_num
							console.log('这是borrowCar信息：', that.borrowCar)
							this.$axios({
								method: 'post',
								url: 'http://localhost:8888/CarRecord/addCarRecord',
								data: that.borrowCar
							}).then(function(res) {
								console.log(res)

							})
							that.dialogFormVisible = false

							that.reload() //刷新

							that.$message({
								showClose: true,
								message: '借车成功',
								type: 'success'
							})
						}
					} else {
						console.log('error submit!!');
						return false;
					}
				});
			},


			//取消借车
			reset() {
				let that = this
				that.dialogFormVisible = false
			}

		}
	}
</script>
