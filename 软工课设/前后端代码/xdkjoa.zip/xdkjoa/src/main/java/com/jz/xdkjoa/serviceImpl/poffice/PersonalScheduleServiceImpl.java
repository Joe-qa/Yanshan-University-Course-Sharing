package com.jz.xdkjoa.serviceImpl.poffice;

import com.jz.xdkjoa.mapper.poffice.PersonalScheduleMapper;
import com.jz.xdkjoa.pojo.administration.BusinessCalendar;
import com.jz.xdkjoa.pojo.poffice.PersonalSchedule;
import com.jz.xdkjoa.service.poffice.PersonalScheduleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.xml.ws.Response;
import java.security.acl.LastOwnerException;
import java.util.List;

@Service
public class PersonalScheduleServiceImpl implements PersonalScheduleService {

    @Autowired(required = false)
    PersonalScheduleMapper personalScheduleMapper;

    public List<PersonalSchedule> showPersonalScheduleBiz(Integer job_num, String schedule_type) {
        return personalScheduleMapper.showPersonalSchedule(job_num, schedule_type);
    }

    public void addPersonalScheduleBiz(PersonalSchedule personalSchedule) {
        personalScheduleMapper.addPersonalSchedule(personalSchedule);
    }

    public void updatePersonalScheduleBiz(PersonalSchedule personalSchedule) {
        personalScheduleMapper.updatePersonalSchedule(personalSchedule);
    }

    public void delPersonalScheduleBiz(Integer schedule_id) {
        personalScheduleMapper.delPersonalSchedule(schedule_id);
    }

    @Override
    public List<PersonalSchedule> showBusinessScheduleBiz(Integer job_num) {
        return personalScheduleMapper.showBusinessSchedule(job_num);
    }

    @Override
    public List<Integer> showDepartNumBiz(Integer job_num) {
        return personalScheduleMapper.showDepartNum(job_num);
    }

    @Override
    public List<BusinessCalendar> showBusinessCalendarBiz(Integer depart_num) {
        return personalScheduleMapper.showBusinessCalendar(depart_num);
    }
}
