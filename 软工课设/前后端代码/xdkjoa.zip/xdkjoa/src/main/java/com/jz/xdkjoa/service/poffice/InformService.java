package com.jz.xdkjoa.service.poffice;

import com.jz.xdkjoa.pojo.poffice.Inform;

import java.util.List;

public interface InformService {
    List<Inform> showInformByStateBiz(Integer job_num, String inform_state, String inform_type_name);
    void updateInformBiz(Inform inform);
    void delInformBiz(int news_id);
    void addInformBiz(Inform inform);
}
