package com.jz.xdkjoa.serviceImpl.pmanagement;

import com.jz.xdkjoa.mapper.pmanagement.JobMapper;
import com.jz.xdkjoa.pojo.pmanagement.Job;
import com.jz.xdkjoa.service.pmanagement.JobService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class JobServiceImpl implements JobService {

    @Autowired(required = false)
    JobMapper jobmapper=null;

    @Override
    public void addJobBiz(Job job) {
        jobmapper.addJob(job);
    }

    @Override
    public Job showJobByNameBiz(String post_name) {
        return jobmapper.showJobByName(post_name);
    }

    @Override
    public void updateJobBiz(Job job) {
        jobmapper.updateJob(job);
    }

    @Override
    public void delJobBiz(Integer post_num) {
         jobmapper.delJob(post_num);
    }

    @Override
    public List<Job> showJobBiz() {
        return jobmapper.showJob();
    }
}
