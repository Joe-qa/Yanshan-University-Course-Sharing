package com.jz.xdkjoa.pojo.pmanagement;

public class Job {
    private int post_num;
    private String post_name;
    private String post_type;
    private int post_level;
    private String super_post;
    private String responsibilities;
    private String entry_requirement;
    private String  post_overview;
    private int vacation;

    public Job() {
    }

    public Job(int post_num, String post_name, String post_type, int post_level, String super_post, String  responsibilities, String entry_requirement, String post_overview, int vacation) {
        this.post_num = post_num;
        this.post_name = post_name;
        this.post_type = post_type;
        this.post_level = post_level;
        this.super_post = super_post;
        this.responsibilities = responsibilities;
        this.entry_requirement = entry_requirement;
        this.post_overview = post_overview;
        this.vacation = vacation;
    }

    @Override
    public String toString() {
        return "Job{" +
                "post_num=" + post_num +
                ", post_name='" + post_name + '\'' +
                ", post_type='" + post_type + '\'' +
                ", post_level=" + post_level +
                ", super_post='" + super_post + '\'' +
                ", responsibilities=" + responsibilities +
                ", entry_requirement=" + entry_requirement +
                ", post_overview=" + post_overview +
                ", vacation=" + vacation +
                '}';
    }

    public int getPost_num() {
        return post_num;
    }

    public void setPost_num(int post_num) {
        this.post_num = post_num;
    }

    public String getPost_name() {
        return post_name;
    }

    public void setPost_name(String post_name) {
        this.post_name = post_name;
    }

    public String getPost_type() {
        return post_type;
    }

    public void setPost_type(String post_type) {
        this.post_type = post_type;
    }

    public int getPost_level() {
        return post_level;
    }

    public void setPost_level(int post_level) {
        this.post_level = post_level;
    }

    public String getSuper_post() {
        return super_post;
    }

    public void setSuper_post(String super_post) {
        this.super_post = super_post;
    }

    public String getResponsibilities() {
        return responsibilities;
    }

    public void setResponsibilities(String responsibilities) {
        this.responsibilities = responsibilities;
    }

    public String getEntry_requirement() {
        return entry_requirement;
    }

    public void setEntry_requirement(String entry_requirement) {
        this.entry_requirement = entry_requirement;
    }

    public String getPost_overview() {
        return post_overview;
    }

    public void setPost_overview(String post_overview) {
        this.post_overview = post_overview;
    }

    public int getVacation() {
        return vacation;
    }

    public void setVacation(int vacation) {
        this.vacation = vacation;
    }
}
