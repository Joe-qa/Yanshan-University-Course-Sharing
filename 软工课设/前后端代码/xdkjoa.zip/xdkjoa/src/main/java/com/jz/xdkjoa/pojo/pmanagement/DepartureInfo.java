package com.jz.xdkjoa.pojo.pmanagement;

import java.util.Date;

public class DepartureInfo {
    int departure_num;
    int job_num;
    Date departure_time;
    String departure_type;
    String departure_cause;
    String transactor;
    Date trans_time;

    public DepartureInfo() {
    }

    public DepartureInfo(int departure_num, int job_num, Date departure_time, String departure_type, String departure_cause, String transactor, Date trans_time) {
        this.departure_num = departure_num;
        this.job_num = job_num;
        this.departure_time = departure_time;
        this.departure_type = departure_type;
        this.departure_cause = departure_cause;
        this.transactor = transactor;
        this.trans_time = trans_time;
    }

    public int getDeparture_num() {
        return departure_num;
    }

    public void setDeparture_num(int departure_num) {
        this.departure_num = departure_num;
    }

    public int getJob_num() {
        return job_num;
    }

    public void setJob_num(int job_num) {
        this.job_num = job_num;
    }

    public Date getDeparture_time() {
        return departure_time;
    }

    public void setDeparture_time(Date departure_time) {
        this.departure_time = departure_time;
    }

    public String getDeparture_type() {
        return departure_type;
    }

    public void setDeparture_type(String departure_type) {
        this.departure_type = departure_type;
    }

    public String getDeparture_cause() {
        return departure_cause;
    }

    public void setDeparture_cause(String departure_cause) {
        this.departure_cause = departure_cause;
    }

    public String getTransactor() {
        return transactor;
    }

    public void setTransactor(String transactor) {
        this.transactor = transactor;
    }

    public Date getTrans_time() {
        return trans_time;
    }

    public void setTrans_time(Date trans_time) {
        this.trans_time = trans_time;
    }

    @Override
    public String toString() {
        return "Departure_info{" +
                "departure_num=" + departure_num +
                ", job_num=" + job_num +
                ", departure_time=" + departure_time +
                ", departure_type='" + departure_type + '\'' +
                ", departure_cause='" + departure_cause + '\'' +
                ", transactor='" + transactor + '\'' +
                ", trans_time=" + trans_time +
                '}';
    }
}
