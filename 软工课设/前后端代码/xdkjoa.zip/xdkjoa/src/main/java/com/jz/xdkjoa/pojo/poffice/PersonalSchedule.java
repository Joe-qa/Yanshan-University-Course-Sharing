package com.jz.xdkjoa.pojo.poffice;


import com.jz.xdkjoa.pojo.administration.BusinessCalendar;
import com.jz.xdkjoa.pojo.pmanagement.Staff;

import java.sql.Date;
import java.sql.Time;


public class PersonalSchedule {
    private int schedule_id;
    private String schedule_name;

    private String schedule_type;

    private String start_time;
    private Date schedule_date;

    private String schedule_content;
    private String concrete_schedulecontent;
    private Boolean delay;
    private int job_num;
    private int process;
    private String schedule_state;
    private String schedule_process;

    private String ask_endtime;
    private String fact_endtime;
    private String remind_type;

    private BusinessCalendar businessCalendar;

    public BusinessCalendar getBusinessCalendar() {
        return businessCalendar;
    }

    public void setBusinessCalendar(BusinessCalendar businessCalendar) {
        this.businessCalendar = businessCalendar;
    }

    @Override
    public String toString() {
        return "PersonalSchedule{" +
                "schedule_id=" + schedule_id +
                ", schedule_name='" + schedule_name + '\'' +
                ", schedule_type='" + schedule_type + '\'' +
                ", start_time='" + start_time + '\'' +
                ", schedule_date=" + schedule_date +
                ", schedule_content='" + schedule_content + '\'' +
                ", concrete_schedulecontent='" + concrete_schedulecontent + '\'' +
                ", delay=" + delay +
                ", job_num=" + job_num +
                ", process=" + process +
                ", schedule_state='" + schedule_state + '\'' +
                ", schedule_process='" + schedule_process + '\'' +
                ", ask_endtime='" + ask_endtime + '\'' +
                ", fact_endtime='" + fact_endtime + '\'' +
                ", remind_type='" + remind_type + '\'' +
                ", staff=" + staff +
                '}';
    }

    public PersonalSchedule(int schedule_id, String schedule_name, String schedule_type, String start_time, Date schedule_date, String schedule_content, String concrete_schedulecontent, Boolean delay, int job_num, int process, String schedule_state, String schedule_process, String ask_endtime, String fact_endtime, String remind_type, Staff staff) {
        this.schedule_id = schedule_id;
        this.schedule_name = schedule_name;
        this.schedule_type = schedule_type;
        this.start_time = start_time;
        this.schedule_date = schedule_date;
        this.schedule_content = schedule_content;
        this.concrete_schedulecontent = concrete_schedulecontent;
        this.delay = delay;
        this.job_num = job_num;
        this.process = process;
        this.schedule_state = schedule_state;
        this.schedule_process = schedule_process;
        this.ask_endtime = ask_endtime;
        this.fact_endtime = fact_endtime;
        this.remind_type = remind_type;
        this.staff = staff;
    }

    public String getRemind_type() {
        return remind_type;
    }

    public void setRemind_type(String remind_type) {
        this.remind_type = remind_type;
    }

    public void setStart_time(String start_time) {
        this.start_time = start_time;
    }

    public void setAsk_endtime(String ask_endtime) {
        this.ask_endtime = ask_endtime;
    }

    public void setFact_endtime(String fact_endtime) {
        this.fact_endtime = fact_endtime;
    }

    public int getSchedule_id() {
        return schedule_id;
    }

    public int getProcess() {
        return process;
    }

    public void setProcess(int process) {
        this.process = process;
    }

    private Staff staff;

    public Staff getStaff() {
        return staff;
    }

    public void setStaff(Staff staff) {
        this.staff = staff;
    }


    public PersonalSchedule() {
    }

    public void setSchedule_id(int schedule_id) {
        this.schedule_id = schedule_id;
    }


    public String getSchedule_state() {
        return schedule_state;
    }

    public void setSchedule_state(String schedule_state) {
        this.schedule_state = schedule_state;
    }

    public String getSchedule_process() {
        return schedule_process;
    }

    public void setSchedule_process(String schedule_process) {
        this.schedule_process = schedule_process;
    }
    public String getSchedule_name() {
        return schedule_name;
    }

    public void setSchedule_name(String schedule_name) {
        this.schedule_name = schedule_name;
    }

    public String getSchedule_type() {
        return schedule_type;
    }

    public void setSchedule_type(String schedule_type) {
        this.schedule_type = schedule_type;
    }


    public Date getSchedule_date() {
        return schedule_date;
    }

    public void setSchedule_date(Date schedule_date) {
        this.schedule_date = schedule_date;
    }
    public String getSchedule_content() {
        return schedule_content;
    }

    public void setSchedule_content(String schedule_content) {
        this.schedule_content = schedule_content;
    }

    public String getStart_time() {
        return start_time;
    }

    public String getAsk_endtime() {
        return ask_endtime;
    }

    public String getFact_endtime() {
        return fact_endtime;
    }

    public String getConcrete_schedulecontent() {
        return concrete_schedulecontent;
    }

    public void setConcrete_schedulecontent(String concrete_schedulecontent) {
        this.concrete_schedulecontent = concrete_schedulecontent;
    }

    public Boolean getDelay() {
        return delay;
    }

    public void setDelay(Boolean delay) {
        this.delay = delay;
    }

    public int getJob_num() {
        return job_num;
    }

    public void setJob_num(int job_num) {
        this.job_num = job_num;
    }


}
