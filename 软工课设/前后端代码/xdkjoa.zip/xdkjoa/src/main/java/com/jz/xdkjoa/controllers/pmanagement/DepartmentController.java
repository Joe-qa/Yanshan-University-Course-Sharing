package com.jz.xdkjoa.controllers.pmanagement;


import com.jz.xdkjoa.service.pmanagement.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/department")
public class DepartmentController {
    @Autowired(required = false)
    DepartmentService departmentService;

    @GetMapping("/querybynum")
    public  String queryByNum(Integer depart_num){
        return departmentService.findNameByNumBiz(depart_num);
    }

    @PostMapping("/showalldepartments")
    public List showAllDepartmentsBiz(){
        return departmentService.showAllDepartmentsBiz();
    }

}
