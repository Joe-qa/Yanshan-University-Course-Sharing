﻿namespace U_disk_Mange
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.DISKcombox = new System.Windows.Forms.ComboBox();
            this.U_diskinfo = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.totalSpace = new System.Windows.Forms.Label();
            this.usedSpace = new System.Windows.Forms.Label();
            this.freeSpace = new System.Windows.Forms.Label();
            this.fromBtn = new System.Windows.Forms.Button();
            this.toBtn = new System.Windows.Forms.Button();
            this.fromtextBox = new System.Windows.Forms.TextBox();
            this.totextBox = new System.Windows.Forms.TextBox();
            this.delBtn = new System.Windows.Forms.Button();
            this.copyBtn = new System.Windows.Forms.Button();
            this.forbiddenDisk = new System.Windows.Forms.Button();
            this.openDisk = new System.Windows.Forms.Button();
            this.GetprocessBtn = new System.Windows.Forms.Button();
            this.deltextBox = new System.Windows.Forms.TextBox();
            this.delfileBtn = new System.Windows.Forms.Button();
            this.select = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // DISKcombox
            // 
            this.DISKcombox.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.DISKcombox.FormattingEnabled = true;
            this.DISKcombox.Location = new System.Drawing.Point(142, 97);
            this.DISKcombox.Name = "DISKcombox";
            this.DISKcombox.Size = new System.Drawing.Size(128, 31);
            this.DISKcombox.TabIndex = 0;
            this.DISKcombox.SelectedIndexChanged += new System.EventHandler(this.DISKcombox_SelectedIndexChanged);
            // 
            // U_diskinfo
            // 
            this.U_diskinfo.AutoSize = true;
            this.U_diskinfo.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.U_diskinfo.Location = new System.Drawing.Point(34, 26);
            this.U_diskinfo.Name = "U_diskinfo";
            this.U_diskinfo.Size = new System.Drawing.Size(0, 24);
            this.U_diskinfo.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(34, 141);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 24);
            this.label1.TabIndex = 2;
            this.label1.Text = "总空间";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(34, 188);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 24);
            this.label2.TabIndex = 3;
            this.label2.Text = "使用空间";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(34, 229);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(110, 24);
            this.label3.TabIndex = 4;
            this.label3.Text = "剩余空间";
            // 
            // totalSpace
            // 
            this.totalSpace.AutoSize = true;
            this.totalSpace.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.totalSpace.Location = new System.Drawing.Point(159, 141);
            this.totalSpace.Name = "totalSpace";
            this.totalSpace.Size = new System.Drawing.Size(0, 24);
            this.totalSpace.TabIndex = 5;
            // 
            // usedSpace
            // 
            this.usedSpace.AutoSize = true;
            this.usedSpace.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.usedSpace.Location = new System.Drawing.Point(159, 188);
            this.usedSpace.Name = "usedSpace";
            this.usedSpace.Size = new System.Drawing.Size(0, 24);
            this.usedSpace.TabIndex = 6;
            // 
            // freeSpace
            // 
            this.freeSpace.AutoSize = true;
            this.freeSpace.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.freeSpace.Location = new System.Drawing.Point(159, 229);
            this.freeSpace.Name = "freeSpace";
            this.freeSpace.Size = new System.Drawing.Size(0, 24);
            this.freeSpace.TabIndex = 7;
            // 
            // fromBtn
            // 
            this.fromBtn.Font = new System.Drawing.Font("宋体", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.fromBtn.Location = new System.Drawing.Point(592, 103);
            this.fromBtn.Name = "fromBtn";
            this.fromBtn.Size = new System.Drawing.Size(235, 43);
            this.fromBtn.TabIndex = 8;
            this.fromBtn.Text = "选择复制的目录或文件";
            this.fromBtn.UseVisualStyleBackColor = true;
            this.fromBtn.Click += new System.EventHandler(this.dirBtn_Click);
            // 
            // toBtn
            // 
            this.toBtn.Font = new System.Drawing.Font("宋体", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.toBtn.Location = new System.Drawing.Point(592, 216);
            this.toBtn.Name = "toBtn";
            this.toBtn.Size = new System.Drawing.Size(226, 49);
            this.toBtn.TabIndex = 9;
            this.toBtn.Text = "选择复制到的位置";
            this.toBtn.UseVisualStyleBackColor = true;
            this.toBtn.Click += new System.EventHandler(this.fileBtn_Click);
            // 
            // fromtextBox
            // 
            this.fromtextBox.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.fromtextBox.Location = new System.Drawing.Point(324, 114);
            this.fromtextBox.Name = "fromtextBox";
            this.fromtextBox.Size = new System.Drawing.Size(250, 25);
            this.fromtextBox.TabIndex = 10;
            // 
            // totextBox
            // 
            this.totextBox.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.totextBox.Location = new System.Drawing.Point(324, 228);
            this.totextBox.Name = "totextBox";
            this.totextBox.Size = new System.Drawing.Size(250, 25);
            this.totextBox.TabIndex = 11;
            // 
            // delBtn
            // 
            this.delBtn.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.delBtn.Location = new System.Drawing.Point(928, 285);
            this.delBtn.Name = "delBtn";
            this.delBtn.Size = new System.Drawing.Size(148, 58);
            this.delBtn.TabIndex = 12;
            this.delBtn.Text = "删除文件";
            this.delBtn.UseVisualStyleBackColor = true;
            this.delBtn.Click += new System.EventHandler(this.delBtn_Click);
            // 
            // copyBtn
            // 
            this.copyBtn.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.copyBtn.Location = new System.Drawing.Point(928, 141);
            this.copyBtn.Name = "copyBtn";
            this.copyBtn.Size = new System.Drawing.Size(148, 60);
            this.copyBtn.TabIndex = 13;
            this.copyBtn.Text = "复制文件";
            this.copyBtn.UseVisualStyleBackColor = true;
            this.copyBtn.Click += new System.EventHandler(this.copyBtn_Click);
            // 
            // forbiddenDisk
            // 
            this.forbiddenDisk.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.forbiddenDisk.Location = new System.Drawing.Point(123, 418);
            this.forbiddenDisk.Name = "forbiddenDisk";
            this.forbiddenDisk.Size = new System.Drawing.Size(147, 58);
            this.forbiddenDisk.TabIndex = 14;
            this.forbiddenDisk.Text = "禁用U盘";
            this.forbiddenDisk.UseVisualStyleBackColor = true;
            this.forbiddenDisk.Click += new System.EventHandler(this.button1_Click);
            // 
            // openDisk
            // 
            this.openDisk.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.openDisk.Location = new System.Drawing.Point(300, 418);
            this.openDisk.Name = "openDisk";
            this.openDisk.Size = new System.Drawing.Size(150, 58);
            this.openDisk.TabIndex = 15;
            this.openDisk.Text = "开启U盘";
            this.openDisk.UseVisualStyleBackColor = true;
            this.openDisk.Click += new System.EventHandler(this.openDisk_Click);
            // 
            // GetprocessBtn
            // 
            this.GetprocessBtn.Font = new System.Drawing.Font("宋体", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.GetprocessBtn.Location = new System.Drawing.Point(592, 418);
            this.GetprocessBtn.Name = "GetprocessBtn";
            this.GetprocessBtn.Size = new System.Drawing.Size(205, 58);
            this.GetprocessBtn.TabIndex = 16;
            this.GetprocessBtn.Text = "获取进程ID";
            this.GetprocessBtn.UseVisualStyleBackColor = true;
            this.GetprocessBtn.Click += new System.EventHandler(this.button3_Click);
            // 
            // deltextBox
            // 
            this.deltextBox.Font = new System.Drawing.Font("宋体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.deltextBox.Location = new System.Drawing.Point(324, 315);
            this.deltextBox.Name = "deltextBox";
            this.deltextBox.Size = new System.Drawing.Size(250, 28);
            this.deltextBox.TabIndex = 18;
            // 
            // delfileBtn
            // 
            this.delfileBtn.Font = new System.Drawing.Font("宋体", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.delfileBtn.Location = new System.Drawing.Point(592, 307);
            this.delfileBtn.Name = "delfileBtn";
            this.delfileBtn.Size = new System.Drawing.Size(226, 54);
            this.delfileBtn.TabIndex = 19;
            this.delfileBtn.Text = "选择删除的文件";
            this.delfileBtn.UseVisualStyleBackColor = true;
            this.delfileBtn.Click += new System.EventHandler(this.delfileBtn_Click);
            // 
            // select
            // 
            this.select.Font = new System.Drawing.Font("微软雅黑", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.select.FormattingEnabled = true;
            this.select.Location = new System.Drawing.Point(478, 42);
            this.select.Name = "select";
            this.select.Size = new System.Drawing.Size(283, 39);
            this.select.TabIndex = 20;
            this.select.SelectedIndexChanged += new System.EventHandler(this.select_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1170, 563);
            this.Controls.Add(this.select);
            this.Controls.Add(this.delfileBtn);
            this.Controls.Add(this.deltextBox);
            this.Controls.Add(this.GetprocessBtn);
            this.Controls.Add(this.openDisk);
            this.Controls.Add(this.forbiddenDisk);
            this.Controls.Add(this.copyBtn);
            this.Controls.Add(this.delBtn);
            this.Controls.Add(this.totextBox);
            this.Controls.Add(this.fromtextBox);
            this.Controls.Add(this.toBtn);
            this.Controls.Add(this.fromBtn);
            this.Controls.Add(this.freeSpace);
            this.Controls.Add(this.usedSpace);
            this.Controls.Add(this.totalSpace);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.U_diskinfo);
            this.Controls.Add(this.DISKcombox);
            this.Name = "Form1";
            this.Text = "U_disk_manage";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox DISKcombox;
        private System.Windows.Forms.Label U_diskinfo;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label totalSpace;
        private System.Windows.Forms.Label usedSpace;
        private System.Windows.Forms.Label freeSpace;
        private System.Windows.Forms.Button fromBtn;
        private System.Windows.Forms.Button toBtn;
        private System.Windows.Forms.TextBox fromtextBox;
        private System.Windows.Forms.TextBox totextBox;
        private System.Windows.Forms.Button delBtn;
        private System.Windows.Forms.Button copyBtn;
        private System.Windows.Forms.Button forbiddenDisk;
        private System.Windows.Forms.Button openDisk;
        private System.Windows.Forms.Button GetprocessBtn;
        private System.Windows.Forms.TextBox deltextBox;
        private System.Windows.Forms.Button delfileBtn;
        private System.Windows.Forms.ComboBox select;
    }
}

