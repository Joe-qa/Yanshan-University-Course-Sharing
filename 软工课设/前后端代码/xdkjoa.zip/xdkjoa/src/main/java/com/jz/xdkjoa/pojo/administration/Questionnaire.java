package com.jz.xdkjoa.pojo.administration;

import java.util.Date;

public class Questionnaire{
    private int questionnaire_num;
    private  int job_num;
    private  String questionnairheadline;
    private  String questionnairdetail;
    private Date questionnaire_time;

    public Questionnaire(int questionnaire_num, int job_num, String questionnairheadline, String questionnairdetail, Date questionnaire_time) {
        this.questionnaire_num = questionnaire_num;
        this.job_num = job_num;
        this.questionnairheadline = questionnairheadline;
        this.questionnairdetail = questionnairdetail;
        this.questionnaire_time = questionnaire_time;
    }
    public Questionnaire(){}

    public int getQuestionnaire_num() {
        return questionnaire_num;
    }

    public void setQuestionnaire_num(int questionnaire_num) {
        this.questionnaire_num = questionnaire_num;
    }

    public int getJob_num() {
        return job_num;
    }

    public void setJob_num(int job_num) {
        this.job_num = job_num;
    }

    public String getQuestionnairheadline() {
        return questionnairheadline;
    }

    public void setQuestionnairheadline(String questionnairheadline) {
        this.questionnairheadline = questionnairheadline;
    }

    public String getQuestionnairdetail() {
        return questionnairdetail;
    }

    public void setQuestionnairdetail(String questionnairdetail) {
        this.questionnairdetail = questionnairdetail;
    }

    public Date getQuestionnaire_time() {
        return questionnaire_time;
    }

    public void setQuestionnaire_time(Date questionnaire_time) {
        this.questionnaire_time = questionnaire_time;
    }

    @Override
    public String toString() {
        return "Questionnaire{" +
                "questionnaire_num=" + questionnaire_num +
                ", job_num=" + job_num +
                ", questionnairheadline='" + questionnairheadline + '\'' +
                ", questionnairdetail='" + questionnairdetail + '\'' +
                ", questionnaire_time=" + questionnaire_time +
                '}';
    }
}
