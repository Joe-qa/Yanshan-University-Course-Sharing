package com.jz.xdkjoa.controllers.poffice;

import com.jz.xdkjoa.pojo.poffice.Inform;
import com.jz.xdkjoa.service.poffice.InformService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.sql.Date;
import java.sql.Time;
import java.util.List;

//允许穿越
@CrossOrigin
@RestController

@RequestMapping("/inform")
public class InformController {

    @Autowired(required = false)
    InformService informService;

    @GetMapping("showinform")
    public List showInformByState(Integer job_num,String inform_state,String inform_type_name)
    {

        List<Inform> list=informService.showInformByStateBiz(job_num,inform_state,inform_type_name);
 //       System.out.println(list.size()+">>>>>>>>>>>>>>>>>>>>...");

        return list;
    }

    @PostMapping("updateinform")
    public String updateInform(@RequestBody Inform inform)
    {
        informService.updateInformBiz(inform);
        return "0000";
    }

    @PostMapping("delinform")
    public String delInform(@RequestParam int news_id)
    {
        informService.delInformBiz(news_id);
        return "000";
    }


    @PostMapping("addinform")
    public String addInform( @RequestBody  Inform inform){
        System.out.println(inform);
        informService.addInformBiz(inform);
        return "success";
    }
}
