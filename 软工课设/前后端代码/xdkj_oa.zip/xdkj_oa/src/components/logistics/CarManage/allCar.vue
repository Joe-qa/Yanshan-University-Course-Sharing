<template>
	<div>

		<div style="display: flex;flex-direction: column;align-items: center;">

			<div style="display: flex;flex-direction: row;height: 50px;width: 100%;">

				<div style="margin-left: 10px;">
					<el-button type="primary" icon="el-icon-upload" @click="exportExcel()">
						导出</el-button>
				</div>
				<!-- <download-excel :data="json_data" :fields="json_fields" name="车辆信息表"> 导出</download-excel> -->
				<div style="margin-left: 700px;">
					<el-input v-model="input" placeholder="请输入内容" style="width: 180px;"></el-input>
					<el-button @click="search" type="primary" icon="el-icon-search" style="margin-left:10px ;">搜索
					</el-button>
				</div>

			</div>
			<div>
				<el-table ref="multipleTable" :data="CarMsgList" tooltip-effect="dark" style="width: 100%"
					@selection-change="handleSelectionChange"  id="outExcel">

					<!-- <el-table-column prop="date" label="编号" width="120">
			</el-table-column> -->
					<el-table-column prop="car_num" label="车牌号" width="200">
					</el-table-column>
					<el-table-column prop="car_model" label="车辆型号" width="200">
					</el-table-column>
					<el-table-column prop="department" label="部门" width="200">
					</el-table-column>
					<el-table-column prop="situation" label="状态" width="200">
					</el-table-column>
					<el-table-column label="操作" width="200">
						<template slot-scope="scope">
							<el-button @click="handleClick(scope.row)" type="text" size="small">查看历史记录</el-button>
						</template>
					</el-table-column>
				</el-table>
			</div>

		</div>
		<!--分页控件 -->
		<div class="block" style="justify-content: center; display: flex; margin-top: 10px;">
			<el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
				:current-page="currentPage" :page-sizes="[5, 8, 10]" :page-size="pageSize"
				layout="total, sizes, prev, pager, next, jumper" :total="CarMsg.length">
			</el-pagination>
		</div>
	</div>


</template>

<script>
	export default {
		created() {
			let that = this
			this.$axios({
				method: 'post',
				url: 'http://localhost:8888/CarMsg/CarMsgList'
			}).then(function(response) {
				console.log(response.data)
				that.CarMsg = response.data
				console.log(that.CarMsg[0].car_num)
				that.CarMsgList = that.CarMsg.slice(0, that.pageSize);
			})
		},
		methods: {
			 exportExcel:function(){
			       let tables=document.querySelector("#outExcel")   //根据id选取到要导出的表格
			       let table_book=this.$XLSX.utils.table_to_book(tables)    
			       let table_write= this.$XLSX.write(table_book,{
			         bookType:"xlsx",
			         bookSST:true,
			         type:"array"
			       })
			       try{
			         this.$FileSaver.saveAs(new Blob([table_write],
			         {type:"application/octet-stream"}),"carmsg.xlsx")
			       }catch(e){
			             console.log(e,table_write)
			       }
			       return table_write
			    },
			handleClick(row) {
				this.$router.push({
					path: 'historyRecord',
					query: {
						car_num: row.car_num,
					}
				})
				console.log('这是 car_num:', row.car_num)
				sessionStorage.setItem('testKey', row.car_num)
			},
			search() {
				// alert('hahahahha')
				let that = this
				this.$axios({
					method: 'get',
					url: 'http://localhost:8888/CarMsg/showByCarNum?car_num=' + that.input
				}).then(function(res) {
					console.log(res)
					that.CarMsgList = res.data
					console.log('获取成功', that.CarMsgList)
				})

			},

			//每页条数切换
			handleSizeChange(pageSize) {
				this.pageSize = pageSize;
				this.handleCurrentChange(this.currentPage);
			},
			//页码切换
			handleCurrentChange(currentPage) {
				this.currentPage = currentPage;
				this.currentChangePage(this.CarMsg, currentPage);
			},
			//分页实现
			currentChangePage(list, currentPage) {
				let from = (currentPage - 1) * this.pageSize;
				let to = currentPage * this.pageSize;
				this.CarMsgList = this.CarMsg.slice(from, to);
			},


			// //导出文件
			// export2Excel() {

			// 	require.ensure([], () => {

			// 		const {
			// 			export_json_to_excel
			// 		} = require('vendor/Export2Excel');

			// 		const tHeader = ['车牌号', '状态', '部门', '车辆型号'

			// 		]; //创建表头

			// 		const filterVal =

			// 			['car_num', 'situation', 'department', 'car_model'

			// 			]; //这里是和表头对应的内容的字段，要和后台返回的数据的字段对应上



			// 		const list = this.CarMsg; //这是从后台拿到的数据

			// 		const data = this.formatJson(filterVal, list);

			// 		export_json_to_excel(tHeader, data, '车辆信息'); //三个参数，表头，经过排序后的数据，表格的名字

			// 	})

			// },

			// formatJson(filterVal, jsonData) {

			// 	return jsonData.map(v => filterVal.map(j => v[j]))

			// },
		},

		data() {
			return {
				input: '',
				CarMsg: [],
				CarMsgList: [],
				currentPage: 1,
				pageSize: 5,
			}
		}
	}
</script>
