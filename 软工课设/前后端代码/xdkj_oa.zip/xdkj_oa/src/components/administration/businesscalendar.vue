<template>
	<div>
		<el-calendar>
			<template slot="dateCell" slot-scope="{date, data}">
				<el-scrollbar style="height: 100%;">
					<div class="data.isSelected ? 'is-selected' : ''" @click="fun($event)">
						{{ data.day.split('-').slice(1).join('-') }}</br>
						<span style="font-size:15px" v-for="item in notice" @click="display(item.headline)">
							{{checkNotice(item,data.day)?'✔️'+item.headline:''}}
							<span v-if="checkNotice(item,data.day)"></br></span>
						</span>
					</div>
				</el-scrollbar>
			</template>
		</el-calendar>
		<el-dialog title="企业日程管理" :visible.sync="dialogFormVisible">
			<el-form :model="form" :rules="rules">
				<el-form-item label="日程主题" prop="headline" :label-width="formLabelWidth">
					<el-input v-model="form.headline" placeholder="请输入主题" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="日程描述" prop="business_describe" :label-width="formLabelWidth">
					<el-input v-model="form.business_describe" placeholder="请输入日程描述" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="选择日程时间" prop="value1" :label-width="formLabelWidth">
					<el-date-picker v-model="form.value1" type="daterange" range-separator="至" start-placeholder="开始日期"
						end-placeholder="结束日期">
					</el-date-picker>
				</el-form-item>
				<el-form-item label="选择部门" prop="depart_num" :label-width="formLabelWidth">
					<el-select v-model="form.depart_num" placeholder="请选择部门">
						<el-option v-for="(item,index) in department" :key="index" :label="item.depart_name"
							:value="item.depart_num"></el-option>
					</el-select>
				</el-form-item>
				<el-form-item label="日程重要性" prop="business_level" :label-width="formLabelWidth">
					<el-select v-model="form.business_level" placeholder="请选择日程重要性">
						<el-option label="高" value="高"></el-option>
						<el-option label="中" value="中"></el-option>
						<el-option label="低" value="低"></el-option>
					</el-select>
				</el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click="cancel($canceled)">取 消</el-button>
				<el-button v-if="v1" type="primary" @click="save()">确 定 新 增</el-button>
				<el-button v-if="v2" type="primary " @click="deleted()">确 定 删 除 </el-button>
				<el-button v-if="v3" type="primary" @click="update()">确 定 修 改</el-button>
			</div>
		</el-dialog>
	</div>
</template>

<script>
	export default {
		created() {
			let that = this
			this.$axios({
					method: 'post',
					url: 'http://localhost:8888/headline/showcalendar'
				}).then(function(response) {
					that.notice = response.data
				}),
				this.$axios({
					method: 'post',
					url: 'http://localhost:8888/department/showalldepartments'
				}).then(function(res) {
					that.department = res.data
					console.log(res.data)
				})
		},
		data() {
			return {
				department: [],
				notice: [],
				v1: "",
				v2: "",
				v3: "",
				dialogTableVisible: false,
				dialogFormVisible: false,
				form: {
					headline: '',
					business_describe: '',
					depart_num: '',
					value1: '',
					business_level: '',
					schedule_num: ''
				},
				form1: {
					headline: '',
					business_describe: '',
					depart_num: '',
					start_time: '',
					end_time: '',
					business_level: '',
					schedule_num: ''
				},
				rules: {
					headline: [{
						required: true,
						message: '请输入日程主题',
						trigger: 'blur'
					}],
					business_describe: [{
						required: true,
						message: '请输入日程描述',
						trigger: 'blur'
					}],
					value1: [{
						required: true,
						message: '请选择时间',
						trigger: 'change'
					}],
					depart_num: [{
						required: true,
						message: '请选择部门',
						trigger: 'change'
					}],
					business_level: [{
						required: true,
						message: '请选择日程重要性',
						trigger: 'change'
					}]
	
				},
				formLabelWidth: '120px'
			}
		},
		methods: {
			display(headline) {
				event.stopPropagation();
				this.v1 = false,
					this.v2 = true,
					this.v3 = true
				let that = this
				this.$axios({
					method: 'post',
					url: 'http://localhost:8888/headline/showcalendar'
				}).then(function(response) {
					for (let o in response.data) {
						if (response.data[o].headline == headline) {
							that.form.headline = headline
							that.form.business_describe = response.data[o].business_describe
							that.form.business_level = response.data[o].business_level
							that.$axios({
								method: 'get',
								url: 'http://localhost:8888/department/querybynum?depart_num=' + response
									.data[o].depart_num
							}).then(function(res) {
								that.form.depart_num = res.data
							})

							var ti = new Array(2)
							ti[0] = response.data[o].start_time
							ti[1] = response.data[o].end_time
							that.form.value1 = ti
							that.form.schedule_num = response.data[o].schedule_num
						}
					}
				})
				this.dialogFormVisible = true
			},
			deleted() {
				this.$confirm('此操作将永久删除此日程, 是否继续?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
				}).then(() => {
					let that = this
					this.$axios({
						method: 'post',
						url: 'http://localhost:8888/headline/delcalendar?schedule_num=' + this.form
							.schedule_num,
					}).then(function(res) {
						if (res.data == "success") {
							that.$message.success('删除成功')

						} else {
							that.$message.error('删除失败')
						}

					})
					this.dialogFormVisible = false
					this.timer = setTimeout(() => { //设置延迟执行
						this.$router.go(0);
					}, 1500);

				}).catch(() => {
					this.$message({
						type: 'info',
						message: '已取消删除'
					});
				});

			},
			update() {
				this.form1.headline = this.form.headline;
				this.form1.business_describe = this.form.business_describe;
				this.form1.depart_num=this.form.depart_num
				
				this.form1.start_time = this.form.value1[0];
				this.form1.end_time = this.form.value1[1];
				this.form1.business_level = this.form.business_level;
				this.form1.schedule_num = this.form.schedule_num;
				let that = this
				this.$axios({
					method: 'post',
					url: 'http://localhost:8888/headline/updatecalendar',
					data: that.form1,
				}).then(function(res) {
					console.log(res.data)
					if (res.data == 'success') {
						that.$message.success("修改成功")
					} else {
						that.$message.error('修改失败')
					}
				})
				// this.timer = setTimeout(() => { //设置延迟执行
				// 	this.$router.go(0);
				// }, 1000);
				this.dialogFormVisible = false
			},
			fun(el) {
				this.v1 = true,
					this.v2 = false,
					this.v3 = false,
					this.dialogFormVisible = true
				this.form.headline = ''
				this.form.business_describe = ''
				this.form.depart_num = ''
				this.form.value1 = ''
				this.form.business_level = ''
				let p = el.currentTarget
				let str = p.innerText.length

			},

			cancel() {
				this.dialogFormVisible = false
			},
			save() {
				this.form1.headline = this.form.headline;
				this.form1.business_describe = this.form.business_describe;
				this.form1.depart_num = this.form.depart_num;
				this.form1.start_time = this.form.value1[0];
				this.form1.end_time = this.form.value1[1];
				this.form1.business_level = this.form.business_level;

				let that = this
				this.$axios({
						method: 'post',
						url: 'http://localhost:8888/headline/addheadline',
						data: that.form1,
					}).then(function(res) {
						if (res.data == 'success')
							that.$message.success('日程新增成功')
						else
							that.$message.error('新增失败')
					}),
					this.timer = setTimeout(() => { //设置延迟执行
						this.$router.go(0);
					}, 1500);
				this.dialogFormVisible = false
			},
			checkNotice(item, dt) {
				let d = new Date(dt)
				let s = new Date(item.start_time)
				let e = new Date(item.end_time)
				const oneDay = 24 * 60 * 60 * 1000
				if (d.getTime() >= s.getTime() && d.getTime() <= (e.getTime() + oneDay)) {
					return true
				}
				return false
			},
		}
	}
</script>

<style>
	.is-selected {
		color: #1989FA;
	}

	.el-calendar-table .el-calendar-day {
		height: 60px;

	}

	.el-scrollbar__wrap {
		overflow-x: hidden;
	}
</style>
