package com.jz.xdkjoa.service.pmanagement;

import com.jz.xdkjoa.pojo.pmanagement.RightMap;

import java.util.List;

public interface RightMapService {
    List<RightMap> findRightBiz(String account);
}
