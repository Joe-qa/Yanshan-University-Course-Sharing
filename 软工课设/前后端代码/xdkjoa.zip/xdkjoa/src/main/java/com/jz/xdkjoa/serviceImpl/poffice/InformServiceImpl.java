package com.jz.xdkjoa.serviceImpl.poffice;

import com.jz.xdkjoa.mapper.poffice.InformMapper;
import com.jz.xdkjoa.pojo.poffice.Inform;
import com.jz.xdkjoa.service.poffice.InformService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InformServiceImpl implements InformService {

    @Autowired(required = false)
    InformMapper informmapper;


    public List<Inform> showInformByStateBiz(Integer job_num, String inform_state, String inform_type_name) {
        return informmapper.showInformByState(job_num,inform_state,inform_type_name);
    }


    public void updateInformBiz(Inform inform) {
        informmapper.updateInform(inform);
    }

    public void delInformBiz(int news_id) {
        informmapper.delInform(news_id);
    }
    public void addInformBiz(Inform inform){informmapper.addInfrom(inform);}
}
