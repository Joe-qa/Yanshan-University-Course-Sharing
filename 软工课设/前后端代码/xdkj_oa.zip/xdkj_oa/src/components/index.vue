<template>
	<div>
		<el-container>
			<el-aside style="width: 225px">
				<el-menu  class="el-menu-vertical-demo" @open="handleOpen" @close="handleClose"
					:collapse="isCollapse" background-color="#263238" text-color="#ffffff" style="height: 100vh;">

					<el-submenu v-for="(item,index) in view" :key="index" :index=item.index>
						<span class="el-icon-menu" slot="title">{{item.title}}</span>
						<el-menu-item v-for="(item1,index1) in item.children" :key="index1"
							style="text-color: #FFFFFF;">
							<router-link :to="{name:item1.to}" style="text-color: #FFFFFF;">{{item1.title}}
							</router-link>
						</el-menu-item>
					</el-submenu>
				</el-menu>
			</el-aside>

			<el-container style="margin: 0;">
				<el-header>
					<el-row style="margin-top: 0px;">
						<!-- <span class="el-icon-s-fold"> -->
						<router-link :to="{name:'main'}"
							style="margin: 0 10px 0 10px; font-weight:bold; font-size: 25px;">小岛科技公司办公自动化系统
						</router-link>
						<!-- </span> -->
						<el-dropdown style="position: fixed; top:10px;right: 40px;">
							<span class="el-dropdown-link">
								<el-avatar size="medium"
									src="https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png">
								</el-avatar>
							</span>
							<el-dropdown-menu slot="dropdown">
								<el-dropdown-item icon="el-icon-user"><span @click="userinfo()">个人信息</span>
								</el-dropdown-item>
								<el-dropdown-item icon="el-icon-close"><span @click="logout()">退出系统</span>
								</el-dropdown-item>
							</el-dropdown-menu>
						</el-dropdown>
					</el-row>
				</el-header>
				<hr>
				<!-- <el-divider></el-divider> -->
				<el-main>

					<router-view></router-view>

				</el-main>
				<el-footer>
					<span
						style="position: fixed; bottom: 20px;right: 10px; margin: 20rpx;font-size: 20rpx;">{{time}}</span>
				</el-footer>
			</el-container>
		</el-container>

		<el-dialog title="用户个人信息" :visible.sync="dialogFormVisible" width="400px">
			<el-form :model="form" style="display:flex; flex-direction: column;justify-content: center;align-items: center;">
				<el-form-item prop="staff_image">
					<!-- <el-input v-model="form.staff_image" disabled autocomplete="off"></el-input> -->
					<img v-bind:src="form.staff_image" style="height: 120px;width:120px; border-radius: 50%">
				</el-form-item>
				
				<el-form-item label="员工账号" prop="account" style="display: flex;flex-direction: row;">
					<el-input v-model="form.account" disabled autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="员工姓名" prop="staff_name" style="display: flex;flex-direction: row;">
					<el-input v-model="form.staff_name" disabled autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="所属部门" prop="depart_name" style="display: flex;flex-direction: row;">
					<el-input v-model="form.depart_name" disabled autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="员工类型" prop="staff_type" style="display: flex;flex-direction: row;">
					<el-input v-model="form.staff_type" disabled autocomplete="off"></el-input>
				</el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button type="primary" @click="fun()">确 定</el-button>
			</div>
		</el-dialog>
		<el-backtop target=".page-component__scroll .el-scrollbar__wrap"></el-backtop>

	</div>
</template>

<script>
	export default {
		data() {
			return {
				isCollapse: false,
				time: '',
				showHover: false,
				dialogFormVisible: false,
				view: [],
				form: {
					job_num: '',
					depart_num: '',
					post_num: '',
					staff_name: '',
					account: '',
					staff_type: '',
					gender: '',
					nationality: '',
					nation: '',
					indentity_num: '',
					native_place: '',
					politics_status: '',
					email: '',
					staff_image: '',
					staff_tel: '',
					depart_name:''
				},
				formLabelWidth: '100px'
			};
		},
		created() {
			setInterval(() => {
				var d = new Date(),
					str = '';
				str += d.getFullYear() + '年'; //获取当前年份 
				str += d.getMonth() + 1 + '月'; //获取当前月份（0——11） 
				str += d.getDate() + '日';
				str += d.getHours() + '时';
				str += d.getMinutes() + '分';
				str += d.getSeconds() + '秒';
				this.time = str
			}, 1000);
			let that = this
			this.$axios({
				method: 'get',
				url: 'http://localhost:8888/right/findright?account=' + that.getCookie("account")
			}).then(function(res) {
				for (let o in res.data) {
					if (res.data[o].staffRight.right_content == '行政管理') {
						that.view.push({
							title: '行政管理',
							index: '1',
							children: [{
								to: 'businesscalendar',
								title: '企业日程管理',
							}, {
								to: 'contract',
								title: '合同管理',
							}, {
								to: 'sendnotice',
								title: '发送通知公告',
							}]
						})
					} else if (res.data[o].staffRight.right_content == '车辆管理') {
						that.view.push({
							title: '车辆管理',
							index: '2',
							children: [{
								to: 'allCar',
								title: '车辆信息',
							}, {
								to: 'freeCar',
								title: '空闲车辆',
							}, {
								to: 'useCar',
								title: '使用车辆'
							}]
						})
					} else if (res.data[o].staffRight.right_content == '设备管理') {
						that.view.push({
							title: '设备管理',
							index: '3',
							children: [{
								to: 'equipmentMsg',
								title: '设备信息',
							}, {
								to: 'repairRecord',
								title: '维修记录',
							}]
						})
					} else if (res.data[o].staffRight.right_content == '通知公告') {
						that.view.push({
							title: '通知公告',
							index: '4',
							children: [{
								to: 'newsaccept',
								title: '收件箱',
							}, {
								to: 'newsrubbish',
								title: '垃圾箱',
							}, {
								to: 'newscollect',
								title: '收藏'
							}]
						})
					} else if (res.data[o].staffRight.right_content == '个人日程') {
						that.view.push({
							title: '个人日程',
							index: '5',
							children: [{
								to: 'monthlook',
								title: '个人日程表',
							}, {
								to: 'weektask',
								title: '周期性任务',
							}, {
								to: 'mytask',
								title: '我的任务'
							}]
						})
					} else if (res.data[o].staffRight.right_content == '人事管理') {
						that.view.push({
							title: '人事管理',
							index: '6',
							children: [{
									to: 'showStaff',
									title: '员工管理',
								}, {
									to: 'addStaff1',
									title: '员工录入',
								}, {
									to: 'showJob',
									title: '岗位管理'
								},
								{
									to: 'departmentTree',
									title: '公司组织结构'
								}
							]
						})
					}

				}
			})
		},
		destroyed() {
			localStorage.setItem('isLogin', 'false');
		},
		methods: {
			fun() {
				this.dialogFormVisible = false;
			},
			handleOpen(key, keyPath) {
				console.log(key, keyPath);
			},
			handleClose(key, keyPath) {
				console.log(key, keyPath);
			},
			getCookie: function(key) {
				if (document.cookie.length > 0) {
					var start = document.cookie.indexOf(key + '=')
					if (start !== -1) {
						start = start + key.length + 1
						var end = document.cookie.indexOf(';', start)
						if (end === -1) end = document.cookie.length
						return unescape(document.cookie.substring(start, end))
					}
				}
				return ''
			},
			userinfo() {
				let that = this
				this.$axios({
					method: 'get',
					url: 'http://localhost:8888/staff/findStaffByAccount?account=' + that.getCookie("account")
				}).then(function(response) {
					that.form.job_num = response.data.job_num,
						that.form.depart_num = response.data.depart_num,
						that.form.post_num = response.data.post_num,
						that.form.staff_name = response.data.staff_name,
						that.form.account = response.data.account,
						that.form.staff_type = response.data.staff_type,
						that.form.gender = response.data.gender,
						that.form.nationality = response.data.nationality,
						that.form.nation = response.data.nation
					    that.form.staff_image = require("../assets/img/" + response.data.staff_image)

					// staff_name:'',
					// account:'',
					// staff_type:'',
					// gender:'',
					// nationality:'',
					// nation:'',
					// indentity_num:'',
					// native_place:'',
					// politics_status:'',
					// email:'',
					// image:'',
					// staff_tel:''
				}),
				this.$axios({
					method:'get',
					url:'http://localhost:8888/department/querybynum?depart_num='+that.form.depart_num
				}).then(function(res){
					that.form.depart_name=res.data
				})
				this.dialogFormVisible = true

			},
			logout() {
				this.$confirm('您确定要退出系统吗?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning',
					center: true
				}).then(() => {
					this.$message({
						type: 'success',
						message: '成功退出系统!'
					});
					this.timer = setTimeout(() => {
						this.$router.push('/logout')
					}, 500);
				}).catch(() => {
					this.$message({
						type: 'info',
						message: '已取消退出'
					});
				});
			},
		}
	}
</script>

<style>
	* {
		margin: 0px;
		padding: 0px;
		text-decoration: none;
		list-style: none;
	}

	.router-link-active {
		text-decoration: none;
		color: #1989FA;
	}

	a {
		text-decoration: none;
		color: white;
	}

	.el-row a {
		text-decoration: none;
		color: black;
	}

	.el-header {
		line-height: 80px;
		background-color: #ffffff;
		text-color: #000000;

	}

	.el-aside {
		height: 100vh;
	}

	.status .el-col {
		width: 100px;
		line-height: 80px;
		background-color: #409EFF;
		color: #FFFFFF;
	}
</style>
