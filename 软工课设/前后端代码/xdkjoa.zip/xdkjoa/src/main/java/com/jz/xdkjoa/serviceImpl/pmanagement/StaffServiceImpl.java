package com.jz.xdkjoa.serviceImpl.pmanagement;

import com.jz.xdkjoa.mapper.pmanagement.StaffMapper;
import com.jz.xdkjoa.pojo.pmanagement.Staff;
import com.jz.xdkjoa.service.pmanagement.StaffService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StaffServiceImpl implements StaffService {

    @Autowired(required = false)
    StaffMapper staffmapper=null;

    @Override
    public void addStaffBiz(Staff staff) {
         staffmapper.addStaff(staff);
    }

    @Override
    public List<Staff> showStaffsBiz() {
        return staffmapper.showStaffs();
    }

    @Override
    public Staff showStaffByIdBiz(Integer job_num) {
        return staffmapper.showStaffById(job_num);
    }

    @Override
    public List<Staff> showStaffByNameBiz(String staff_name,Integer depart_num) {
        staff_name="%"+staff_name+"%";
        return staffmapper.showStaffByName(staff_name,depart_num);
    }

    @Override
    public void updateStaffBiz(Staff staff) {
        staffmapper.updateStaff(staff);
    }

    @Override
    public void delStaffBiz(Integer job_num) {
        staffmapper.delStaff(job_num);
    }
    @Override
    public List<Staff> showStaffByDeptBiz(String depart_name) {
        return staffmapper.showStaffByDept(depart_name);
    }
    @Override
    public List<Staff> validateStaff(String account) {
        return staffmapper.validateStaff(account);
    }

    @Override
    public void saveImageBiz(String image, Integer job_num) {
         staffmapper.saveImage(image,job_num);
    }

    @Override
    public List<Staff> findStaffByDepartmentBiz(Integer depart_num) {
        return staffmapper.findStaffByDepartment(depart_num);
    }
}
