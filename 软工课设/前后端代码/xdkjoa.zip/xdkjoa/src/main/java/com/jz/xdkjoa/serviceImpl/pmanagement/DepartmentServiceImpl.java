package com.jz.xdkjoa.serviceImpl.pmanagement;

import com.jz.xdkjoa.mapper.pmanagement.DepartmentMapper;
import com.jz.xdkjoa.pojo.pmanagement.Department;
import com.jz.xdkjoa.service.pmanagement.DepartmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DepartmentServiceImpl implements DepartmentService {

    @Autowired(required = false)
    DepartmentMapper departmentMapper=null;

    @Override
    public String findNameByNumBiz(Integer depart_num) {
        return departmentMapper.findNameByNum(depart_num);
    }

    @Override
    public List<Department> showAllDepartmentsBiz() {
        return departmentMapper.showAllDepartments();
    }


}

