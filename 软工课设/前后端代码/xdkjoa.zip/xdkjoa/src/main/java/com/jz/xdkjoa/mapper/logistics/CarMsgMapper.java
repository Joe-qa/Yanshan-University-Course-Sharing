package com.jz.xdkjoa.mapper.logistics;

import com.jz.xdkjoa.pojo.logistics.CarMsg;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface CarMsgMapper {
    /**
     * 查询所有车辆信息
     * 这是接口
     * @return
     */
    List<CarMsg>getCarMsgs();

    /**
     * 通过车辆状态查询车辆
     * @param situation
     * @return
     */
    List<CarMsg>showByState(String situation);

    /**
     * 通过车牌号查询车辆
     * @param car_num
     * @return
     */
    List<CarMsg>showByCarNum(String car_num);

    /**
     * 添加车辆信息
     * @param carmsg
     */
    void addCar(CarMsg carmsg);

    /**
     * 更新车的状态
     * @param car_num
     */
    void updateCarState(String car_num);


}
