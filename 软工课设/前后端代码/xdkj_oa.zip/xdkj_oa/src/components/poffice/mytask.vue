<template>
	<el-main style="margin-top:0px;padding: 0px;">
		<div class="head" style="display: flex;flex-direction: row;">
			<el-button type="primary" icon="el-icon-plus" style="margin-left: 10px" @click="fun($event)">新建个人任务
			</el-button>
			<font style="margin-left: 250px;"></font>
			<el-pagination style="margin-left: 700px" small layout="prev, pager, next" :total="calendar.length"
				:page-size="pageSize" @current-change="handleCurrentChange" :current-page="currentPage">
			</el-pagination>
		</div>
		<el-table :data="tempcalendar" border style="width: 100%;margin-top: 10px;"
			:header-cell-style="{background:'#f4f4f4'}">
			<el-table-column prop="schedule_name" label="任务名称" width="100">
			</el-table-column>
			<el-table-column prop="schedule_type" label="任务类型" width="100">
			</el-table-column>
			<el-table-column prop="schedule_state" label="任务状态" width="100">
			</el-table-column>
			<el-table-column prop="schedule_date" label="任务时间" width="200" sortable>
			</el-table-column>
			<el-table-column prop="schedule_content" label="任务描述" width="200">
			</el-table-column>
			<el-table-column prop="schedule_process" label="任务进度" :formatter="stateFormat" width="190" sortable>
			</el-table-column>
			<el-table-column label="进度显示" align="center">
				<template slot-scope="scope">
					<el-progress :percentage="scope.row.process" :show-text="true" :status="scope.row.status"
						stroke-width="20px">
					</el-progress>
				</template>
			</el-table-column>
			<el-table-column fixed="right" label="操作" width="170">
				<template slot-scope="scope">
					<el-button @click="handleClick1(scope.row,scope.$index);toDetail(scope.row)" type="text"
						size="small">查看
					</el-button>
					<el-button type="text" size="small"
						@click="handleClick2(scope.row,scope.$index);modify(scope.row);getValue(scope.row)">修改
					</el-button>
					<el-button type="text" size="small" @click="deleteRow(scope.$index, tempcalendar,scope.row)">删除
					</el-button>
				</template>
			</el-table-column>
		</el-table>

		<el-dialog title="新建个人任务" :visible.sync="dialogFormVisible">
			<el-form :model="form" :rules="rules" ref="form">
				<el-form-item label="任务名称" prop="schedule_name" :label-width="formLabelWidth">
					<el-input v-model="form.schedule_name" placeholder="请输入任务名称" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="日程描述" prop="schedule_content" :label-width="formLabelWidth">
					<el-input v-model="form.schedule_content" placeholder="请输入日程内容" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="选择日期" prop="schedule_date" :label-width="formLabelWidth">
					<div class="block">
						<el-date-picker v-model="form.schedule_date" type="date" placeholder="选择日期"
							:picker-options="pickerOptions">
						</el-date-picker>
					</div>
				</el-form-item>
				<el-form-item label="选择开始时间" prop="start_time" :label-width="formLabelWidth">
					<el-time-picker v-model="form.start_time" placeholder="开始时间">
					</el-time-picker>
				</el-form-item>
				<el-form-item label="选择结束时间" prop="ask_endtime" :label-width="formLabelWidth">
					<el-time-picker v-model="form.ask_endtime" placeholder="结束时间">
					</el-time-picker>
				</el-form-item>
				<el-form-item label="具体任务描述" prop="concrete_schedulecontent" :label-width="formLabelWidth"
					style="height: 100px;">
					<el-input v-model="form.concrete_schedulecontent" placeholder="请输入具体任务描述" autocomplete="off">
					</el-input>
				</el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click="cancel($canceled)">取 消</el-button>
				<el-button type="primary" @click="save('form')">确 定</el-button>
			</div>
		</el-dialog>
		<!-- 查看弹框内容设置 -->
		<el-dialog title="具体内容" :visible.sync="dialogFormVisible1">
			{{detail}}
			<div slot="footer" class="dialog-footer">
				<el-button @click="cancel1($canceled)">取 消</el-button>
				<el-button type="primary" @click="save1()">确 定</el-button>
			</div>
		</el-dialog>


		<!-- 备注的弹框内容设置 -->
		<el-dialog title="修改个人任务" :visible.sync="dialogFormVisible2">
			<el-form :model="form1" :rules="rules" ref="form1">
				<el-form-item label="任务名称" prop="schedule_name" :label-width="formLabelWidth">
					<el-input v-model="form1.schedule_name" placeholder="请输入任务名称" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="日程描述" prop="schedule_content" :label-width="formLabelWidth">
					<el-input v-model="form1.schedule_content" placeholder="请输入日程内容" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="选择日期" prop="schedule_date" :label-width="formLabelWidth">
					<div class="block">
						<el-date-picker v-model="form1.schedule_date" type="date" placeholder="选择日期"
							:picker-options="pickerOptions">
						</el-date-picker>
					</div>
				</el-form-item>
				<el-form-item label="选择开始时间" prop="start_time" :label-width="formLabelWidth">
					<el-time-picker v-model="form1.start_time" placeholder="开始时间" :picker-options="StartPickerDisabled">
					</el-time-picker>
				</el-form-item>
				<el-form-item label="选择结束时间" prop="ask_endtime" :label-width="formLabelWidth"
					options="EndPickerDisabled">
					<el-time-picker v-model="form1.ask_endtime" placeholder="结束时间">
					</el-time-picker>
				</el-form-item>
				<el-form-item label="具体任务描述" prop="concrete_schedulecontent" :label-width="formLabelWidth">
					<el-input v-model="form1.concrete_schedulecontent" placeholder="请输入具体任务描述" autocomplete="off">
					</el-input>
				</el-form-item>
				<el-form-item label="任务进度" prop="schedule_process" :label-width="formLabelWidth" style="height: 100px;">
					<el-input v-model="form1.schedule_process" placeholder="请输入任务进度" autocomplete="off"></el-input>
				</el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click="cancel()">取 消</el-button>
				<el-button type="primary" @click="save2('form1')">确 定</el-button>
			</div>
		</el-dialog>

	</el-main>
</template>

<script>
	export default {
		inject: ['reload'],
		created() {


			let that = this
			this.$axios({
				method: 'get',
				url: 'http://localhost:8888/staff/findStaffByAccount?account=' + that.getCookie("account")
			}).then(function(response) {
				that.job_num = response.data.job_num,
					that.$axios({
						method: 'get',
						url: 'http://localhost:8888/personalschedule/showpersonalschedule?job_num=' + that
							.job_num +
							'&schedule_type=个人日程'
					}).then(function(response) {
						that.calendar = response.data
						that.tempcalendar = that.calendar.slice(0, that.pageSize)
						console.log(that.calendar)
					})

			})
		},
		data() {
			return {
				job_num: '',
				showprocess: "",
				tempcalendar: [],
				calendar: [],
				remark: "",
				newcalendar: {
					schedule_name: "",
					schedule_type: "",
					start_time: "",
					schedule_date: "",
					ask_endtime: "",
					fact_endtime: "",
					schedule_content: "",
					concrete_schedulecontent: "",
					delay: "",
					process: "",
					schedule_state: "",
					schedule_process: "",
					job_num: ""
				},
				StartPickerDisabled: {
					//开始时间限制
					disabledDate: time => {
						let beginVal = this.form.ask_endtime;
						if (beginVal) {
							return time.getTime() > beginVal;
						}
					}
				},
				EndPickerDisabled: {
					//结束时间限制
					disabledDate: time => {
						let beginVal = this.form.start_time;
						if (beginVal) {
							return time.getTime() < beginVal;
						}
					}
				},
				dialogTableVisible: false,
				dialogFormVisible: false,
				dialogFormVisible1: false,
				dialogFormVisible2: false,
				value: false,
				form: {
					schedule_name: '',
					schedule_content: '',
					schedule_date: '',
					schedule_type: '',
					start_time: '',
					ask_endtime: '',
					concrete_schedulecontent: '',
					process: "",
					schedule_process: "",
				},
				form1: {
					schedule_name: '',
					schedule_content: '',
					schedule_date: '',
					schedule_type: '',
					start_time: '',
					ask_endtime: '',
					concrete_schedulecontent: '',
					process: "",
					schedule_process: "",
				},
				pageSize: 5,
				schedule_date: '',
				formLabelWidth: '120px',
				rules: {
					schedule_name: [{
						required: true,
						message: '请输入任务名称',
						trigger: 'blur'
					}, ],
					schedule_content: [{
						required: true,
						message: '请输入日程内容',
						trigger: 'blur'
					}, ],
					schedule_date: [{
						required: true,
						message: '请输入日程开始日期',
						trigger: 'change'
					}, ],
					start_time: [{
						required: true,
						message: '请输入日程开始时间',
						trigger: 'change'
					}, ],
					ask_endtime: [{
						required: true,
						message: '请选择日程时间',
						trigger: 'change'
					}],
					concrete_schedulecontent: [{
						required: true,
						message: '请输入具体日程描述',
						trigger: 'blur'
					}],
					schedule_process: [{
							required: true,
							message: '请输入进度',
							trigger: 'blur'
						},
						{
							pattern: /^100$|^(\d|[1-9]\d)$/,
							message: '进度输入有误，重新输入'
						},
					]
				}
			}
		},
		methods: {
			getCookie: function(key) {
				if (document.cookie.length > 0) {
					var start = document.cookie.indexOf(key + '=')
					if (start !== -1) {
						start = start + key.length + 1
						var end = document.cookie.indexOf(';', start)
						if (end === -1) end = document.cookie.length
						return unescape(document.cookie.substring(start, end))
					}
				}
				return ''
			},
			stateFormat(row, column) {
				if (row.schedule_process.length != 0) {
					let schedule_process1 = row.schedule_process + '%'
					return schedule_process1
				}
			},
			getValue(row) {
				this.showprocess = row.schedule_process;
			},
			fun(el) {
				this.dialogFormVisible = true
			},
			cancel() {
				this.dialogFormVisible2 = false
			},
			cancel()
			{
				this.dialogFormVisible = false
			},
			save(formName) {
				this.$refs[formName].validate((valid) => {
					let that=this
					if (valid) {
						if (this.form.start_time > this.form.ask_endtime) {
							that.$message({
								showClose: true,
								message: '开始时间不能小于结束时间',
								type: 'error',
								offset: 300
							});
						} else {
							const date = new Date();
							this.newcalendar.schedule_name = this.form.schedule_name;
							this.newcalendar.schedule_type = "个人日程";
							this.newcalendar.start_time = this.form.start_time;
							this.newcalendar.schedule_date = this.form.schedule_date;
							this.newcalendar.ask_endtime = this.form.ask_endtime;
							this.newcalendar.fact_endtime = this.form.ask_endtime;
							this.newcalendar.schedule_content = this.form.schedule_content;
							this.newcalendar.concrete_schedulecontent = this.form.concrete_schedulecontent;
							this.newcalendar.process = 0;
							this.newcalendar.schedule_state = "未开始";
							this.newcalendar.schedule_process = '0';
							this.newcalendar.job_num = this.job_num;
							this.newcalendar.delay = false;
							let that = this
							console.log('这是往后端传的东西：', that.newcalendar)
							this.$axios({
								method: 'post',
								url: 'http://localhost:8888/personalschedule/addpersonalschedule',
								data: that.newcalendar,
							}).then(function(res) {
								that.$message({
									showClose: true,
									message: '个人任务新建成功',
									type: 'success',
									offset: 300
								});
							})
							this.dialogFormVisible = false
							this.timer = setTimeout(() => { //设置延迟执行
								this.$router.go(0);
							}, 0.1);
						}
					} else {
						console.log('error submit!!');
						return false;
					}
				})
			},
			//页码切换
			handleCurrentChange(currentPage) {
				this.currentPage = currentPage;
				this.currentChangePage(this.calendar, currentPage);
			},
			//分页实现
			currentChangePage(list, currentPage) {
				let from = (currentPage - 1) * this.pageSize;
				let to = currentPage * this.pageSize;
				this.tempcalendar = this.calendar.slice(from, to);
			},

			//对查看弹出框的操作
			toDetail(row) {
				this.detail = row.concrete_schedulecontent;
				this.dialogFormVisible1 = true;
			},
			cancel1() {
				this.dialogFormVisible1 = false
			},
			save1() {
				this.dialogFormVisible1 = false
			},
			handleClick1(row, index) {
				console.log(row, index);
			},
			//对备注弹出框的操作
			cancel2() {
				this.dialogFormVisible2 = false
			},
			save2(formName) {
				this.$refs[formName].validate((valid) => {
					if (valid) {
						let that = this;
						if (that.form1.start_time > that.form1.ask_endtime) {
							that.$message({
								showClose: true,
								message: '开始时间不能小于结束时间',
								type: 'error',
								offset: 300
							});
						} else {
							that.form1.process = that.form1.schedule_process
							console.log("lllllll", that.form1.process)
							if (that.form1.process != 0) {
								that.form1.schedule_state = "已开始"
							}
							if (that.form1.process == 0) {
								that.form1.schedule_state = "未开始"
							}
							this.$axios({
								method: 'post',
								url: 'http://localhost:8888/personalschedule/updatepersonalschedule',
								data: that.form1,
								headers: {
									'Content-Type': 'application/json;charset=utf-8' //改这里就好了
								}
							}).then(res => {
								this.$message.success('修改成功')
								that.reload()

							}).catch(function(error) {
								console.log(error)
							});
							this.dialogFormVisible2 = false
						}
					} else {
						console.log('error submit!!');
						return false;
					}
				})
			},
			handleClick2(row, index) {
				console.log(row, index);
			},
			modify(row) {
				this.dialogFormVisible2 = true;
				this.newcalendar = row; //显示原来的具体内容
				this.form1 = row;
				this.form1.start_time = new Date(Date.now());
				this.form1.ask_endtime = new Date(Date.now());
				this.form1.schedule_process = this.form1.schedule_process;
				this.remark = row.concrete_schedulecontent;
				console.log("这是点击修改之后显示的标记 " + this.remark)
			},
			//删除数据
			deleteRow(index, rows, row) {
				this.$confirm('此操作将永久删除个人任务, 是否继续?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
				}).then(() => {
				let e = rows.splice(index, 1) //删除表格中的一行
				//将删除请求传递回后端，进行数据库删除
				let schedule_id = row.schedule_id
				let that = this
				this.$axios({
					method: 'get',
					url: 'http://localhost:8888/personalschedule/delpersonalschedule?schedule_id=' + schedule_id
				}).then(function() {
					that.$message({
						message: '恭喜您，删除成功！！！！',
						type: 'success',
						offset: 300
					});
				})})
				// this.timer = setTimeout(() => { //设置延迟执行
				// 	this.$router.go(0);
				// }, 0.1);
			}
		}
	}
</script>
<style>
	.head {
		font-weight: bold;
		font-size: 20px;

	}
</style>
