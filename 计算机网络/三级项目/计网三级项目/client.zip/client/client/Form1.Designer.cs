﻿namespace client
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.map = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.plane = new System.Windows.Forms.PictureBox();
            this.btn_Connection = new System.Windows.Forms.Button();
            this.btn_stop = new System.Windows.Forms.Button();
            this.dia = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.map)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.plane)).BeginInit();
            this.SuspendLayout();
            // 
            // map
            // 
            this.map.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("map.BackgroundImage")));
            this.map.Location = new System.Drawing.Point(23, 21);
            this.map.Name = "map";
            this.map.Size = new System.Drawing.Size(954, 600);
            this.map.TabIndex = 6;
            this.map.TabStop = false;
            this.map.Click += new System.EventHandler(this.map_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 2000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // plane
            // 
            this.plane.BackColor = System.Drawing.Color.Transparent;
            this.plane.Image = ((System.Drawing.Image)(resources.GetObject("plane.Image")));
            this.plane.Location = new System.Drawing.Point(51, 21);
            this.plane.Name = "plane";
            this.plane.Size = new System.Drawing.Size(150, 150);
            this.plane.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.plane.TabIndex = 8;
            this.plane.TabStop = false;
            // 
            // btn_Connection
            // 
            this.btn_Connection.Location = new System.Drawing.Point(1250, 33);
            this.btn_Connection.Name = "btn_Connection";
            this.btn_Connection.Size = new System.Drawing.Size(132, 35);
            this.btn_Connection.TabIndex = 9;
            this.btn_Connection.Text = "连接服务器";
            this.btn_Connection.UseVisualStyleBackColor = true;
            this.btn_Connection.Click += new System.EventHandler(this.btn_Connection_Click);
            // 
            // btn_stop
            // 
            this.btn_stop.Location = new System.Drawing.Point(1250, 89);
            this.btn_stop.Name = "btn_stop";
            this.btn_stop.Size = new System.Drawing.Size(132, 38);
            this.btn_stop.TabIndex = 10;
            this.btn_stop.Text = "暂停飞行";
            this.btn_stop.UseVisualStyleBackColor = true;
            this.btn_stop.Click += new System.EventHandler(this.btn_stop_Click);
            // 
            // dia
            // 
            this.dia.AutoSize = true;
            this.dia.Font = new System.Drawing.Font("黑体", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.dia.ForeColor = System.Drawing.Color.Red;
            this.dia.Location = new System.Drawing.Point(47, 41);
            this.dia.Name = "dia";
            this.dia.Size = new System.Drawing.Size(0, 19);
            this.dia.TabIndex = 11;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1448, 640);
            this.Controls.Add(this.dia);
            this.Controls.Add(this.btn_stop);
            this.Controls.Add(this.btn_Connection);
            this.Controls.Add(this.plane);
            this.Controls.Add(this.map);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.map)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.plane)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox map;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.PictureBox plane;
        private System.Windows.Forms.Button btn_Connection;
        private System.Windows.Forms.Button btn_stop;
        private System.Windows.Forms.Label dia;
    }
}

