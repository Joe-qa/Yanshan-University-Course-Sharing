<template>
	<div>
		<el-container style="height: 500px;margin-top: 0px;padding: 0px;">
			<el-header>
				<el-form :model="search">
					<i style="margin-right: 15px"></i>
					<el-button @click="exportExcel()" type="primary">导出</el-button>
					<el-input placeholder="搜索姓名" prefix-icon="el-icon-search" v-model="search.staff_name"
						style="margin-top: 0px;margin-left:600px; width: 210px;">
					</el-input>
					<el-select v-model="search.depart_num" placeholder="请选择要查询的部门">
						<el-option v-for="d in depts" :key="d.depart_num" :label="d.depart_name" :value="d.depart_num">
						</el-option>
					</el-select>
					<el-button type="primary" @click="searchStaff">搜索</el-button>
				</el-form>
			</el-header>

			<el-main>
				<el-table :data="templist" id="outExcel">
					<el-table-column type="selection" width="55">
					</el-table-column>
					<el-table-column prop="job_num" label="员工工号" sortable>
					</el-table-column>
					<el-table-column prop="staff_name" label="员工姓名">
					</el-table-column>
					<el-table-column prop="gender" label="员工性别">
					</el-table-column>
					<el-table-column prop="department.depart_name" label="所属部门">
					</el-table-column>
					<el-table-column prop="job.post_name" label="职位名称">
					</el-table-column>
					<el-table-column prop="in_office" label="是否在职">
					</el-table-column>
					<el-table-column label="编辑">
						<template slot-scope="scope">
							<el-button @click="updateRow(scope.row)" type="primary" plain size="small">修改</el-button>
							<el-button type="primary" @click="deleteRow(scope.$index,templist,scope.row)" plain
								size="small">删除</el-button>
						</template>
					</el-table-column>
				</el-table>
				<!-- 分页控件 -->
				<div class="block" style="justify-content: center; display: flex; margin-top: 10px;">
					<el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
						:current-page="currentPage" :page-sizes="[5, 10, 15]" :page-size="pageSize"
						layout="total, sizes, prev, pager, next, jumper" :total="staffs.length">
					</el-pagination>
				</div>
			</el-main>
		</el-container>
		<el-dialog title="修改员工信息" :visible.sync="dialogFormVisible" width="45%">
			<el-form :model="staff" :rules="rules" ref="staff">
				<el-form-item label="员工姓名" prop="staff_name" :label-width="formLabelWidth">
					<el-input v-model="staff.staff_name" autocomplete="off"></el-input>
				</el-form-item>

				<el-form-item label="性别" prop="gender" :label-width="formLabelWidth">
					<el-select v-model="staff.gender">
						<el-option label="男" value="男"></el-option>
						<el-option label="女" value="女"></el-option>
					</el-select>
				</el-form-item>

				<el-form-item label="国籍" prop="nationality" :label-width="formLabelWidth">
					<el-select v-model="staff.nationality">
						<el-option label="中国" value="中国"></el-option>
						<el-option label="外国" value="外国"></el-option>
					</el-select>
				</el-form-item>

				<el-form-item label="民族" prop="nation" :label-width="formLabelWidth">
					<el-select v-model="staff.nation">
						<el-option label="汉" value="汉族"></el-option>
						<el-option label="少数民族" value="少数民族"></el-option>
					</el-select>
				</el-form-item>

				<el-form-item label="政治面貌" prop="politics_statues" :label-width="formLabelWidth">
					<el-select v-model="staff.politics_statues">
						<el-option label="群众" value="群众"></el-option>
						<el-option label="党员" value="党员"></el-option>
					</el-select>
				</el-form-item>

				<el-form-item label="籍贯" prop="native_place" :label-width="formLabelWidth">
					<el-input v-model="staff.native_place"></el-input>
				</el-form-item>

				<el-form-item label="身份证号" prop="identity_num" :label-width="formLabelWidth">
					<el-input v-model="staff.identity_num"></el-input>
				</el-form-item>
				<el-form-item label="出生日期" prop="birthday" :label-width="formLabelWidth">
					<el-date-picker type="date" placeholder="选择日期" v-model="staff.birthday" style="width: 100%;">
					</el-date-picker>
				</el-form-item>
				<el-form-item label="员工类型" prop="staff_type" :label-width="formLabelWidth">
					<el-select v-model="staff.staff_type">
						<el-option label="正式员工" value="正式员工"></el-option>
						<el-option label="临时员工" value="临时员工"></el-option>
					</el-select>
				</el-form-item>
				<el-form-item label="是否在职" prop="in_office" :label-width="formLabelWidth">
					<el-select v-model="staff.in_office">
						<el-option label="是" value="是"></el-option>
						<el-option label="否" value="否"></el-option>
					</el-select>
				</el-form-item>
				<el-form-item label="部门名称" prop="depart_num" :label-width="formLabelWidth">
					<el-select v-model="staff.depart_num">
						<el-option v-for="d in depts" :key="d.depart_num" :label="d.depart_name" :value="d.depart_num">
						</el-option>
					</el-select>
				</el-form-item>
				<el-form-item label="职位名称" prop="post_num" :label-width="formLabelWidth">
					<el-select v-model="staff.post_num">
						<el-option v-for="j in jobs" :key="j.post_num" :label="j.post_name" :value="j.post_num">
						</el-option>
					</el-select>
				</el-form-item>
				<el-form-item label="邮箱" prop="email" :label-width="formLabelWidth">
					<el-input v-model="staff.email"></el-input>
				</el-form-item>
				<el-form-item label="电话" prop="staff_tel" :label-width="formLabelWidth">
					<el-input v-model="staff.staff_tel"></el-input>
				</el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click="resetForm('staff')">取 消</el-button>
				<el-button type="primary" @click="saveUpdateStaff('staff')">保 存</el-button>
			</div>
		</el-dialog>

	</div>
</template>
<style>

</style>

<script>
	export default {
		data() {
			return {
				depts: [],
				templist: [],
				pageSize: 5,
				currentPage: 1,
				search: {
					staff_name: '',
					depart_num: ''
				},
				dialogFormVisible: false,
				staffs: [],
				jobs: [],
				staff: {
					job_num: '',
					depart_num: '',
					post_num: '',
					staff_name: '',
					account: '',
					staff_password: '',
					staff_type: '',
					gender: '',
					nationality: '',
					nation: '',
					identity_num: '',
					birthday: '',
					native_place: '',
					politics_statues: '',
					email: '',
					in_office: '',
					service_length: '',
					staff_tel: ''
				},
				formLabelWidth: '120px',
				rules: {
					staff_name: [{
							required: true,
							message: '请输入员工姓名',
							trigger: 'blur'
						},
						{
							min: 2,
							max: 10,
							message: '长度在 2 到 10 个字符',
							trigger: 'blur'
						}
					],
					job_num: [{
							required: true,
							message: '请输入员工工号',
							trigger: 'blur'
						},
						{
							max: 10,
							message: '员工工号不超过10个字符'
						},
						{
							pattern: /^[^\u4e00-\u9fa5]+$/,
							message: '不允许输入中文',
							trigger: 'blur'
						},
						{
							pattern: /^[A-Za-z0-9\u4e00-\u9fa5]+$/,
							message: '不允许输入空格等特殊符号',
							trigger: 'blur'
						}
					],
					depart_num: [{
						required: true,
						message: '请输入所属部门',
						trigger: 'blur'
					}, ],
					post_num: [{
						required: true,
						message: '请选择职位',
						trigger: 'blur'
					}, ],
					staff_password: [{
							required: true,
							message: '请输入员工登录密码',
							trigger: 'blur'
						},
						{
							min: 6,
							max: 20,
							message: '密码长度不低于6个字符',
							trigger: 'blur'
						},
						{
							pattern: /^[A-Za-z0-9\u4e00-\u9fa5]+$/,
							message: '不允许输入空格等特殊符号',
							trigger: 'blur'
						}
					],
					account: [{
							required: true,
							message: '请输入员工的登录账号',
							trigger: 'blur'
						},
						{
							pattern: /^[A-Za-z0-9\u4e00-\u9fa5]+$/,
							message: '不允许输入空格等特殊符号',
							trigger: 'blur'
						},
					],
					staff_type: [{
						required: true,
						message: '请选择员工类型类型',
						trigger: 'blur'
					}],
					gender: [{
						required: true,
						message: '请选择员工性别',
						trigger: 'blur'
					}, ],
					identity_num: [{
							required: true,
							message: '请输入证件号码',
							trigger: 'blur'
						},
						{
							min: 18,
							max: 18,
							message: '证件号格式不正确'
						},
						{
							pattern: /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/,
							message: '证件号格式不正确'
						}
					],
					email: [{
							required: true,
							message: '请输入邮箱',
							trigger: 'blur'
						},
						{
							pattern: /^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$/,
							message: '邮箱格式不正确',
							trigger: 'blur'
						},
					],
					in_office: [{
						required: true,
						message: '请选择员工是否在职',
						trigger: 'blur'
					}, ]
				}
			}
		},
		methods: {
			resetForm(formName) {
				this.$refs[formName].resetFields();
				this.dialogFormVisible = false
			},
			exportExcel: function() {
				let tables = document.querySelector("#outExcel") //根据id选取到要导出的表格
				let table_book = this.$XLSX.utils.table_to_book(tables)
				let table_write = this.$XLSX.write(table_book, {
					bookType: "xlsx",
					bookSST: true,
					type: "array"
				})
				try {
					this.$FileSaver.saveAs(new Blob([table_write], {
						type: "application/octet-stream"
					}), "staffs.xlsx")
				} catch (e) {
					console.log(e, table_write)
				}
				return table_write
			},
			//每页条数切换
			handleSizeChange(pageSize) {
				this.pageSize = pageSize;
				this.handleCurrentChange(this.currentPage);
			},
			//页码切换
			handleCurrentChange(currentPage) {
				this.currentPage = currentPage;
				this.currentChangePage(this.staffs, currentPage);
			},
			//分页实现
			currentChangePage(list, currentPage) {
				let from = (currentPage - 1) * this.pageSize;
				let to = currentPage * this.pageSize;
				this.templist = this.staffs.slice(from, to);
			},
			searchStaff() {
				let that = this
				console.log(that.search.staff_name)
				console.log(that.search.depart_num)
				this.$axios({
					method: 'post',
					url: 'http://localhost:8888/staff/showStaffByName',
					data: {
						"staff_name": that.search.staff_name,
						"depart_num": that.search.depart_num
					}
				}).then(function(response) {
					console.log(response.data)
					that.staffs = response.data
					that.templist = that.staffs.slice(0, that.pageSize)
				})
			},
			saveUpdateStaff(formName) {
				this.$refs[formName].validate((valid) => {
					if (valid) {
						let that = this
						this.dialogFormVisible = false
						this.$axios({
							method: 'post',
							url: 'http://localhost:8888/staff/updatestaff',
							data: that.staff
						}).then(function() {
							that.$message({
								showClose: true,
								message: '修改成功',
								type: 'success',
								offset: 300
							});
						})
						this.timer = setTimeout(() => { //设置延迟执行
							this.$router.go(0);
						}, 0.1);
					} else {
						console.log('error submit!!');
						return false;
					}
				});
			},
			updateRow(rows) {
				this.dialogFormVisible = true
				this.staff = rows
			},
			deleteRow(index, rows, row) {
				console.log(rows)
				rows.splice(index, 1) //删除表格中的一行
				//将删除请求传回到后台服务器
				let job_num = row.job_num
				let that = this
				this.$axios({
					method: 'get',
					url: 'http://localhost:8888/staff/delstaff?job_num=' + job_num
				}).then(function() {
					that.$message({
						showClose: true,
						message: '删除成功',
						type: 'success',
						offset: 300
					});
				})
			}
		},
		created: function() {
			let that = this
			//去后端提数据
			//获取员工信息
			this.$axios({
				method: 'post',
				url: 'http://localhost:8888/staff/stafflist',
			}).then(function(response) {
				that.staffs = response.data
				that.templist = that.staffs.slice(0, that.pageSize)
			})

			//获取部门信息
			this.$axios({
				method: 'post',
				url: 'http://localhost:8888/department/showalldepartments',
			}).then(function(response) {
				console.log(response.data)
				that.depts = response.data
			})

			//获取职位信息
			this.$axios({
				method: 'post',
				url: 'http://localhost:8888/job/showalljob'

			}).then(function(response) {
				that.jobs = response.data
			})
		}
	};
</script>
