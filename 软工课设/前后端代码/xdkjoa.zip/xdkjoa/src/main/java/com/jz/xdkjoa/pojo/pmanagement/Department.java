package com.jz.xdkjoa.pojo.pmanagement;

public class Department {
    int depart_num;
    String depart_tel;
    String depart_name;
    int depart_level;


    public Department() {
    }

    public Department(int depart_num, String depart_tel, String depart_name, int depart_level) {
        this.depart_num = depart_num;
        this.depart_tel = depart_tel;
        this.depart_name = depart_name;
        this.depart_level = depart_level;
    }

    public int getDepart_num() {
        return depart_num;
    }

    public void setDepart_num(int depart_num) {
        this.depart_num = depart_num;
    }

    public String getDepart_tel() {
        return depart_tel;
    }

    public void setDepart_tel(String depart_tel) {
        this.depart_tel = depart_tel;
    }

    public String getDepart_name() {
        return depart_name;
    }

    public void setDepart_name(String depart_name) {
        this.depart_name = depart_name;
    }

    public int getDepart_level() {
        return depart_level;
    }

    public void setDepart_level(int depart_level) {
        this.depart_level = depart_level;
    }

    @Override
    public String toString() {
        return "Department{" +
                "depart_num=" + depart_num +
                ", depart_tel='" + depart_tel + '\'' +
                ", depart_name='" + depart_name + '\'' +
                ", depart_level=" + depart_level +
                '}';
    }
}
