<template>
	<div class="login-wrapper" :style="'background-image:url('+ Background +')'">
		<div class="form-box">
			<div class="form-title">
				<p style="font-weight: bold;">小岛科技公司办公自动化系统登录</p>
			</div>
			<el-form ref="loginForm" :model="loginForm" :rules="loginRules" label-width="0px" class="login-form">
				<el-form-item prop="account">
					<el-input v-model="loginForm.account" type="text" auto-complete="off" placeholder="请输入工号"
						prefix-icon="el-icon-user" />
				</el-form-item>
				<el-form-item prop="password">
					<el-input v-model="loginForm.password" type="password" auto-complete="off" placeholder="请输入密码"
						prefix-icon="el-icon-lock" @keyup.enter.native="handleLogin" />
				</el-form-item>
				<el-form-item>
					<el-checkbox v-model="loginForm.remember">记住我</el-checkbox>
				</el-form-item>
				<el-form-item>
					<el-button :loading="loading" size="small" type="primary" style="width:100%;" center
						@click.native.prevent="handleLogin">
						<span v-if="!loading">登 录</span>
						<span v-else>登 录 中...</span>
					</el-button>
				</el-form-item>
			</el-form>
		</div>
	</div>
</template>

<script>
	import Background from '../assets/img/login-bg.jpg'
	const Base64 = require('js-base64').Base64
	export default {
		name: 'Login',
		data() {
			return {
				Background,
				loginForm: {
					account: '',
					password: '',
					remember: true
				},
				loginRules: {
					account: [{
						required: true,
						trigger: 'blur',
						message: '用户名不能为空'
					}],
					password: [{
						required: true,
						trigger: 'blur',
						message: '密码不能为空'
					}]
				},
				loading: false,
			}
		},
		created() {
			// 在页面加载时从cookie获取登录信息
			let account = this.getCookie("account")
			let password = Base64.decode(this.getCookie("password"))
			// 如果存在赋值给表单，并且将记住密码勾选
			if (password) {
				this.loginForm.account = account
				this.loginForm.password = password
				this.loginForm.remember = true
			}
			else{
				if(account){
					this.loginForm.account=account
					this.loginForm.password=''
					this.loading.remember=false
				}
				
			}
		},
		methods: {
			handleLogin() {
				let that = this
				this.$axios({
					method: 'get',
					url: 'http://localhost:8888/staff/validateStaff?account=' + that.loginForm.account +
						'&staff_password=' + that.loginForm.password
				}).then(function(response) {
					console.log(response.data)
					if (response.data == "登录成功") {
						//that.setCookie('token', response.token)
						that.setUserInfo()
						that.loading = true
						that.$message.success('登录成功，欢迎进入系统')
						that.timer = setTimeout(() => {
							localStorage.setItem('isLogin', 'true');
							that.$router.push('/index')
						}, 1500);
					} else {
						if (response.data == "此账号不存在") {
							that.$message.error('此账号不存在，请您重新输入');
							that.loginForm.account = ""
							that.loginForm.password = ""
						} else {
							that.$message.error('密码输入错误，请您重新输入');
							that.loginForm.password = ""
						}
					}
				})
			},
			// 储存表单信息
			setUserInfo: function() {
				// 判断用户是否勾选记住密码，如果勾选，向cookie中储存登录信息，
				// 如果没有勾选，储存的信息为空
				if (this.loginForm.remember) {
					this.setCookie("account", this.loginForm.account)
					// base64加密密码
					let passWord = Base64.encode(this.loginForm.password)
					this.setCookie("password", passWord)
				} else {
					this.setCookie("account", this.loginForm.account)
					this.setCookie("password", "")
				}
			},
			// 获取cookie
			getCookie: function(key) {
				if (document.cookie.length > 0) {
					var start = document.cookie.indexOf(key + '=')
					if (start !== -1) {
						start = start + key.length + 1
						var end = document.cookie.indexOf(';', start)
						if (end === -1) end = document.cookie.length
						return unescape(document.cookie.substring(start, end))
					}
				}
				return ''
			},
			// 保存cookie
			setCookie: function(cName, value, expiredays) {
				var exdate = new Date()
				exdate.setDate(exdate.getDate() + expiredays)
				document.cookie = cName + '=' + decodeURIComponent(value) +
					((expiredays == null) ? '' : ';expires=' + exdate.toGMTString())
			}
		}
	}
</script>

<style lang="less">
	.login-wrapper {
		display: flex;
		justify-content: center;
		align-items: center;
		width: 100%;
		height: 100vh;
		background-size: cover;

		.form-box {
			width: 350px;
			padding: 15px 30px 20px;
			background: #ffffff;
			border-radius: 30px;
			box-shadow: 0 15px 30px 0 rgba(0, 0, 1, .1);

			.form-title {
				margin: 0 auto 35px;
				text-align: center;
				color: #707070;
				font-size: 19px;
				letter-spacing: 2px;
			}
		}
	}
</style>
