package com.jz.xdkjoa.pojo.pmanagement;

import java.util.Date;

public class PersonalConstract {
    private int personal_contract_num;
    private int job_num;
    private Date begin_time;
    private Date end_time;
    private int contract_ages;
    private String remark;
    private String contract_type;

    public PersonalConstract() {
    }

    public PersonalConstract(int personal_contract_num, int job_num, Date begin_time, Date end_time, int contract_ages, String remark, String contract_type) {
        this.personal_contract_num = personal_contract_num;
        this.job_num = job_num;
        this.begin_time = begin_time;
        this.end_time = end_time;
        this.contract_ages = contract_ages;
        this.remark = remark;
        this.contract_type = contract_type;
    }

    @Override
    public String toString() {
        return "Personalconstract{" +
                "personal_contract_num=" + personal_contract_num +
                ", job_num=" + job_num +
                ", begin_time=" + begin_time +
                ", end_time=" + end_time +
                ", contract_ages=" + contract_ages +
                ", remark='" + remark + '\'' +
                ", contract_type='" + contract_type + '\'' +
                '}';
    }

    public int getPersonal_contract_num() {
        return personal_contract_num;
    }

    public void setPersonal_contract_num(int personal_contract_num) {
        this.personal_contract_num = personal_contract_num;
    }

    public int getJob_num() {
        return job_num;
    }

    public void setJob_num(int job_num) {
        this.job_num = job_num;
    }

    public Date getBegin_time() {
        return begin_time;
    }

    public void setBegin_time(Date begin_time) {
        this.begin_time = begin_time;
    }

    public Date getEnd_time() {
        return end_time;
    }

    public void setEnd_time(Date end_time) {
        this.end_time = end_time;
    }

    public int getContract_ages() {
        return contract_ages;
    }

    public void setContract_ages(int contract_ages) {
        this.contract_ages = contract_ages;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getContract_type() {
        return contract_type;
    }

    public void setContract_type(String contract_type) {
        this.contract_type = contract_type;
    }
}
