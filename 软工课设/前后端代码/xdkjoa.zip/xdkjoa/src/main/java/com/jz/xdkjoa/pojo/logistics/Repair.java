package com.jz.xdkjoa.pojo.logistics;

import java.util.Date;

public class Repair {
    private int repair_num;
    private int job_num;
    private int equipment_num;
    private String repair_type;
    private Double repair_money;
    private String repair_description;
    private Date take_date;
    private Date repair_date;

    public Repair() {
    }

    public Repair(int repair_num, int job_num, int equipment_num, String repair_type, Double repair_money, String repair_description, Date take_date, Date repair_date) {
        this.repair_num = repair_num;
        this.job_num = job_num;
        this.equipment_num = equipment_num;
        this.repair_type = repair_type;
        this.repair_money = repair_money;
        this.repair_description = repair_description;
        this.take_date = take_date;
        this.repair_date = repair_date;
    }

    @Override
    public String toString() {
        return "Repair{" +
                "repair_num=" + repair_num +
                ", job_num=" + job_num +
                ", equipment_num=" + equipment_num +
                ", repair_type='" + repair_type + '\'' +
                ", repair_money=" + repair_money +
                ", repair_description='" + repair_description + '\'' +
                ", take_date=" + take_date +
                ", repair_date=" + repair_date +
                '}';
    }

    public int getRepair_num() {
        return repair_num;
    }

    public void setRepair_num(int repair_num) {
        this.repair_num = repair_num;
    }

    public int getJob_num() {
        return job_num;
    }

    public void setJob_num(int job_num) {
        this.job_num = job_num;
    }

    public int getEquipment_num() {
        return equipment_num;
    }

    public void setEquipment_num(int equipment_num) {
        this.equipment_num = equipment_num;
    }

    public String getRepair_type() {
        return repair_type;
    }

    public void setRepair_type(String repair_type) {
        this.repair_type = repair_type;
    }

    public Double getRepair_money() {
        return repair_money;
    }

    public void setRepair_money(Double repair_money) {
        this.repair_money = repair_money;
    }

    public String getRepair_description() {
        return repair_description;
    }

    public void setRepair_description(String repair_description) {
        this.repair_description = repair_description;
    }

    public Date getTake_date() {
        return take_date;
    }

    public void setTake_date(Date take_date) {
        this.take_date = take_date;
    }

    public Date getRepair_date() {
        return repair_date;
    }

    public void setRepair_date(Date repair_date) {
        this.repair_date = repair_date;
    }
}
