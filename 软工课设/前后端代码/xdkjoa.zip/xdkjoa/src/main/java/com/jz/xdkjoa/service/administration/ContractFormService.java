package com.jz.xdkjoa.service.administration;


import com.jz.xdkjoa.pojo.administration.ContractForm;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public interface ContractFormService {
    void addContractBiz(ContractForm contract);
    void delContractBiz(int contract_num);
    List<ContractForm> findContractBiz(String contractstate);
    List<ContractForm> showContractBiz();
}
