<template>
	<div style="display: flex;flex-direction: column;justify-content: center;align-items: center;">
		<div style="margin-left: 10px; margin-right: auto;">
			<el-button type="primary" icon="el-icon-upload" @click="exportExcel()">
				导出</el-button>
		</div>
		<div>
		<el-table ref="multipleTable" :data="useCarList" tooltip-effect="dark"
			@selection-change="handleSelectionChange" id="outExcel">
			<el-table-column prop="record_num" label="借车编号" width="120">
			</el-table-column>
			<el-table-column prop="carMsg.car_num" label="车牌号" width="120">
			</el-table-column>
			<el-table-column prop="carMsg.car_model" label="车辆型号" width="180">
			</el-table-column>
			<el-table-column prop="carMsg.department" label="部门" width="120">
			</el-table-column>
			<el-table-column prop="job_num" label="借用人工号" width="120">
			</el-table-column>
			<el-table-column prop="borrow_time" :formatter="dateFormatter" label="借用时间" width="130">
			</el-table-column>
			<el-table-column prop="return_time" :formatter="dateFormatter" label="应还时间" width="130">
			</el-table-column>
			<el-table-column label="状态" width="120">
				<template slot-scope="scope" style="color: #409EFF">{{ scope.row.carMsg.situation }}</template>
			</el-table-column>
		</el-table>
		</div>
		<!--分页控件 -->
		<div class="block" style="justify-content: center; display: flex; margin-top: 10px;">
			<el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
				:current-page="currentPage" :page-sizes="[5, 10, 20]" :page-size="pageSize"
				layout="total, sizes, prev, pager, next, jumper" :total="useCar.length">
			</el-pagination>
		</div>

	</div>
</template>
<script>
	export default {
		created() {

			let that = this
			this.$axios({
				method: 'get',
				url: 'http://localhost:8888/CarRecord/showAllCarRecord?situation=使用中',

			}).then(function(res) {
				console.log(res)
				that.useCar = res.data
				console.log(that.useCar)
				that.useCarList = that.useCar.slice(0, that.pageSize);
			})
		},
		data() {
			return {
				useCarList: [],
				currentPage: 1,
				pageSize: 5,
				useCar: [],
				multipleSelection: []
			}
		},

		methods: {
			exportExcel: function() {
				let tables = document.querySelector("#outExcel") //根据id选取到要导出的表格
				let table_book = this.$XLSX.utils.table_to_book(tables)
				let table_write = this.$XLSX.write(table_book, {
					bookType: "xlsx",
					bookSST: true,
					type: "array"
				})
				try {
					this.$FileSaver.saveAs(new Blob([table_write], {
						type: "application/octet-stream"
					}), "useCarMsg.xlsx")
				} catch (e) {
					console.log(e, table_write)
				}
				return table_write
			},
			dateFormatter(row) {
				let datetime = row.borrow_time;
				if (datetime) {
					datetime = new Date(datetime);
					let y = datetime.getFullYear() + '-';
					let mon = datetime.getMonth() + 1 + '-';
					let d = datetime.getDate();
					return y + mon + d;
				}
				return ''
			},
			toggleSelection(rows) {
				if (rows) {
					rows.forEach(row => {
						this.$refs.multipleTable.toggleRowSelection(row);
					});
				} else {
					this.$refs.multipleTable.clearSelection();
				}
			},
			handleSelectionChange(val) {
				this.multipleSelection = val;
			},
			//每页条数切换
			handleSizeChange(pageSize) {
				this.pageSize = pageSize;
				this.handleCurrentChange(this.currentPage);
			},
			//页码切换
			handleCurrentChange(currentPage) {
				this.currentPage = currentPage;
				this.currentChangePage(this.useCar, currentPage);
			},
			//分页实现
			currentChangePage(list, currentPage) {
				let from = (currentPage - 1) * this.pageSize;
				let to = currentPage * this.pageSize;
				this.useCarList = this.useCar.slice(from, to);
			},

		}
	}
</script>
