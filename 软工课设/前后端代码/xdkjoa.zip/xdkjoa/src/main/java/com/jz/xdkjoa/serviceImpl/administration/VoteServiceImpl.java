package com.jz.xdkjoa.serviceImpl.administration;

public class VoteServiceImpl {
}
