<template>
	<div>
		<el-container>
			<el-main style="width: 570px;">
				<el-form :rules="rules" ref="staff" :model="staff" label-width="80px"
					style="margin-left: 2px;height: auto;">
					<!-- <h3>员工基本信息录入</h3> <br> -->
					<el-form-item label="员工照片" prop="staff_image">
						<el-upload style="display: inline" 
						     list-type="picture-card"
							:show-file-list="true" 
							:on-success="handleAvatarSuccess" 
							:on-error="onError"
							:before-upload="beforeAvatarUpload" 
							action="http://localhost:8888/upload/saveimage">
							<i class="el-icon-plus avatar-uploader-icon"></i>
						</el-upload>
						<a  :href="staff.staff_image"  download="">预览</a>
					</el-form-item>
					<el-row>
					    <el-col span="8">
					      <el-form-item label="员工姓名" prop="staff_name">
					        <el-input v-model="staff.staff_name"></el-input>
					      </el-form-item>
					    </el-col>
					<el-col span="6">
					  <el-form-item label="性别" prop="gender">
					    <el-select v-model="staff.gender">
					    <el-option label="男" value="男"></el-option>
					    <el-option label="女" value="女"></el-option>
					    </el-select>
					  </el-form-item>
					</el-col>
					<el-col span="6">
					  <el-form-item label="国籍" prop="nationality">
					    <el-select v-model="staff.nationality">
					      <el-option label="中国" value="中国"></el-option>
					      <el-option label="外国" value="外国"></el-option>
					    </el-select>
					  </el-form-item>
					</el-col>
					  </el-row>
					  <el-row>
					  <el-col span="8">
					    <el-form-item label="籍贯" prop="native_place">
					      <el-input v-model="staff.native_place"></el-input>
					    </el-form-item>
					  </el-col>
					    <el-col span="6">
					      <el-form-item label="民族" prop="nation">
					        <el-select v-model="staff.nation">
					          <el-option label="汉族" value="汉族"></el-option>
					          <el-option label="少数民族" value="少数民族"></el-option>
					        </el-select>
					      </el-form-item>
					    </el-col>
					    <el-col span="6">
					      <el-form-item label="政治面貌" prop="politics_statues">
					        <el-select v-model="staff.politics_statues">
					          <el-option label="群众" value="群众"></el-option>
					          <el-option label="党员" value="党员"></el-option>
					        </el-select>
					      </el-form-item>
					    </el-col>
					  </el-row>
					
					  <el-row>
					    <el-col span="8">
					      <el-form-item label="身份证号" prop="identity_num">
					        <el-input v-model="staff.identity_num"></el-input>
					      </el-form-item>
					    </el-col>
					
					    <el-col span="12">
					      <el-form-item label="出生日期" prop="birthday">
					        <el-date-picker type="date" placeholder="选择日期" v-model="staff.birthday" style="width: 100%;">
					        </el-date-picker>
					      </el-form-item>
					    </el-col>
					  </el-row>
					<el-form-item style="margin-left: 200px;">
						<el-button type="primary" @click="onSubmit('staff')">下一页</el-button>
					</el-form-item>
				</el-form>
			</el-main>
			<el-aside style="height: 500px;">
				<div style="height: 400px; width: 150px; margin-top: 50px;">
					<el-steps direction="vertical" :active="1">
						<el-step title="员工基本信息录入"></el-step>
						<el-step title="职位信息录入"></el-step>
					</el-steps>
				</div>
			</el-aside>
		</el-container>
	</div>
</template>

<script>
	export default {
		data() {
			return {
				dialogVisible: false,
				staff: {
					job_num: '',
					depart_num: '',
					post_num: '',
					staff_name: '',
					account: '',
					staff_password: '',
					staff_type: '',
					gender: '',
					nationality: '',
					nation: '',
					identity_num: '',
					birthday: '',
					native_place: '',
					politics_statues: '',
					email: '',
					in_office: '',
					service_length: '0',
					staff_tel: '',
					staff_image: ''
				},
          rules: {
                   staff_name: [
                     { required: true, message: '请输入员工姓名', trigger: 'blur' },
                     { min:2,max: 10, message: '长度在 2 到 10 个字符', trigger: 'blur' }
                   ],
                   gender: [
                     { required: true, message: '请选择员工性别', trigger: 'change' },
                   ],
                   identity_num: [
                     { required: true, message: '请输入证件号码', trigger: 'blur' },
                     { min:18,max:18, message: '证件号格式不正确'},
					 { pattern: /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/, message: '证件号格式不正确'}
                   ]
                 }
			}
		},
		methods: {
			handleAvatarSuccess(res, file,fileList) {
				console.log(res)
				this.staff.staff_image=res;
			},
			beforeAvatarUpload(file) {
				const isJPG = file.type === 'image/jpeg';
				const isLt2M = file.size / 1024 / 1024 < 2;

				if (!isJPG) {
					this.$message.error('上传头像图片只能是 JPG 格式!');
				}
				if (!isLt2M) {
					this.$message.error('上传头像图片大小不能超过 2MB!');
				}
				return isJPG && isLt2M;
			},
			onSubmit(formName) {
				this.$refs[formName].validate((valid) => {
					if (valid) {
						//跳转到下一页
						let staff = this.staff
						//console.log(staff)
						sessionStorage.setItem('staff', JSON.stringify(staff))
						this.$router.push({
							name: 'addStaff2'
						})
					} else {
						console.log('error submit!!');
						return false;
					}
				});
			}
		},
		created: function() {
			if (sessionStorage.getItem('staff') != null) {
				let staffJson = sessionStorage.getItem('staff')
				this.staff = JSON.parse(staffJson)
			} else {
				this.staff.job_num = ''
				this.staff.depart_num = ''
				this.staff.post_num = ''
				this.staff.staff_name = ''
				this.staff.account = ''
				this.staff.staff_password = ''
				this.staff.staff_type = ''
				this.staff.gender = ''
				this.staff.nationality = ''
				this.staff.nation = ''
				this.staff.identity_num = ''
				this.staff.birthday = ''
				this.staff.native_place = ''
				this.staff.politics_statues = ''
				this.staff.email = ''
				this.staff.in_office = ''
				this.staff.service_length = '0'
				this.staff.staff_tel = ''
				this.staff.staff_image=''
			}

			// console.log(staffJson)
			// console.log(this.staff)
		}
	}
</script>

<style>
	.avatar-uploader .el-upload {
		border: 1px dashed #d9d9d9;
		border-radius: 6px;
		cursor: pointer;
		position: relative;
		overflow: hidden;
	}

	.avatar-uploader .el-upload:hover {
		border-color: #409EFF;
	}

	.avatar-uploader-icon {
		font-size: 28px;
		color: #8c939d;
		width: 178px;
		height: 178px;
		line-height: 178px;
		text-align: center;
	}

	.avatar {
		width: 178px;
		height: 178px;
		display: block;
	}
</style>
