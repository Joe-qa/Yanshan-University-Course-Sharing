package com.jz.xdkjoa.mapper.pmanagement;

import com.jz.xdkjoa.pojo.pmanagement.Job;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface JobMapper {
    void addJob(Job job);
    Job showJobByName(String post_name);
    void updateJob(Job job);
    void delJob(Integer post_num);
    List<Job> showJob();
}
