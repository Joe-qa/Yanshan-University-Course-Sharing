package com.jz.xdkjoa.serviceImpl.logistics;

import com.jz.xdkjoa.mapper.logistics.RepairMapper;
import com.jz.xdkjoa.pojo.logistics.Repair;
import com.jz.xdkjoa.service.logistics.RepairService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RepairServiceImpl implements RepairService {
    @Autowired(required = false)
    RepairMapper repairMapper;

    @Override
    public void addRepairRecordBiz(Repair repair){
        repairMapper.addRepairRecord(repair);
    }

    @Override
    public void delRepairRecordBiz(Integer repair_num){
        repairMapper.delRepairRecord(repair_num);
    }

    @Override
    public List<Repair> showRepairRecordBiz(){
        return repairMapper.showRepairRecord();
    }

    @Override
    public void updateRepairRecordBiz(Repair repair){
        repairMapper.updateRepairRecord(repair);
    }

}
