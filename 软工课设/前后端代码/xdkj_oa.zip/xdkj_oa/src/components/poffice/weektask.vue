<template>
	<el-main style="margin-top:0px;padding: 0px;">
		<div class="head" style="display: flex;flex-direction: row;">
			<el-button type="primary" icon="el-icon-plus" style="margin-left: 10px" @click="addWeekTask()">新建周期性任务
			</el-button>
			<div>
				<el-pagination style="margin-left: 900px" small layout="prev, pager, next" :total="calendar.length"
					:page-size="pageSize" @current-change="handleCurrentChange">
				</el-pagination>
			</div>
		</div>
		<el-table :data="tempcalendar" border style="width: 100%;margin-top: 10px;"
			:header-cell-style="{background:'#f4f4f4'}">
			<el-table-column prop="schedule_content" label="事务主题" width="300">
			</el-table-column>
			<el-table-column prop="remind_type" label="提醒类型" width="100">
			</el-table-column>
			<el-table-column prop="schedule_date" label="提醒时间" width="200" sortable>
			</el-table-column>
			<el-table-column prop="start_time" label="开始时间" width="200">
			</el-table-column>
			<el-table-column prop="ask_endtime" label="结束时间" width="190">
			</el-table-column>
			<el-table-column fixed="right" label="操作" width="170">
				<template slot-scope="scope">
					<el-button @click="modifyRow(scope.$index, tempcalendar,scope.row)" type="text" size="small">修改
					</el-button>
					<el-button type="text" size="small" @click="deleteRow(scope.$index, tempcalendar,scope.row)">删除
					</el-button>
				</template>
			</el-table-column>
		</el-table>
		<el-dialog :title="title" :visible.sync="dialogFormVisible">
			<el-form :model="form" :rules="rules" ref="form">
				<el-form-item label="选择日期" prop="schedule_date" :label-width="formLabelWidth">
					<div class="block">
						<el-date-picker v-model="form.schedule_date" align="right" type="date" placeholder="选择日期"
							:picker-options="pickerOptions">
						</el-date-picker>
					</div>
				</el-form-item>
				<el-form-item label="选择开始时间" prop="start_time" :label-width="formLabelWidth">
					<el-time-picker v-model="form.start_time" placeholder="请选择开始时间">
					</el-time-picker>
				</el-form-item>
				<el-form-item label="选择结束时间" prop="ask_endtime" :label-width="formLabelWidth">
					<el-time-picker v-model="form.ask_endtime" placeholder="请选择结束时间">
					</el-time-picker>
				</el-form-item>
				<el-form-item label="任务主题" prop="schedule_name" :label-width="formLabelWidth">
					<el-input v-model="form.schedule_name" placeholder="请输入任务名称" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="任务描述" prop="schedule_content" :label-width="formLabelWidth">
					<el-input v-model="form.schedule_content" placeholder="请输入具体日程任务描述" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="提醒类型" prop="remind_type" :label-width="formLabelWidth">
					<el-select v-model="form.remind_type" placeholder="请选择提醒类型">
						<el-option label="按日提醒" value="按日提醒"></el-option>
						<el-option label="按周提醒" value="按周提醒"></el-option>
						<el-option label="按月提醒" value="按月提醒"></el-option>
					</el-select>
				</el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click="cancel($canceled)">取 消</el-button>
				<el-button type="primary" @click="save('form')">确 定</el-button>
			</div>
		</el-dialog>
	</el-main>
</template>

<script>
	export default {
		created() {

			let that = this
			this.$axios({
				method: 'get',
				url: 'http://localhost:8888/staff/findStaffByAccount?account=' + that.getCookie("account")
			}).then(function(response) {
				that.job_num = response.data.job_num
				that.$axios({
					method: 'get',
					url: 'http://localhost:8888/personalschedule/showpersonalschedule?job_num=' + that
						.job_num +
						'&schedule_type=周期性任务'
				}).then(function(response) {
					that.calendar = response.data
					that.tempcalendar = that.calendar.slice(0, that.pageSize)
					for (let i in that.calendar) {
						console.log(that.calendar[i].start_time)
						if (that.calendar[i].start_time.length > 11) {
							// that.calendar[i].start_time = that.calendar[i].start_time.substring(11, 19);
							let str = that.calendar[i].start_time.substring(11, 13);
							console.log("", str)
							//alert(str);
							if (str == '00') {
								that.calendar[i].start_time = "08" + that.calendar[i].start_time.substring(
									13, 19);
							} else if (str == '01') {
								that.calendar[i].start_time = "09" + that.calendar[i].start_time.substring(
									13, 19);
							} else if (str == '02') {
								that.calendar[i].start_time = "10" + that.calendar[i].start_time.substring(
									13, 19);
							} else if (str == '03') {
								that.calendar[i].start_time = "11" + that.calendar[i].start_time.substring(
									13, 19);
							} else if (str == '04') {
								that.calendar[i].start_time = "12" + that.calendar[i].start_time.substring(
									13, 19);
							} else if (str == '05') {
								that.calendar[i].start_time = "13" + that.calendar[i].start_time.substring(
									13, 19);
							} else if (str == '06') {
								that.calendar[i].start_time = "14" + that.calendar[i].start_time.substring(
									13, 19);
							} else if (str == '07') {
								that.calendar[i].start_time = "15" + that.calendar[i].start_time.substring(
									13, 19);
							} else if (str == '08') {
								that.calendar[i].start_time = "16" + that.calendar[i].start_time.substring(
									13, 19);
							} else if (str == '09') {
								that.calendar[i].start_time = "17" + that.calendar[i].start_time.substring(
									13, 19);
							} else if (str == '10') {
								that.calendar[i].start_time = "18" + that.calendar[i].start_time.substring(
									13, 19);
							} else if (str == '11') {
								that.calendar[i].start_time = "19" + that.calendar[i].start_time.substring(
									13, 19);
							} else if (str == '12') {
								that.calendar[i].start_time = "20" + that.calendar[i].start_time.substring(
									13, 19);
							} else if (str == '13') {
								that.calendar[i].start_time = "21" + that.calendar[i].start_time.substring(
									13, 19);
							} else if (str == '14') {
								that.calendar[i].start_time = "22" + that.calendar[i].start_time.substring(
									13, 19);
							} else if (str == '15') {
								that.calendar[i].start_time = "23" + that.calendar[i].start_time.substring(
									13, 19);
							} else if (str == '16') {
								that.calendar[i].start_time = "00" + that.calendar[i].start_time.substring(
									13, 19);
							} else if (str == '17') {
								that.calendar[i].start_time = "01" + that.calendar[i].start_time.substring(
									13, 19);
							} else if (str == '18') {
								that.calendar[i].start_time = "02" + that.calendar[i].start_time.substring(
									13, 19);
							} else if (str == '19') {
								that.calendar[i].start_time = "03" + that.calendar[i].start_time.substring(
									13, 19);
							} else if (str == '20') {
								that.calendar[i].start_time = "04" + that.calendar[i].start_time.substring(
									13, 19);
							} else if (str == '21') {
								that.calendar[i].start_time = "05" + that.calendar[i].start_time.substring(
									13, 19);
							} else if (str == '22') {
								that.calendar[i].start_time = "06" + that.calendar[i].start_time.substring(
									13, 19);
							} else if (str == '23') {
								that.calendar[i].start_time = "07" + that.calendar[i].start_time.substring(
									13, 19);
							}

							console.log("<<<<<<<<<" + that.calendar[i].start_time)
						}
						if (that.calendar[i].ask_endtime.length > 11) {
							//that.calendar[i].ask_endtime = that.calendar[i].ask_endtime.substring(11, 19);
							let str = that.calendar[i].ask_endtime.substring(11, 13);
							console.log("", str)
							//alert(str);
							if (str == '00') {
								that.calendar[i].ask_endtime = "08" + that.calendar[i].ask_endtime
									.substring(
										13, 19);
							} else if (str == '01') {
								that.calendar[i].ask_endtime = "09" + that.calendar[i].ask_endtime
									.substring(
										13, 19);
							} else if (str == '02') {
								that.calendar[i].ask_endtime = "10" + that.calendar[i].ask_endtime
									.substring(
										13, 19);
							} else if (str == '03') {
								that.calendar[i].ask_endtime = "11" + that.calendar[i].ask_endtime
									.substring(
										13, 19);
							} else if (str == '04') {
								that.calendar[i].ask_endtime = "12" + that.calendar[i].ask_endtime
									.substring(
										13, 19);
							} else if (str == '05') {
								that.calendar[i].ask_endtime = "13" + that.calendar[i].ask_endtime
									.substring(
										13, 19);
							} else if (str == '06') {
								that.calendar[i].ask_endtime = "14" + that.calendar[i].ask_endtime
									.substring(
										13, 19);
							} else if (str == '07') {
								that.calendar[i].ask_endtime = "15" + that.calendar[i].ask_endtime
									.substring(
										13, 19);
							} else if (str == '08') {
								that.calendar[i].ask_endtime = "16" + that.calendar[i].ask_endtime
									.substring(
										13, 19);
							} else if (str == '09') {
								that.calendar[i].ask_endtime = "17" + that.calendar[i].ask_endtime
									.substring(
										13, 19);
							} else if (str == '10') {
								that.calendar[i].ask_endtime = "18" + that.calendar[i].ask_endtime
									.substring(
										13, 19);
							} else if (str == '11') {
								that.calendar[i].ask_endtime = "19" + that.calendar[i].ask_endtime
									.substring(
										13, 19);
							} else if (str == '12') {
								that.calendar[i].ask_endtime = "20" + that.calendar[i].ask_endtime
									.substring(
										13, 19);
							} else if (str == '13') {
								that.calendar[i].ask_endtime = "21" + that.calendar[i].ask_endtime
									.substring(
										13, 19);
							} else if (str == '14') {
								that.calendar[i].ask_endtime = "22" + that.calendar[i].ask_endtime
									.substring(
										13, 19);
							} else if (str == '15') {
								that.calendar[i].ask_endtime = "23" + that.calendar[i].ask_endtime
									.substring(
										13, 19);
							} else if (str == '16') {
								that.calendar[i].ask_endtime = "00" + that.calendar[i].ask_endtime
									.substring(
										13, 19);
							} else if (str == '17') {
								that.calendar[i].ask_endtime = "01" + that.calendar[i].ask_endtime
									.substring(
										13, 19);
							} else if (str == '18') {
								that.calendar[i].ask_endtime = "02" + that.calendar[i].ask_endtime
									.substring(
										13, 19);
							} else if (str == '19') {
								that.calendar[i].ask_endtime = "03" + that.calendar[i].ask_endtime
									.substring(
										13, 19);
							} else if (str == '20') {
								that.calendar[i].ask_endtime = "04" + that.calendar[i].ask_endtime
									.substring(
										13, 19);
							} else if (str == '21') {
								that.calendar[i].ask_endtime = "05" + that.calendar[i].ask_endtime
									.substring(
										13, 19);
							} else if (str == '22') {
								that.calendar[i].ask_endtime = "06" + that.calendar[i].ask_endtime
									.substring(
										13, 19);
							} else if (str == '23') {
								that.calendar[i].ask_endtime = "07" + that.calendar[i].ask_endtime
									.substring(
										13, 19);
							}
							console.log("<<<<<<<<<" + that.calendar[i].ask_endtime)
						}
					}
					console.log(that.calendar)
				})

			})
		},
		data() {
			return {
				pickerOptions: {
					disabledDate(time) {
						return time.getTime() > Date.now();
					},
					shortcuts: [{
						text: '今天',
						onClick(picker) {
							picker.$emit('pick', new Date());
						}
					}, {
						text: '昨天',
						onClick(picker) {
							const date = new Date();
							date.setTime(date.getTime() - 3600 * 1000 * 24);
							picker.$emit('pick', date);
						}
					}, {
						text: '一周前',
						onClick(picker) {
							const date = new Date();
							date.setTime(date.getTime() - 3600 * 1000 * 24 * 7);
							picker.$emit('pick', date);
						}
					}]
				},
				schedule_date: '',
				job_num: '',
				calendar: [],
				pageSize: 7,
				tempcalendar: [],
				value: false,
				dialogFormVisible: false,
				formLabelWidth: '120px',
				form: {
					schedule_name: '',
					schedule_content: '',
					schedule_date: '',
					schedule_type: "周期性任务",
					start_time: '',
					ask_endtime: '',
					concrete_schedulecontent: '',
					remind_type: '',
					job_num: '',
				},
				rules: {
					schedule_name: [{
						required: true,
						message: '请输入任务名称',
						trigger: 'blur'
					}, ],
					schedule_content: [{
						required: true,
						message: '请输入日程内容',
						trigger: 'blur'
					}, ],
					schedule_date: [{
						required: true,
						message: '请输入日程开始日期',
						trigger: 'change'
					}, ],
					start_time: [{
						required: true,
						message: '请输入日程开始时间',
						trigger: 'change'
					}, ],
					ask_endtime: [{
						required: true,
						message: '请选择日程时间',
						trigger: 'change'
					}],
					remind_type: [{
						required: true,
						message: '请选择日程提醒类型',
						trigger: 'change'
					}]
				}
			}
		},
		methods: {
			getCookie: function(key) {
				if (document.cookie.length > 0) {
					var start = document.cookie.indexOf(key + '=')
					if (start !== -1) {
						start = start + key.length + 1
						var end = document.cookie.indexOf(';', start)
						if (end === -1) end = document.cookie.length
						return unescape(document.cookie.substring(start, end))
					}
				}
				return ''
			},
			cancel() {
				this.dialogFormVisible = false
				this.timer = setTimeout(() => { //设置延迟执行
					this.$router.go(0);
				}, 0.1);
			},
			//新增、修改保存
			save(formName) {
				this.$refs[formName].validate((valid) => {
					if (valid) {
						let that = this
						if (this.title == "新建周期性任务") {
							if(this.form.start_time>this.form.ask_endtime)
							{
								that.$message({
									showClose: true,
									message: '开始时间不能小于结束时间',
									type: 'error',
									offset: 300
								});
							}
							else{
							this.form.job_num = this.job_num
							this.$axios({
								method: 'post',
								url: 'http://localhost:8888/personalschedule/addpersonalschedule',
								data: that.form
							}).then(function() {
								that.$message({
									showClose: true,
									message: '添加周期性任务成功',
									type: 'success',
									offset: 300
								});
							})
						this.dialogFormVisible = false
						this.timer = setTimeout(() => { //设置延迟执行
							this.$router.go(0);
						}, 0.1);
						}
						} else if (this.title == "修改周期性任务") {
							if(this.form.start_time>this.form.ask_endtime)
							{
								that.$message({
									showClose: true,
									message: '开始时间不能小于结束时间',
									type: 'error',
									offset: 300
								});
							}
							else{
							this.$axios({
								method: 'post',
								url: 'http://localhost:8888/personalschedule/updatepersonalschedule',
								data: that.form
							}).then(function() {
								that.$message({
									showClose: true,
									message: '修改周期性任务成功',
									type: 'success',
									offset: 300
								});
							})
							this.dialogFormVisible = false
							this.timer = setTimeout(() => { //设置延迟执行
								this.$router.go(0);
							}, 0.1);
							}
							
						}
					} else {
						console.log('error submit!!');
						return false;
					}
				})
			},
			//修改周期性任务
			modifyRow(index, rows, row) {
				this.title = "修改周期性任务"
				this.form = row
				this.form.start_time = new Date(Date.now())
				this.form.ask_endtime = new Date(Date.now())
				console.log(this.form)
				this.dialogFormVisible = true
			},
			//新建周期性任务
			addWeekTask() {
				this.title = "新建周期性任务"
				this.form.schedule_name = '',
					this.form.schedule_content = '',
					this.form.schedule_date = '',
					this.form.schedule_type = "周期性任务",
					this.form.start_time = '',
					this.form.ask_endtime = '',
					this.form.concrete_schedulecontent = '',
					this.form.remind_type = '',
					this.form.job_num = 1,
					this.dialogFormVisible = true
			},
			//页码切换
			handleCurrentChange(currentPage) {
				this.currentPage = currentPage;
				this.currentChangePage(this.calendar, currentPage);
			},
			//分页实现
			currentChangePage(list, currentPage) {
				let from = (currentPage - 1) * this.pageSize;
				let to = currentPage * this.pageSize;
				this.tempcalendar = this.calendar.slice(from, to);
			},
			//删除数据
			deleteRow(index, rows, row) {
				this.$confirm('此操作将永久删除周期性任务, 是否继续?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
				}).then(() => {
				let e = rows.splice(index, 1) //删除表格中的一行
				//将删除请求传递回后端，进行数据库删除
				let schedule_id = row.schedule_id
				let that = this
				this.$axios({
					method: 'get',
					url: 'http://localhost:8888/personalschedule/delpersonalschedule?schedule_id=' + schedule_id
				}).then(function() {
					that.$message({
						message: '恭喜您，删除成功！！！！',
						type: 'success',
						offset: 300
					});
				})})
				// this.timer = setTimeout(() => { //设置延迟执行
				// 	this.$router.go(0);
				// }, 0.1);
			}
		}
	}
</script>
<style>
	.head {
		font-weight: bold;
		font-size: 20px;

	}
</style>
