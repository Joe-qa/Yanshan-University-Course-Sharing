package com.jz.xdkjoa.service.logistics;


import com.jz.xdkjoa.pojo.logistics.CarRecord;

import java.util.List;

public interface CarRecordService {
    void addCarRecordBiz(CarRecord carRecord);
    void delCarRecordBiz(Integer record_num);
    List<CarRecord>showByCarNumRecordBiz(String car_num);
    List<CarRecord>showAllCarRecordBiz(String situation);

}
