package com.jz.xdkjoa.controllers.logistics;

import com.jz.xdkjoa.pojo.logistics.Equipment;
import com.jz.xdkjoa.service.logistics.EquipmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * @Author zxq
 * @Date 2021-6-19 18:49
 */
@CrossOrigin
@RestController
@RequestMapping("/EquipmentMsg")
public class EquipmentController {
    @Autowired
    EquipmentService equipmentService;

    @GetMapping("addEquipmentMsg")
    public String addEquipmentMsg(){
        Equipment equipment=new Equipment();
        equipment.setEquipment_num(1);
        equipment.setEquipment_name("服务器");
        equipment.setEquipment_situation("损坏过一次");
        equipment.setUse_situation("使用中");
        equipment.setEquipment_life(5);
        equipmentService.addEquipmentMsgBiz(equipment);
        return "hello";
    }
    @PostMapping("showAllEquipment")
    public List showAllEquipment(){
        List<Equipment> list=equipmentService.showAllEquipmentBiz();
        for(Equipment e:list){
            System.out.println(e.toString());
        }
        return list;
    }
}
