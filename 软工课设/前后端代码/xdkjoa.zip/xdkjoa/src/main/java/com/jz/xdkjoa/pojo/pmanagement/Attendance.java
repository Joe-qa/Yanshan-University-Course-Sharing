package com.jz.xdkjoa.pojo.pmanagement;

import java.sql.Time;
import java.util.Date;

public class Attendance {
    int attendance_id;
    int job_num;
    Date work_date;
    Time in_time;
    String in_status;
    Time out_time;
    String out_status;
    Boolean is_leave;

    public Attendance() {
    }

    public Attendance(int attendance_id, int job_num, Date work_date, Time in_time, String in_status, Time out_time, String out_status, Boolean is_leave) {
        this.attendance_id = attendance_id;
        this.job_num = job_num;
        this.work_date = work_date;
        this.in_time = in_time;
        this.in_status = in_status;
        this.out_time = out_time;
        this.out_status = out_status;
        this.is_leave = is_leave;
    }

    public int getAttendance_id() {
        return attendance_id;
    }

    public void setAttendance_id(int attendance_id) {
        this.attendance_id = attendance_id;
    }

    public int getJob_num() {
        return job_num;
    }

    public void setJob_num(int job_num) {
        this.job_num = job_num;
    }

    public Date getWork_date() {
        return work_date;
    }

    public void setWork_date(Date work_date) {
        this.work_date = work_date;
    }

    public Time getIn_time() {
        return in_time;
    }

    public void setIn_time(Time in_time) {
        this.in_time = in_time;
    }

    public String getIn_status() {
        return in_status;
    }

    public void setIn_status(String in_status) {
        this.in_status = in_status;
    }

    public Time getOut_time() {
        return out_time;
    }

    public void setOut_time(Time out_time) {
        this.out_time = out_time;
    }

    public String getOut_status() {
        return out_status;
    }

    public void setOut_status(String out_status) {
        this.out_status = out_status;
    }

    public Boolean getIs_leave() {
        return is_leave;
    }

    public void setIs_leave(Boolean is_leave) {
        this.is_leave = is_leave;
    }

    @Override
    public String toString() {
        return "Attendance{" +
                "attendance_id=" + attendance_id +
                ", job_num=" + job_num +
                ", work_date=" + work_date +
                ", in_time=" + in_time +
                ", in_status='" + in_status + '\'' +
                ", out_time=" + out_time +
                ", out_status='" + out_status + '\'' +
                ", is_leave=" + is_leave +
                '}';
    }
}
