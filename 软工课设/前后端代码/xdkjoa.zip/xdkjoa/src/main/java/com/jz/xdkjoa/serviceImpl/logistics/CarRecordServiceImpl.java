package com.jz.xdkjoa.serviceImpl.logistics;

import com.jz.xdkjoa.mapper.logistics.CarRecordMapper;
import com.jz.xdkjoa.pojo.logistics.CarRecord;
import com.jz.xdkjoa.service.logistics.CarRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CarRecordServiceImpl implements CarRecordService {
    //依赖注入  spring会自动将实现类的对象装配进引用来

    @Autowired(required = false)
    CarRecordMapper carrecordmapper;

    @Override
    public void addCarRecordBiz(CarRecord carRecord){
        carrecordmapper.addCarRecord(carRecord);
    }

    @Override
    public void delCarRecordBiz(Integer record_num){
        carrecordmapper.delCarRecord(record_num);
    }

    @Override
    public List<CarRecord>showByCarNumRecordBiz(String car_num){
        return  carrecordmapper.showByCarNumRecord(car_num);
    }
    @Override
    public List<CarRecord>showAllCarRecordBiz(String situation){
        return carrecordmapper.showAllCarRecord(situation);
    }



}
