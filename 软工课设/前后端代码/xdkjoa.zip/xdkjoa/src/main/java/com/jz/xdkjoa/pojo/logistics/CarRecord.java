package com.jz.xdkjoa.pojo.logistics;



import java.util.Date;

public class CarRecord {
    private int record_num;
    private int job_num;
    private String car_num;
    private Date really_time;
    private Date return_time;
    private Date borrow_time;
    private String use_reason;

    private CarMsg carMsg;

    public CarMsg getCarMsg() {
        return carMsg;
    }

    public void setCarMsg(CarMsg carMsg) {
        this.carMsg = carMsg;
    }

    public CarRecord() {
    }

    public CarRecord(int record_num, int job_num, String car_num, Date really_time, Date return_time, Date borrow_time, String use_reason) {
        this.record_num = record_num;
        this.job_num = job_num;
        this.car_num = car_num;
        this.really_time = really_time;
        this.return_time = return_time;
        this.borrow_time = borrow_time;
        this.use_reason = use_reason;
    }

    @Override
    public String toString() {
        return "CarRecord{" +
                "record_num=" + record_num +
                ", job_num=" + job_num +
                ", car_num='" + car_num + '\'' +
                ", really_time=" + really_time +
                ", return_time=" + return_time +
                ", borrow_time=" + borrow_time +
                ", use_reason=" + use_reason +
                '}';
    }

    public int getRecord_num() {
        return record_num;
    }

    public void setRecord_num(int record_num) {
        this.record_num = record_num;
    }

    public int getJob_num() {
        return job_num;
    }

    public void setJob_num(int job_num) {
        this.job_num = job_num;
    }

    public String getCar_num() {
        return car_num;
    }

    public void setCar_num(String car_num) {
        this.car_num = car_num;
    }

    public Date getReally_time() {
        return really_time;
    }

    public void setReally_time(Date really_time) {
        this.really_time = really_time;
    }

    public Date getReturn_time() {
        return return_time;
    }

    public void setReturn_time(Date return_time) {
        this.return_time = return_time;
    }

    public Date getBorrow_time() {
        return borrow_time;
    }

    public void setBorrow_time(Date borrow_time) {
        this.borrow_time = borrow_time;
    }

    public String getUse_reason() {
        return use_reason;
    }

    public void setUse_reason(String use_reason) {
        this.use_reason = use_reason;
    }
}