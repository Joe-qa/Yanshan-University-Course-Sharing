<template>
	<div>
		<el-row :gutter="20">
			<el-col :span="4" style="text-align: center;vertical-align: middle;">
				<h2 style="margin-right: 30px;">公司发展历程</h2>

<!-- 			</el-col>
			<el-col :span="4"> -->
				<div class="block" style="margin-top: 40px;">
					<el-timeline>
						<el-timeline-item v-for="(activity, index) in activities" :key="index" :icon="activity.icon"
							:type="activity.type" :color="activity.color" :size="activity.size"
							style="font-size: 20px;">
							<el-collapse @change="handleChange">
								<el-collapse-item :title="activity.title">
									<div>{{activity.content}}</div>
								</el-collapse-item>
							</el-collapse>
						</el-timeline-item>
					</el-timeline>
				</div>
			</el-col>
			<el-col :span="16" style="margin-left: 100px;">
				<h2 style="margin-right: 30px;">公司报表</h2>
				<div>
	<!-- 				<el-carousel :interval="3000" type="card" height="250px">
						<el-carousel-item key=1>
							<div class="demo-image__preview">
								<el-image style="width: 100px; height: 100px" src="../assets/img/pic1.jpg"
									fit="contain"></el-image>
							</div>

							
						</el-carousel-item>
						<el-carousel-item key=2>
							<el-image style="width: 100px; height: 100px" src="../assets/img/pic2.jpg" fit="fill">
							</el-image>

						</el-carousel-item>
						<el-carousel-item key=3>
							<el-image style="width: 100px; height: 100px" src="../assets/img/pic3.jpg" fit="cover">
							</el-image>
						</el-carousel-item>
						<el-carousel-item key=4>
							<el-image style="width: 100px; height: 100px" src="@/assets/img/pic4.jpg" fit="fill">
							</el-image>
						</el-carousel-item>

					</el-carousel> -->
					
					
					<!-- <h3 style="font-size: 20px; color: #524cff; padding-left: 550px; ">公司工作总结</h3> -->
							<br />
							<el-tabs :tab-position="tabPosition" style="height: fit-content;padding-left: 50px;">
								<el-tab-pane label="部门开支情况">
									<div style="width:800px;height:500px;" ref="chart"></div>
								</el-tab-pane>
							<!-- 	<el-tab-pane label="员工绩效情况">
									<el-tabs :tab-position="tabPosition1" style="height: 700px;">
										<el-tab-pane label="财务部">
											<div style="width:600px;height:500px;" ref="chart11"></div>
										</el-tab-pane>
										<el-tab-pane label="人事部">
											<div style="width:800px;height:500px;" ref="chart12"></div>
										</el-tab-pane>
										<el-tab-pane label="业务部一">
											<div style="width:800px;height:500px;" ref="chart13"></div>
										</el-tab-pane>
										<el-tab-pane label="业务部二">
											<div style="width:800px;height:500px;" ref="chart14"></div>
										</el-tab-pane>
										<el-tab-pane label="业务部三">
											<div style="width:800px;height:500px;" ref="chart15"></div>
										</el-tab-pane>
									</el-tabs>
								</el-tab-pane> -->
								<el-tab-pane label="各部门开支占比">
									<div style="width:800px;height:500px;" ref="chart2"></div>
								</el-tab-pane>
								<el-tab-pane label="各部门工资">
									<div style="width:800px;height:500px;" ref="chart3"></div>
								</el-tab-pane>
							</el-tabs>
				</div>
			</el-col>
		</el-row>
		
	</div>
</template>

<script>
	export default {
		name: 'App',
		mounted() {
			this.initCharts();
		},
		data() {
			return {
				urlPath: '',
				activities: [{
						title: '成立初期',
						content: '2018.09，公司在秦皇岛成立，成立初期只有5人',
						timestamp: '2018-09-1',
						size: 'large',
						type: 'primary',
						icon: 'el-icon-more',
						color: '#aaaaff'
					}, {
						title: '运筹起步',
						content: '公司一步步发展，逐渐扩大规模',
						timestamp: '2019-01-01',
						size: 'large',
						icon: 'el-icon-s-home',
						color: '#0bbd87'
					}, {
						title: '小有所成',
						content: '公司有了一定的收入',
						timestamp: '2019-09-01',
						icon: 'el-icon-star-off',
						size: 'large',
						color: '#ff557f'
					}, {
						title: '稳定成熟',
						content: '公司成熟发展，有多家分公司',
						timestamp: '2020-05-03',
						icon: 'el-icon-coordinate',
						size: 'large',
						color: '#ffff7f'
					},
					{
						title: '跨越未来',
						content: '公司有着美好的未来',
						timestamp: '2021-07-01',
						icon: 'el-icon-trophy',
						size: 'large',
						color: '#55ff00'
					}
				],

			}
		},
		created() {

			//   let that=this
			//  	this.$axios({
			// 	method:'get',
			// 	url:'http://localhost:8888/staff/showStaffById?job_num=1'
			// }).then(function(res){
			// 	 that.urlPath="http://localhost:8888/upload/"+res.data.image
			// })
		},
		methods: {
			initCharts() {
							let depSpend = this.$echarts.init(this.$refs.chart);
							let insPur = this.$echarts.init(this.$refs.chart2);
							let depSal = this.$echarts.init(this.$refs.chart3);
			
							// 绘制图表
			
							depSpend.setOption({
									color: '#aaaaff',
									title: {
										text: '公司各部门开支情况（万元）'
									},
									tooltip: {},
									xAxis: {
										data: ["财务部", "研发部", "人事部", "行政部", "计划营销部","保卫部","后勤部"]
									},
									yAxis: {},
									series: [{
										name: '支出',
										type: 'bar',
										data: [50, 70, 80, 88,100,30,30]
									}]
								}),
								depSal.setOption({
									color: '#aaaaff',
									title: {
										text: '公司各部门工资情况（万元）'
									},
									tooltip: {},
									xAxis: {
										data: ["财务部", "研发部", "人事部", "行政部", "计划营销部","保卫部","后勤部"]
									},
									yAxis: {},
									series: [{
										name: '工资',
										type: 'bar',
										data: [50, 100, 80,36,50,30,25]
									}]
								}),
								insPur.setOption({
									title: {
										text: '各部门开支占比',
										left: 'center'
									},
									tooltip: {
										trigger: 'item'
									},
									legend: {
										orient: 'vertical',
										left: 'left',
									},
									series: [{
			
										type: 'pie',
										radius: '50%',
										data: [{
												value: 50,
												name: '财务部'
											},
											{
												value: 100,
												name: '研发部'
										    },
											{
												value: 50,
												name: '人事部'
											},
											{
												value: 60,
												name: '行政部'
											},
											{
												value: 36,
												name: '计划营销部'
											},
											{
												value: 30,
												name: '保卫部'
											},
											{
												value: 20,
												name: '后勤部'
											}
										],
										emphasis: {
											itemStyle: {
												shadowBlur: 10,
												shadowOffsetX: 0,
												shadowColor: 'rgba(0, 0, 0, 0.5)'
											}
										}
									}]
								}),
								staffPero1.setOption({
									color: '#aaaaff',
									title: {
										text: '公司财务部员工工资（元）'
									},
									tooltip: {
										trigger: 'axis',
										axisPointer: { // 坐标轴指示器，坐标轴触发有效
											type: 'line' // 默认为直线，可选为：'line' | 'shadow'
										}
									},
									grid: {
										left: '3%',
										right: '4%',
										bottom: '3%',
										containLabel: true
									},
									xAxis: [{
										type: 'category',
										data: ['小刘', '小马', '小张', '小路', '老马', '老铁', '老石'],
										axisTick: {
											alignWithLabel: true
										}
									}],
									yAxis: [{
										type: 'value'
									}],
									series: [{
										name: '工资',
										type: 'bar',
										barWidth: '60%',
										data: [5000, 6000, 7000, 8000, 6000, 5000, 7530]
									}]
								}),
								staffPero2.setOption({
									color: '#aaaaff',
									tooltip: {
										trigger: 'axis',
										axisPointer: { // 坐标轴指示器，坐标轴触发有效
											type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
										}
									},
									grid: {
										left: '3%',
										right: '4%',
										bottom: '3%',
										containLabel: true
									},
									xAxis: [{
										type: 'category',
										data: ['老张', '老刘', '小马', '小美', '老郝', '老雷'],
										axisTick: {
											alignWithLabel: true
										}
									}],
									yAxis: [{
										type: 'value'
									}],
									series: [{
										name: '工资',
										type: 'bar',
										barWidth: '60%',
										data: [5000, 5200, 7500, 6334, 5390, 6330]
									}]
								}),
								staffPero3.setOption({
									color: '#aaaaff',
									tooltip: {
										trigger: 'axis',
										axisPointer: { // 坐标轴指示器，坐标轴触发有效
											type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
										}
									},
									grid: {
										left: '3%',
										right: '4%',
										bottom: '3%',
										containLabel: true
									},
									xAxis: [{
										type: 'category',
										data: ['老马', '老张', '牛哥', '张三', '老铁', '小王', '小林'],
										axisTick: {
											alignWithLabel: true
										}
									}],
									yAxis: [{
										type: 'value'
									}],
									series: [{
										name: '工资',
										type: 'bar',
										barWidth: '60%',
										data: [10000, 12052, 15200, 23000,
											13390, 15330, 15200
										]
									}],
			
								}),
								staffPero4.setOption({
									color: '#aaaaff',
									tooltip: {
										trigger: 'axis',
										axisPointer: { // 坐标轴指示器，坐标轴触发有效
											type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
										}
									},
									grid: {
										left: '3%',
										right: '4%',
										bottom: '3%',
										containLabel: true
									},
									xAxis: [{
										type: 'category',
										data: ['老马', '老张', 'Jone', '小孟', '老铁', '小王', '小林'],
										axisTick: {
											alignWithLabel: true
										}
									}],
									yAxis: [{
										type: 'value'
									}],
									series: [{
										name: '工资',
										type: 'bar',
										barWidth: '60%',
										data: [9899, 12052, 16250, 21000,
											14620, 17560, 15200
										]
									}],
								}),
								staffPero5.setOption({
										color: '#aaaaff',
										tooltip: {
											trigger: 'axis',
											axisPointer: { // 坐标轴指示器，坐标轴触发有效
												type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
											}
										},
										grid: {
											left: '3%',
											right: '4%',
											bottom: '3%',
											containLabel: true
										},
										xAxis: [{
											type: 'category',
											data: ['老马', '老张', '小妞', '小杨', '老纪', '小王', '小林'],
			
										}],
										yAxis: [{
											type: 'value'
										}],
										series: [{
												name: '工资',
												type: 'bar',
												barWidth: '60%',
												data: [16520, 12052, 15200, 21000,
													8999, 25400,16000]
												}],
										})
								}
		}
	}
</script>

<style>
	.text {
			font-size: 14px;
		}
	
		.item {
			margin-bottom: 18px;
		}
	
	
		.box-card {
			width: 600px;
		}
	.el-row {
		margin-bottom: 20px;

		&:last-child {
			margin-bottom: 0;
		}
	}

	.el-col {
		border-radius: 4px;
	}

	.bg-purple-dark {
		background: #99a9bf;
	}

	.bg-purple {
		background: #d3dce6;
	}

	.bg-purple-light {
		background: #e5e9f2;
	}

	.grid-content {
		border-radius: 4px;
		min-height: 36px;
	}

	.row-bg {
		padding: 10px 0;
		background-color: #f9fafc;
	}
</style>
