package com.jz.xdkjoa.service.logistics;

import com.jz.xdkjoa.pojo.logistics.Equipment;

import java.util.List;

public interface EquipmentService {
    void addEquipmentMsgBiz(Equipment equipment);
    List<Equipment> showAllEquipmentBiz();
}
