package com.jz.xdkjoa.serviceImpl.logistics;

import com.jz.xdkjoa.mapper.logistics.CarMsgMapper;
import com.jz.xdkjoa.pojo.logistics.CarMsg;
import com.jz.xdkjoa.service.logistics.CarMsgService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CarMsgServiceImpl implements CarMsgService {
    //依赖注入  spring会自动将实现类的对象装配进引用来
    @Autowired(required = false)
    CarMsgMapper carmsgmapper;

    @Override
    public List<CarMsg> getCarMsgsBiz() {
        return carmsgmapper.getCarMsgs();
    }

    @Override
    public List<CarMsg>showByStateBiz(String situation){
        return carmsgmapper.showByState(situation);
    }

    @Override
    public List<CarMsg>showByCarNumBiz(String car_num){
        return carmsgmapper.showByCarNum(car_num);
    }

    @Override
    public void addCarBiz(CarMsg carmsg){
        carmsgmapper.addCar(carmsg);
    }

    @Override
    public void updateCarStateBiz(String car_num){
        carmsgmapper.updateCarState(car_num);
    }


}
