package com.jz.xdkjoa.mapper.administration;

import com.jz.xdkjoa.pojo.administration.ContractForm;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;

import java.util.Date;
import java.util.List;

@Mapper
public interface ContractFormMapper {
    void addContract(ContractForm contract);
    @Delete("delete from contract_form where contract_num=#{contract_num}")
    void delContract(int contract_num);
    List<ContractForm> findContract( String contractstate);
    List<ContractForm> showContract();

}
