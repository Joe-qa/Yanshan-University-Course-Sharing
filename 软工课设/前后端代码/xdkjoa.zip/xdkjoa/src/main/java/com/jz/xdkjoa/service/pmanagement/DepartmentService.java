package com.jz.xdkjoa.service.pmanagement;

import com.jz.xdkjoa.pojo.pmanagement.Department;

import java.util.List;

public interface DepartmentService {
    String findNameByNumBiz(Integer depart_num);
    List<Department> showAllDepartmentsBiz();
}
