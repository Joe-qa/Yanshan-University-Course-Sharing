package com.jz.xdkjoa.serviceImpl.administration;

import com.jz.xdkjoa.mapper.administration.BusinessCalendarMapper;
import com.jz.xdkjoa.pojo.administration.BusinessCalendar;
import com.jz.xdkjoa.service.administration.BusinessCalendarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BusinessCalendarServiceImpl implements BusinessCalendarService {
    //依赖注入 spring会自动的将实现类的对象装备进引用中
    @Autowired(required = false)
    BusinessCalendarMapper businesscalendarmapper;
    //增加日程表的一条日晨
    @Override
    public  void addHeadlineBiz(BusinessCalendar headline){
    businesscalendarmapper.addHeadline(headline);
    }
    //删除日程表的一条日程
    @Override
    public void delCalendarBiz(int schedule_num) {
        businesscalendarmapper.delCalendar(schedule_num);
    }
    //显示日程
    @Override
    public List<BusinessCalendar> showBusinessCalendarBiz(){return businesscalendarmapper.showBusinessCalendar();}
    //更新日程
    @Override
    public  void updateCalendarBiz( BusinessCalendar calendar){businesscalendarmapper.updateCalendar(calendar);}
}
