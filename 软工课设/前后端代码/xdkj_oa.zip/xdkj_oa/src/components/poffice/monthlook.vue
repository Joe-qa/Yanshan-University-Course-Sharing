<template>
  <div class="block" style="display: flex;flex-direction: row;">
    <!-- 日历控件 -->

    <el-calendar>
      <template slot="dateCell" slot-scope="{date, data}">
        <el-scrollbar style="height: 100%;">
          <div class="data.isSelected ? 'is-selected' : ''" @click="fun($event,data.day)">
            {{ data.day.split('-').slice(1).join('-') }}</br>
            <span style="font-size:10px" v-for="item in calendar" @click="display(item.businessCalendar.headline)">
              {{checkNotice(item,data.day)?'✔️'+item.businessCalendar.headline:''}}
              <span v-if="checkNotice(item,data.day)"></br></span>
            </span>
          </div>
        </el-scrollbar>
      </template>
    </el-calendar>

    <el-dialog title="系统日程" :visible.sync="dialogFormVisible1">
      <el-table :data="name" tooltip-effect="dark" style="width: 100%">
        <template slot-scope="scope">
          <el-table-column prop="businessCalendar.schedule_num" label="日程id">
          </el-table-column>
          <el-table-column prop="businessCalendar.headline" label="日程主题">
          </el-table-column>
        </template>
      </el-table>
    </el-dialog>

    <el-dialog title="个人日程" :visible.sync="dialogFormVisible">
      <el-form :model="form">
        <el-form-item visible="false" label="日程编号" prop="schedule_id" :label-width="formLabelWidth">
          <el-input v-model="form.schedule_id" placeholder="请输入日程编号" autocomplete="off" readonly="true"></el-input>
        </el-form-item>
        <el-form-item label="日程名称" prop="schedule_name" :label-width="formLabelWidth">
          <el-input v-model="form.schedule_name" placeholder="请输入主题" autocomplete="off" readonly="true"></el-input>
        </el-form-item>
        <el-form-item label="日程内容" prop="schedule_content" :label-width="formLabelWidth">
          <el-input v-model="form.schedule_content" placeholder="请输入日程内容" autocomplete="off" readonly="true"></el-input>
        </el-form-item>
        <el-form-item label="选择开始时间" prop="start_time" :label-width="formLabelWidth">
          <el-date-picker v-model="form.start_time" type="date" placeholder="开始时间">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="选择结束时间" prop="ask_endtime" :label-width="formLabelWidth">
          <el-date-picker v-model="form.ask_endtime" type="date" placeholder="结束时间">
          </el-date-picker>
        </el-form-item>

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button v-if="v1" type="primary" @click="save()">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
  export default {
    created() {
		
		let that = this
		this.$axios({
			method: 'get',
			url: 'http://localhost:8888/staff/findStaffByAccount?account=' + that.getCookie("account")
		}).then(function(response) {
			that.job_num=response.data.job_num
			that.$axios({
			  method: 'get',
			  url: 'http://localhost:8888/personalschedule/showdepartnum?job_num=' + that.job_num
			}).then(function(response) {
			  that.calendar = response.data
			  console.log(that.calendar)
			}) 
				
		})
		
   
     
    },
    data() {
      return {
		job_num:'',
        calendar: [],
        name: [],
        num: [],
        v1: "",
        v2: "",
        v3: "",
        dialogTableVisible: false,
        dialogFormVisible: false,
        dialogFormVisible1: false,
        form: {
          schedule_id: '',
          schedule_name: '',
          schedule_type: '',
          schedule_date: '',
          start_time: '',
          ask_endtime: '',
          fact_endtime: '',
          schedule_content: '',
          concrete_schedulecontent: '',
          delay: '',
          value1: ''
        },
        formLabelWidth: '120px',
      }
    },
    methods: {
			getCookie: function(key) {
				if (document.cookie.length > 0) {
					var start = document.cookie.indexOf(key + '=')
					if (start !== -1) {
						start = start + key.length + 1
						var end = document.cookie.indexOf(';', start)
						if (end === -1) end = document.cookie.length
						return unescape(document.cookie.substring(start, end))
					}
				}
				return ''
			},
      checkNotice(item, dt) {
        let d = new Date(dt)
        let s = new Date(item.businessCalendar.start_time)
        let e = new Date(item.businessCalendar.end_time)
        // alert(item.businessCalendar.start_time)
        // alert(s)
        const oneDay = 24 * 60 * 60 * 1000
        if (d.getTime() >= s.getTime() && d.getTime() <= (e.getTime() + oneDay)) {
          return true
        }
        return false
      },
      fun(el, dt) {
        this.name = []
        let i = 0
        let that = this
        this.$axios({
          method: 'get',
          url: 'http://localhost:8888/personalschedule/showdepartnum?job_num=' + that.job_num
        }).then(function(response) {
          for (let o in response.data) {
            let d = new Date(dt)
            let s = new Date(response.data[o].businessCalendar.start_time)
            let e = new Date(response.data[o].businessCalendar.end_time)
            const oneDay = 24 * 60 * 60 * 1000
            if (d.getTime() >= s.getTime() && d.getTime() <= (e.getTime() + oneDay)) {
              that.name.push(response.data[o])
              console.log(that.name)
            }
          }
        })
        this.dialogFormVisible1 = true
      },
      display(headline) {
        event.stopPropagation();
        let that = this
        this.$axios({
          method: 'get',
          url: 'http://localhost:8888/personalschedule/showdepartnum?job_num=' + that.job_num
        }).then(function(response) {
          for (let o in response.data) {
            if (response.data[o].businessCalendar.headline == headline) {
              that.form.schedule_id = response.data[o].businessCalendar.schedule_num
              that.form.schedule_name = headline
              that.form.schedule_content = response.data[o].businessCalendar.business_describe
              that.form.start_time = response.data[o].businessCalendar.start_time

              that.form.ask_endtime = response.data[o].businessCalendar.end_time
            }
          }
        })
        this.dialogFormVisible = true
        this.v1 = true
      },
      save() {
        this.dialogFormVisible = false;
      },
    },
  }
</script>

<style>
  .is-selected {
    color: #1989FA;
  }

  .el-calendar-table .el-calendar-day {
    height: 75px;

  }

  .el-scrollbar__wrap {
    overflow-x: hidden;
  }
</style>
