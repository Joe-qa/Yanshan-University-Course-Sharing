<template>
	<div>
		<el-container>
			<el-header class="staff" style="background-color: #B3C0D1; color: #333;line-height: 60px">
				<el-form>
					<i style="margin-right: 15px"></i>
					<el-button @click="addJob()">增加</el-button>
					<el-input placeholder="搜索职位名称" prefix-icon="el-icon-search" v-model="post_name"
						style="margin-top:0px;margin-left:800px; width: 210px;">
					</el-input>
					<el-button type="primary" @click="searchJob">搜索</el-button>
				</el-form>
			</el-header>
			<el-main>
				<el-table :data="templist" style="width: 100%">
					<el-table-column type="expand">
						<template slot-scope="props">
							<el-form label-position="left" inline class="demo-table-expand">
								<el-form-item label="职位名称">
									<span>{{ props.row.post_name }}</span>
								</el-form-item>
								<el-form-item label="职位编号">
									<span>{{ props.row.post_num }}</span>
								</el-form-item>
								<el-form-item label="职位类型">
									<span>{{ props.row.post_type }}</span>
								</el-form-item>
								<el-form-item label="职位等级">
									<span>{{ props.row.post_level }}</span>
								</el-form-item>
								<el-form-item label="上级职位">
									<span>{{ props.row.super_post }}</span>
								</el-form-item>
								<el-form-item label="工作职责">
									<span>{{ props.row.responsibilities }}</span>
								</el-form-item>
								<el-form-item label="入职要求">
									<span>{{ props.row.entry_requirement }}</span>
								</el-form-item>
								<el-form-item label="工作概述">
									<span>{{ props.row.post_overview }}</span>
								</el-form-item>
							</el-form>
						</template>
					</el-table-column>

					<el-table-column label="职位编号" prop="post_num" sortable>
					</el-table-column>
					<el-table-column label="职位名称" prop="post_name">
					</el-table-column>
					<el-table-column label="职位等级" prop="post_level" sortable>
					</el-table-column>
					<el-table-column label="编辑">
						<template slot-scope="scope">
							<el-button @click="updateRow(scope.row)" type="primary" plain>修改</el-button>
							<el-button type="primary" @click="deleteRow(scope.$index,templist,scope.row)" plain>删除
							</el-button>
						</template>
					</el-table-column>
				</el-table>
				<!-- 分页控件 -->
				<div class="block" style="justify-content: center; display: flex; margin-top: 10px;">
					<el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
						:current-page="currentPage" :page-sizes="[5, 10, 15]" :page-size="pageSize"
						layout="total, sizes, prev, pager, next, jumper" :total="jobs.length">
					</el-pagination>
				</div>
			</el-main>
			</el-main>
		</el-container>
		<el-dialog :title="title" :visible.sync="dialogFormVisible">
			<el-form :model="job" :rules="rules" ref="job">
				<el-form-item label="职位名称" prop="post_name" :label-width="formLabelWidth">
					<el-input v-model="job.post_name" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="职位级别" prop="post_level" :label-width="formLabelWidth">
					<el-input v-model.number="job.post_level" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="职位编号" prop="post_num" :label-width="formLabelWidth">
					<el-input v-model.number="job.post_num" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="上级职位" prop="super_post" :label-width="formLabelWidth">
					<el-input v-model="job.super_post" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="职能类型" prop="post_type" :label-width="formLabelWidth">
					<el-select v-model="job.post_type" placeholder="请选择职能类型">
						<el-option label="研发" value="研发"></el-option>
						<el-option label="非研发" value="非研发"></el-option>
						<el-option label="运营研发" value="运营研发"></el-option>
						<el-option label="运营非研发" value="运营非研发"></el-option>
						<el-option label="销售" value="销售"></el-option>
					</el-select>
				</el-form-item>
				<el-form-item label="入职要求" prop="entry_requirement" :label-width="formLabelWidth">
					<el-input v-model="job.entry_requirement" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="职责" prop="responsibilities" :label-width="formLabelWidth">
					<el-input v-model="job.responsibilities" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="岗位工作概述" prop="post_overview" :label-width="formLabelWidth">
					<el-input v-model="job.post_overview" autocomplete="off"></el-input>
				</el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click="resetForm('job')">取 消</el-button>
				<el-button type="primary" @click="saveUpdateJob('job')">确 定</el-button>
			</div>
		</el-dialog>
	</div>
</template>
<style>
	.demo-table-expand {
		font-size: 0;
	}

	.demo-table-expand label {
		width: 90px;
		color: #99a9bf;
	}

	.demo-table-expand .el-form-item {
		margin-right: 0;
		margin-bottom: 0;
		width: 50%;
	}
</style>
<script>
	export default {
		data() {
			return {
				value: '',
				post_name: '',
				dialogFormVisible: false,
				title: '',
				templist: [],
				pageSize: 5,
				currentPage: 1,
				jobs: [],
				job: {
					post_num: '',
					post_name: '',
					post_type: '',
					post_level: '',
					super_post: '',
					responsibilities: '',
					entry_requirement: '',
					post_overview: ''
				},
				formLabelWidth: '120px',
				rules: {
					post_name: [{
							required: true,
							message: '请输入职位名称',
							trigger: 'blur'
						},
						{
							min: 3,
							max: 5,
							message: '长度在 2 到 10 个字符',
							trigger: 'blur'
						}
					],
					post_level: [{
							required: true,
							message: '请输入职位等级',
							trigger: 'blur'
						},
						{
							type: 'number',
							message: '职位等级必须为数字值',
							}
						
					],
					post_num: [{
							required: true,
							message: '请输入职位编号',
							trigger: 'blur'
						},
						{
							type: 'number',
							message: '职位编号必须为数字值'
						}
					],
					super_post: [{
							required: true,
							message: '请输入上级职位名称',
							trigger: 'blur'
						}
					],
					post_type: [{
						required: true,
						message: '请选择职能类型',
						trigger: 'blur'
					}]
				}
			}
		},
		methods: {
			resetForm(formName) {
				if (this.title == "增加岗位信息") {
					this.dialogFormVisible = false
				} else if (this.title == "修改岗位信息") {
					this.$refs[formName].resetFields();
					this.dialogFormVisible = false
					this.timer = setTimeout(() => { //设置延迟执行
						this.$router.go(0);
					}, 0.1);
				}
			},
			//每页条数切换
			handleSizeChange(pageSize) {
				this.pageSize = pageSize;
				this.handleCurrentChange(this.currentPage);
			},
			//页码切换
			handleCurrentChange(currentPage) {
				this.currentPage = currentPage;
				this.currentChangePage(this.jobs, currentPage);
			},
			//分页实现
			currentChangePage(list, currentPage) {
				let from = (currentPage - 1) * this.pageSize;
				let to = currentPage * this.pageSize;
				this.templist = this.jobs.slice(from, to);
			},
			searchJob() {
				let that = this
				let post_name = this.post_name
				console.log(post_name)
				if (post_name == "") {
					this.$axios({
						method: 'post',
						url: 'http://localhost:8888/job/showalljob'
					}).then(function(response) {
						that.jobs = response.data
						that.templist = that.jobs.slice(0, that.pageSize)
					})
				} else {
					this.$axios({
						method: 'post',
						url: 'http://localhost:8888/job/showjob?post_name=' + post_name,
					}).then(function(response) {
						console.log(response.data)
						if (response.data == "") {
							that.jobs = response.data
							that.templist = that.jobs.slice(0, that.pageSize)
						} else {
							let job_info = []
							job_info.push(response.data)
							that.jobs = job_info
							that.templist = that.jobs.slice(0, that.pageSize)
						}
					})
				}
			},
			addJob() {
				this.title = '增加岗位信息'
				this.dialogFormVisible = true
				this.job.post_num = ''
				this.job.post_name = ''
				this.job.post_type = ''
				this.job.post_level = ''
				this.job.super_post = ''
				this.job.responsibilities = ''
				this.job.entry_requirement = ''
				this.entry_requirement = ''
				this.job.post_overview = ''
			},
			saveUpdateJob(formName) {
				this.$refs[formName].validate((valid) => {
					if (valid) {
						let that = this
						this.dialogFormVisible = false
						if (this.title == "修改岗位信息") {
							this.$axios({
								method: 'post',
								url: 'http://localhost:8888/job/updatejob',
								data: that.job
							}).then(function() {
								that.$message({
									showClose: true,
									message: '修改成功',
									type: 'success',
									offset: 300
								});
							})

						} else {
							this.$axios({
								method: 'post',
								url: 'http://localhost:8888/job/addjob',
								data: that.job
							}).then(function() {
								that.$message({
									showClose: true,
									message: '创建岗位信息成功',
									type: 'success',
									offset: 300
								});
							})
							this.timer = setTimeout(() => { //设置延迟执行
								this.$router.go(0);
							}, 0.1);
						}
					} else {
						console.log('error submit!!');
						return false;
					}
				});
			},
			updateRow(rows) {
				this.dialogFormVisible = true
				this.title = '修改岗位信息'
				this.job = rows
			},
			deleteRow(index, rows, row) {
				console.log(rows)
				rows.splice(index, 1);
				//传回到后台服务器
				let post_num = row.post_num
				let that = this
				this.$axios({
					method: 'get',
					url: 'http://localhost:8888/job/deljob?post_num=' + post_num
				}).then(function() {
					that.$message({
						showClose: true,
						message: '删除成功',
						type: 'success',
						offset: 300
					});
				})
			}
		},
		created: function() {
			let that = this
			//去后端提数据
			this.$axios({
				method: 'post',
				url: 'http://localhost:8888/job/showalljob'

			}).then(function(response) {
				that.jobs = response.data
				that.templist = that.jobs.slice(0, that.pageSize)
			})
		}
	};
</script>
