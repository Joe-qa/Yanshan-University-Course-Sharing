package com.jz.xdkjoa.mapper.pmanagement;

import com.jz.xdkjoa.pojo.pmanagement.Staff;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface StaffMapper {
    void addStaff(Staff staff);
    List<Staff> showStaffs();
    Staff showStaffById(Integer job_num);
    List<Staff> showStaffByName(String staff_name,Integer depart_num);
    void updateStaff(Staff staff);
    void delStaff(Integer job_num);
    List<Staff> showStaffByDept(String depart_name);
    List<Staff> validateStaff(String account);
    void saveImage(String image,Integer job_num);
    List<Staff> findStaffByDepartment(Integer depart_num);
}
