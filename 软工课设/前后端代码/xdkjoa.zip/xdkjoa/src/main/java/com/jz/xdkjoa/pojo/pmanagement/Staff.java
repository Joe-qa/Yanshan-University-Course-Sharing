package com.jz.xdkjoa.pojo.pmanagement;

import java.util.Date;

public class Staff {
    int job_num;
    int depart_num;
    int post_num;
    String staff_name;
    String account;
    String staff_password;
    String staff_type;
    String gender;
    String nationality;
    String nation;
    String identity_num;
    Date birthday;
    String native_place;
    String politics_statues;
    String email;
    String in_office;
    int service_length;
    String staff_image;
    String staff_tel;

    public String getStaff_image() {
        return staff_image;
    }

    public void setStaff_image(String staff_image) {
        this.staff_image = staff_image;
    }

    private Department department;  //员工所对应的部门实体
    private Job job;

    public Job getJob() {
        return job;
    }

    public void setJob(Job job) {
        this.job = job;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }


    @Override
    public String toString() {
        return "Staff{" +
                "job_num=" + job_num +
                ", depart_num=" + depart_num +
                ", post_num=" + post_num +
                ", staff_name='" + staff_name + '\'' +
                ", account='" + account + '\'' +
                ", staff_password='" + staff_password + '\'' +
                ", staff_type='" + staff_type + '\'' +
                ", gender='" + gender + '\'' +
                ", nationality='" + nationality + '\'' +
                ", nation='" + nation + '\'' +
                ", identity_num='" + identity_num + '\'' +
                ", birthday=" + birthday +
                ", native_place='" + native_place + '\'' +
                ", politics_statues='" + politics_statues + '\'' +
                ", email='" + email + '\'' +
                ", in_office='" + in_office + '\'' +
                ", service_length=" + service_length +
                ", staff_image='" + staff_image + '\'' +
                ", staff_tel='" + staff_tel + '\'' +
                '}';
    }

    public Staff(int job_num, int depart_num, int post_num, String staff_name, String account, String staff_password, String staff_type, String gender, String nationality, String nation, String identity_num, Date birthday, String native_place, String politics_statues, String email, String in_office, int service_length, String staff_image, String staff_tel) {
        this.job_num = job_num;
        this.depart_num = depart_num;
        this.post_num = post_num;
        this.staff_name = staff_name;
        this.account = account;
        this.staff_password = staff_password;
        this.staff_type = staff_type;
        this.gender = gender;
        this.nationality = nationality;
        this.nation = nation;
        this.identity_num = identity_num;
        this.birthday = birthday;
        this.native_place = native_place;
        this.politics_statues = politics_statues;
        this.email = email;
        this.in_office = in_office;
        this.service_length = service_length;
        this.staff_image = staff_image;
        this.staff_tel = staff_tel;
    }

    public Staff() {
    }

    public int getJob_num() {
        return job_num;
    }

    public void setJob_num(int job_num) {
        this.job_num = job_num;
    }

    public int getDepart_num() {
        return depart_num;
    }

    public void setDepart_num(int depart_num) {
        this.depart_num = depart_num;
    }

    public int getPost_num() {
        return post_num;
    }

    public void setPost_num(int post_num) {
        this.post_num = post_num;
    }

    public String getStaff_name() {
        return staff_name;
    }

    public void setStaff_name(String staff_name) {
        this.staff_name = staff_name;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getStaff_password() {
        return staff_password;
    }

    public void setStaff_password(String staff_password) {
        this.staff_password = staff_password;
    }

    public String getStaff_type() {
        return staff_type;
    }

    public void setStaff_type(String staff_type) {
        this.staff_type = staff_type;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getNationality() {
        return nationality;
    }

    public void setNationality(String nationality) {
        this.nationality = nationality;
    }

    public String getNation() {
        return nation;
    }

    public void setNation(String nation) {
        this.nation = nation;
    }

    public String getIdentity_num() {
        return identity_num;
    }

    public void setIdentity_num(String identity_num) {
        this.identity_num = identity_num;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getNative_place() {
        return native_place;
    }

    public void setNative_place(String native_place) {
        this.native_place = native_place;
    }

    public String getPolitics_statues() {
        return politics_statues;
    }

    public void setPolitics_statues(String politics_statues) {
        this.politics_statues = politics_statues;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getIn_office() {
        return in_office;
    }

    public void setIn_office(String in_office) {
        this.in_office = in_office;
    }

    public int getService_length() {
        return service_length;
    }

    public void setService_length(int service_length) {
        this.service_length = service_length;
    }

    public String getStaff_tel() {
        return staff_tel;
    }

    public void setStaff_tel(String staff_tel) {
        this.staff_tel = staff_tel;
    }

}
