package com.jz.xdkjoa.pojo.administration;

import java.util.Date;

public class Vote {
    private  int vote_num;
    private  int job_num;
    private  String vote_headline;
    private String poll;
    private  String highestoptions;
    private Date vote_time;

    public Vote(int vote_num, int job_num, String vote_headline, String poll, String highestoptions, Date vote_time) {
        this.vote_num = vote_num;
        this.job_num = job_num;
        this.vote_headline = vote_headline;
        this.poll = poll;
        this.highestoptions = highestoptions;
        this.vote_time = vote_time;
    }
    public Vote(){}

    public int getVote_num() {
        return vote_num;
    }

    public void setVote_num(int vote_num) {
        this.vote_num = vote_num;
    }

    public int getJob_num() {
        return job_num;
    }

    public void setJob_num(int job_num) {
        this.job_num = job_num;
    }

    public String getVote_headline() {
        return vote_headline;
    }

    public void setVote_headline(String vote_headline) {
        this.vote_headline = vote_headline;
    }

    public String getPoll() {
        return poll;
    }

    public void setPoll(String poll) {
        this.poll = poll;
    }

    public String getHighestoptions() {
        return highestoptions;
    }

    public void setHighestoptions(String highestoptions) {
        this.highestoptions = highestoptions;
    }

    public Date getVote_time() {
        return vote_time;
    }

    public void setVote_time(Date vote_time) {
        this.vote_time = vote_time;
    }

    @Override
    public String toString() {
        return "Vote{" +
                "vote_num=" + vote_num +
                ", job_num=" + job_num +
                ", vote_headline='" + vote_headline + '\'' +
                ", poll='" + poll + '\'' +
                ", highestoptions='" + highestoptions + '\'' +
                ", vote_time=" + vote_time +
                '}';
     }
}
