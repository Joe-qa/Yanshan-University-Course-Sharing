package com.jz.xdkjoa;

import org.mybatis.spring.annotation.MapperScan;
import org.mybatis.spring.annotation.MapperScans;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;

//@MapperScan({"com.jz.xdkjoa.mapper.poffice","com.jz.xdkjoa.mapper.logistics"})
@SpringBootApplication
public class XdkjoaApplication {

    public static void main(String[] args) {
        SpringApplication.run(XdkjoaApplication.class, args);
    }

}
