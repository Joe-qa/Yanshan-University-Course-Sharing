package com.jz.xdkjoa.pojo.administration;

import java.util.Date;

public class MeetingBooking {
    private  int booking_num;
    private  String meetingroom_num;
    private  int job_num;
    private Date begin_time;
    private Date finish_time;
    private String meeting_headline;
    private int participant_num;

    public MeetingBooking(int booking_num, String meetingroom_num, int job_num, Date begin_time, Date finish_time, String meeting_headline, int participant_num) {
        this.booking_num = booking_num;
        this.meetingroom_num = meetingroom_num;
        this.job_num = job_num;
        this.begin_time = begin_time;
        this.finish_time = finish_time;
        this.meeting_headline = meeting_headline;
        this.participant_num = participant_num;

    }
    public MeetingBooking(){}

    public int getBooking_num() {
        return booking_num;
    }

    public void setBooking_num(int booking_num) {
        this.booking_num = booking_num;
    }

    public String getMeetingroom_num() {
        return meetingroom_num;
    }

    public void setMeetingroom_num(String meetingroom_num) {
        this.meetingroom_num = meetingroom_num;
    }

    public int getJob_num() {
        return job_num;
    }

    public void setJob_num(int job_num) {
        this.job_num = job_num;
    }

    public Date getBegin_time() {
        return begin_time;
    }

    public void setBegin_time(Date begin_time) {
        this.begin_time = begin_time;
    }

    public Date getFinish_time() {
        return finish_time;
    }

    public void setFinish_time(Date finish_time) {
        this.finish_time = finish_time;
    }

    public String getMeeting_headline() {
        return meeting_headline;
    }

    public void setMeeting_headline(String meeting_headline) {
        this.meeting_headline = meeting_headline;
    }

    public int getParticipant_num() {
        return participant_num;
    }

    public void setParticipant_num(int participant_num) {
        this.participant_num = participant_num;
    }

    @Override
    public String toString() {
        return "MeetingBooking{" +
                "booking_num=" + booking_num +
                ", meetingroom_num='" + meetingroom_num + '\'' +
                ", job_num=" + job_num +
                ", begin_time=" + begin_time +
                ", finish_time=" + finish_time +
                ", meeting_headline='" + meeting_headline + '\'' +
                ", participant_num=" + participant_num +
                '}';
    }
}
