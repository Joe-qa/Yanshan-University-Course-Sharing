package com.jz.xdkjoa.service.poffice;

import com.jz.xdkjoa.pojo.administration.BusinessCalendar;
import com.jz.xdkjoa.pojo.poffice.PersonalSchedule;

import java.util.List;

public interface PersonalScheduleService {
    List<PersonalSchedule> showPersonalScheduleBiz(Integer job_num, String schedule_type);
    void addPersonalScheduleBiz(PersonalSchedule personalSchedule);
    void updatePersonalScheduleBiz(PersonalSchedule personalSchedule);
    void delPersonalScheduleBiz(Integer schedule_id);
    List<PersonalSchedule> showBusinessScheduleBiz(Integer job_num);
    List <Integer> showDepartNumBiz(Integer job_num);
    List<BusinessCalendar> showBusinessCalendarBiz(Integer depart_num);
}
