﻿using Microsoft.Win32;
using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Text;
using System.Drawing;

namespace U_disk_Mange
{
    public partial class Form1 : Form
    {
        public const int WM_DEVICECHANGE = 0x219;//U盘插入后，OS的底层会自动检测到，然后向应用程序发送“硬件设备状态改变“的消息
        public const int DBT_DEVICEARRIVAL = 0x8000;  //就是用来表示U盘可用的。一个设备或媒体已被插入一块，现在可用。
        public const int DBT_CONFIGCHANGECANCELED = 0x0019;  //要求更改当前的配置（或取消停靠码头）已被取消。
        public const int DBT_CONFIGCHANGED = 0x0018;  //当前的配置发生了变化，由于码头或取消固定。
        public const int DBT_CUSTOMEVENT = 0x8006; //自定义的事件发生。 的Windows NT 4.0和Windows 95：此值不支持。
        public const int DBT_DEVICEQUERYREMOVE = 0x8001;  //审批要求删除一个设备或媒体作品。任何应用程序也不能否认这一要求，并取消删除。
        public const int DBT_DEVICEQUERYREMOVEFAILED = 0x8002;  //请求删除一个设备或媒体片已被取消。
        public const int DBT_DEVICEREMOVECOMPLETE = 0x8004;  //一个设备或媒体片已被删除。
        public const int DBT_DEVICEREMOVEPENDING = 0x8003;  //一个设备或媒体一块即将被删除。不能否认的。
        public const int DBT_DEVICETYPESPECIFIC = 0x8005;  //一个设备特定事件发生。
        public const int DBT_DEVNODES_CHANGED = 0x0007;  //一种设备已被添加到或从系统中删除。
        public const int DBT_QUERYCHANGECONFIG = 0x0017;  //许可是要求改变目前的配置（码头或取消固定）。
        public const int DBT_USERDEFINED = 0xFFFF;  //此消息的含义是用户定义的
        public const int WM_SYSCOMMAND = 0x0112;
        public const int SC_CLOSE = 0xF060;
        [DllImport("Kernel32.dll")]
        public static extern int GetLogicalDrives();//二进制数，1表示存在该盘符存在,0表示该盘符不存在

        [DllImport("Kernel32.dll")]
        public static extern int GetDriveType(string ns);
        //0 "DRIVE_UNKNOWN"       无法识别的设备
        //1 "DRIVE_NO_ROOT_DIR"   给出的名字不存在
        //2 "DRIVE_REMOVABLE"     可移动设备
        //3 "DRIVE_FIXED"         不可移动的磁盘
        //4 "DRIVE_REMOTE"        网络硬盘  
        //5 "DRIVE_CDROM"         CD光驱
        //6 "DRIVE_RAMDISK"       内存虚拟盘

        [DllImport("Kernel32.dll")]
        public static extern bool GetDiskFreeSpaceEx(
     string lpDirectoryName,
     out UInt64 lpFreeBytesAvailable,
     out UInt64 lpTotalNumberOfBytes,
     out UInt64 lpTotalNumberOfFreeBytess);//得到盘符的容量以及剩余容量

        [DllImport("Kernel32.dll")]
        public static extern bool CopyFile(
          string lpExistingFileName,
          string lpNewFileName,
          bool bFailIfExists = false);//复制文件

        [DllImport("Kernel32.dll")]
        public static extern bool DeleteFile(string lpFileName);//删除文件

        //更改注册表
        [DllImport("advapi32.dll", SetLastError = true)]
        static extern uint RegSetValueEx(
        UIntPtr hKey,
        [MarshalAs(UnmanagedType.LPStr)]
         string lpValueName,
        int Reserved,
        RegistryValueKind dwType,
        IntPtr lpData,
        int cbData);

        [DllImport("advapi32.dll", CharSet = CharSet.Auto)]
        public static extern int RegOpenKeyEx(
        UIntPtr hKey,
        string subKey,
        int ulOptions,
        int samDesired,
        out UIntPtr hkResult);
        [DllImport("advapi32.dll", SetLastError = true)]
        public static extern int RegCloseKey(UIntPtr hKey);

        /* Retrieves the type and data for the specified registry value. - Original documented types */
        [DllImport("advapi32.dll", SetLastError = true)]
        static extern uint RegQueryValueEx(
         UIntPtr hKey,
        string lpValueName,
        int lpReserved,
        out uint lpType,
        StringBuilder lpData,
        ref uint lpcbData);

        static readonly IntPtr HKEY_CLASSES_ROOT = new IntPtr(unchecked((int)0x80000000));
        static readonly IntPtr HKEY_CURRENT_USER = new IntPtr(unchecked((int)0x80000001));
        static readonly UIntPtr HKEY_LOCAL_MACHINE = new UIntPtr(unchecked((uint)0x80000002));
        static readonly IntPtr HKEY_USERS = new IntPtr(unchecked((int)0x80000003));
        static readonly IntPtr HKEY_PERFORMANCE_DATA = new IntPtr(unchecked((int)0x80000004));
        static readonly IntPtr HKEY_CURRENT_CONFIG = new IntPtr(unchecked((int)0x80000005));
        static readonly IntPtr HKEY_DYN_DATA = new IntPtr(unchecked((int)0x80000006));
        int STANDARD_RIGHTS_ALL = (0x001F0000);
        int KEY_QUERY_VALUE = (0x0001);
        int KEY_SET_VALUE = (0x0002);
        int KEY_CREATE_SUB_KEY = (0x0004);
        int KEY_ENUMERATE_SUB_KEYS = (0x0008);
        int KEY_NOTIFY = (0x0010);
        int KEY_CREATE_LINK = (0x0020);
        int SYNCHRONIZE = (0x00100000);


        public class InteropSHFileOperation
        {
            public enum FO_Func : uint
            {
                FO_MOVE = 0x0001,
                FO_COPY = 0x0002,
                FO_DELETE = 0x0003,
                FO_RENAME = 0x0004,
            }

            [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode, Pack = 2)]
            struct SHFILEOPSTRUCT
            {
                public IntPtr hwnd;
                public FO_Func wFunc;
                [MarshalAs(UnmanagedType.LPWStr)]
                public string pFrom;
                [MarshalAs(UnmanagedType.LPWStr)]
                public string pTo;
                public ushort fFlags;
                [MarshalAs(UnmanagedType.Bool)]
                public bool fAnyOperationsAborted;
                public IntPtr hNameMappings;
                [MarshalAs(UnmanagedType.LPWStr)]
                public string lpszProgressTitle;

            }

            [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
            static extern int SHFileOperation([In, Out] ref SHFILEOPSTRUCT lpFileOp);

            private SHFILEOPSTRUCT _ShFile;
            public FILEOP_FLAGS fFlags;

            public IntPtr hwnd
            {
                set
                {
                    this._ShFile.hwnd = value;
                }
            }
            public FO_Func wFunc
            {
                set
                {
                    this._ShFile.wFunc = value;
                }
            }

            public string pFrom
            {
                set
                {
                    this._ShFile.pFrom = value + '\0' + '\0';
                }
            }
            public string pTo
            {
                set
                {
                    this._ShFile.pTo = value + '\0' + '\0';
                }
            }

            public bool fAnyOperationsAborted
            {
                set
                {
                    this._ShFile.fAnyOperationsAborted = value;
                }
            }
            public IntPtr hNameMappings
            {
                set
                {
                    this._ShFile.hNameMappings = value;
                }
            }
            public string lpszProgressTitle
            {
                set
                {
                    this._ShFile.lpszProgressTitle = value + '\0';
                }
            }

            public InteropSHFileOperation(string pFrom, string pTo)
            {

                this.fFlags = new FILEOP_FLAGS();
                this._ShFile = new SHFILEOPSTRUCT();
                this._ShFile.hwnd = IntPtr.Zero;
                this._ShFile.wFunc = FO_Func.FO_COPY;
                this._ShFile.pFrom = pFrom;
                this._ShFile.pTo = pTo;
                this._ShFile.fAnyOperationsAborted = false;
                this._ShFile.hNameMappings = IntPtr.Zero;
                this._ShFile.lpszProgressTitle = "";

            }

            public bool Execute()
            {
                this._ShFile.fFlags = this.fFlags.Flag;
                return SHFileOperation(ref this._ShFile) == 0;//true if no errors
            }

            public class FILEOP_FLAGS
            {
                [Flags]
                private enum FILEOP_FLAGS_ENUM : ushort
                {
                    FOF_MULTIDESTFILES = 0x0001,
                    FOF_CONFIRMMOUSE = 0x0002,
                    FOF_SILENT = 0x0004,  // don't create progress/report
                    FOF_RENAMEONCOLLISION = 0x0008,
                    FOF_NOCONFIRMATION = 0x0010,  // Don't prompt the user.
                    FOF_WANTMAPPINGHANDLE = 0x0020,  // Fill in SHFILEOPSTRUCT.hNameMappings
                                                     // Must be freed using SHFreeNameMappings
                    FOF_ALLOWUNDO = 0x0040,
                    FOF_FILESONLY = 0x0080,  // on *.*, do only files
                    FOF_SIMPLEPROGRESS = 0x0100,  // means don't show names of files
                    FOF_NOCONFIRMMKDIR = 0x0200,  // don't confirm making any needed dirs
                    FOF_NOERRORUI = 0x0400,  // don't put up error UI
                    FOF_NOCOPYSECURITYATTRIBS = 0x0800,  // dont copy NT file Security Attributes
                    FOF_NORECURSION = 0x1000,  // don't recurse into directories.
                    FOF_NO_CONNECTED_ELEMENTS = 0x2000,  // don't operate on connected elements.
                    FOF_WANTNUKEWARNING = 0x4000,  // during delete operation, warn if nuking instead of recycling (partially overrides FOF_NOCONFIRMATION)
                    FOF_NORECURSEREPARSE = 0x8000,  // treat reparse points as objects, not containers
                }

                public bool FOF_MULTIDESTFILES = false;
                public bool FOF_CONFIRMMOUSE = false;
                public bool FOF_SILENT = false;
                public bool FOF_RENAMEONCOLLISION = false;
                public bool FOF_NOCONFIRMATION = false;
                public bool FOF_WANTMAPPINGHANDLE = false;
                public bool FOF_ALLOWUNDO = false;
                public bool FOF_FILESONLY = false;
                public bool FOF_SIMPLEPROGRESS = false;
                public bool FOF_NOCONFIRMMKDIR = false;
                public bool FOF_NOERRORUI = false;
                public bool FOF_NOCOPYSECURITYATTRIBS = false;
                public bool FOF_NORECURSION = false;
                public bool FOF_NO_CONNECTED_ELEMENTS = false;
                public bool FOF_WANTNUKEWARNING = false;
                public bool FOF_NORECURSEREPARSE = false;

                public ushort Flag
                {
                    get
                    {
                        ushort ReturnValue = 0;

                        if (this.FOF_MULTIDESTFILES)
                            ReturnValue |= (ushort)FILEOP_FLAGS_ENUM.FOF_MULTIDESTFILES;
                        if (this.FOF_CONFIRMMOUSE)
                            ReturnValue |= (ushort)FILEOP_FLAGS_ENUM.FOF_CONFIRMMOUSE;
                        if (this.FOF_SILENT)
                            ReturnValue |= (ushort)FILEOP_FLAGS_ENUM.FOF_SILENT;
                        if (this.FOF_RENAMEONCOLLISION)
                            ReturnValue |= (ushort)FILEOP_FLAGS_ENUM.FOF_RENAMEONCOLLISION;
                        if (this.FOF_NOCONFIRMATION)
                            ReturnValue |= (ushort)FILEOP_FLAGS_ENUM.FOF_NOCONFIRMATION;
                        if (this.FOF_WANTMAPPINGHANDLE)
                            ReturnValue |= (ushort)FILEOP_FLAGS_ENUM.FOF_WANTMAPPINGHANDLE;
                        if (this.FOF_ALLOWUNDO)
                            ReturnValue |= (ushort)FILEOP_FLAGS_ENUM.FOF_ALLOWUNDO;
                        if (this.FOF_FILESONLY)
                            ReturnValue |= (ushort)FILEOP_FLAGS_ENUM.FOF_FILESONLY;
                        if (this.FOF_SIMPLEPROGRESS)
                            ReturnValue |= (ushort)FILEOP_FLAGS_ENUM.FOF_SIMPLEPROGRESS;
                        if (this.FOF_NOCONFIRMMKDIR)
                            ReturnValue |= (ushort)FILEOP_FLAGS_ENUM.FOF_NOCONFIRMMKDIR;
                        if (this.FOF_NOERRORUI)
                            ReturnValue |= (ushort)FILEOP_FLAGS_ENUM.FOF_NOERRORUI;
                        if (this.FOF_NOCOPYSECURITYATTRIBS)
                            ReturnValue |= (ushort)FILEOP_FLAGS_ENUM.FOF_NOCOPYSECURITYATTRIBS;
                        if (this.FOF_NORECURSION)
                            ReturnValue |= (ushort)FILEOP_FLAGS_ENUM.FOF_NORECURSION;
                        if (this.FOF_NO_CONNECTED_ELEMENTS)
                            ReturnValue |= (ushort)FILEOP_FLAGS_ENUM.FOF_NO_CONNECTED_ELEMENTS;
                        if (this.FOF_WANTNUKEWARNING)
                            ReturnValue |= (ushort)FILEOP_FLAGS_ENUM.FOF_WANTNUKEWARNING;
                        if (this.FOF_NORECURSEREPARSE)
                            ReturnValue |= (ushort)FILEOP_FLAGS_ENUM.FOF_NORECURSEREPARSE;

                        return ReturnValue;
                    }
                }
            }

        }

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern int GetCurrentProcessId();
       
        //检验盘符，检验当前pc中存在的盘符，以字符串形式返回
        public String checkDisk()
        {
            string diskinfo = "";
            string disk = Convert.ToString(GetLogicalDrives(), 2);
            string reverseDisk = "";
            for (int i = disk.Length - 1; i >= 0; i--)
            {
                reverseDisk += disk[i];
            }
            char diskNumber = 'A';
            string tem;
            for (int i = 0; i < reverseDisk.Length; i++)
            {
                tem = diskNumber + ":\\";
                if (reverseDisk[i] == '1' && GetDriveType(tem) == 2)
                    diskinfo += diskNumber;
                diskNumber++;
            }
            if (diskinfo == "")
                return "empty";
            return diskinfo;
        }
        bool[] diskflag = new bool[26];
        public Form1()
        {
            InitializeComponent();
            this.BackgroundImage = Image.FromFile("background.jpg");

            this.BackgroundImageLayout = ImageLayout.Stretch;//设置背景图片自动适应
            select.Items.Clear();

            select.Items.Add("复制整个目录中的文件");
            select.Items.Add("复制某个文件");
            string diskInfo = checkDisk();
            if (!diskInfo.Equals("empty"))
            {
                if (diskInfo.Length > 0)
                    U_diskinfo.Text = "有U盘插入";

                DISKcombox.Items.Clear();
                for (int i = 0; i < diskInfo.Length; i++)
                    DISKcombox.Items.Add(diskInfo[i] + ":\\");
            }
            else
                U_diskinfo.Text = "无U盘插入";
            for (int i = 0; i < 26; i++)
                diskflag[i] = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }


        protected override void WndProc(ref Message m)
        {
            string disk = checkDisk();
            if (!disk.Equals("empty")) { 
           
                U_diskinfo.Text = "有U盘插入！";
            }
            else
                U_diskinfo.Text = "无U盘插入!";
            
           if (m.Msg == WM_SYSCOMMAND && (int)m.WParam == SC_CLOSE)
            {
                UIntPtr hKey = UIntPtr.Zero;

                int KEY_ALL_ACCESS = (STANDARD_RIGHTS_ALL | KEY_QUERY_VALUE | KEY_SET_VALUE | KEY_CREATE_SUB_KEY | KEY_ENUMERATE_SUB_KEYS
                                | KEY_NOTIFY | KEY_CREATE_LINK) & (~SYNCHRONIZE);
                int retVal = RegOpenKeyEx(HKEY_LOCAL_MACHINE, @"SYSTEM\CurrentControlSet\Services\USBSTOR", 0, KEY_ALL_ACCESS, out hKey);
                if (retVal == 0)
                {
                    int size = 0;
                    IntPtr pData = IntPtr.Zero;
                    size = Marshal.SizeOf(typeof(Int32));
                    pData = Marshal.AllocHGlobal(size);
                    Marshal.WriteInt32(pData, 2);
                    StringBuilder sb = new StringBuilder();
                    retVal = (int)RegSetValueEx(hKey, "Start", 0, RegistryValueKind.DWord, pData, 4);
                    RegCloseKey(hKey);
                                    }
            }
            try
            {
                if (m.Msg == WM_DEVICECHANGE)
                {
                    switch (m.WParam.ToInt32())
                    {
                        case WM_DEVICECHANGE:
                            break;
                        case DBT_DEVICEARRIVAL://U盘插入
                            MessageBox.Show("检测到U盘插入！");
                            DISKcombox.Items.Clear();
                            for (int i = 0; i < disk.Length; i++)
                            {
                               
                                DISKcombox.Items.Add(disk[i] + ":\\");
                            }
                            updateSpace();
                            break;
                        case DBT_CONFIGCHANGECANCELED:
                            break;
                        case DBT_CONFIGCHANGED:
                            break;
                        case DBT_CUSTOMEVENT:
                            break;
                        case DBT_DEVICEQUERYREMOVE:
                            break;
                        case DBT_DEVICEQUERYREMOVEFAILED:
                            break;
                        case DBT_DEVICEREMOVECOMPLETE: //U盘卸载
                            MessageBox.Show("检测到U盘拔出！");
                            DISKcombox.Items.Clear();
                            if(!disk.Equals("empty"))
                             for (int i = 0; i < disk.Length; i++)
                                DISKcombox.Items.Add(disk[i] + ":\\");
                            updateSpace();
                            break;
                        case DBT_DEVICEREMOVEPENDING:
                            break;
                        case DBT_DEVICETYPESPECIFIC:
                            break;
                        case DBT_DEVNODES_CHANGED:
                            break;
                        case DBT_QUERYCHANGECONFIG:
                            break;
                        case DBT_USERDEFINED:
                            break;
                        default:
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            base.WndProc(ref m);
        }

        //获得U盘总共空间
        public double getTotalDiskSpace(string lpRootPathName)
        {
            ulong freeBytesAvailable = 0;
            ulong totalNumberOfBytes = 0;
            ulong totalNumberOfFreeBytes = 0;
            bool flag = GetDiskFreeSpaceEx(lpRootPathName, out freeBytesAvailable, out totalNumberOfBytes, out totalNumberOfFreeBytes);
            double space;
            if (flag)
            {
                space = (double)totalNumberOfBytes / 1024 / 1024 / 1024;
            }
            else
                space = 0;
            return space;
        }

        //获得U盘剩余空间
        public double getFreeDiskSpace(string lpRootPathName)
        {
            ulong freeBytesAvailable = 0;
            ulong totalNumberOfBytes = 0;
            ulong totalNumberOfFreeBytes = 0;
            bool flag = GetDiskFreeSpaceEx(lpRootPathName, out freeBytesAvailable, out totalNumberOfBytes, out totalNumberOfFreeBytes);
            double space;
            if (flag)
            {
                space = (double)totalNumberOfFreeBytes / 1024 / 1024 / 1024;
            }
            else
                space = 0;
            return space;
        }

        public void updateSpace()
        {
            DISKcombox.Text = "";
            string disk;
            if (DISKcombox.SelectedItem == null)
                disk = "";
            else
             disk = DISKcombox.SelectedItem.ToString();

            double totalspace = getTotalDiskSpace(disk);
            double freespace = getFreeDiskSpace(disk);
            double usedspace = totalspace - freespace;
            totalSpace.Text = totalspace.ToString("f2") + " GB";
            usedSpace.Text = usedspace.ToString("f2") + " GB";
            freeSpace.Text = freespace.ToString("f2") + " GB";
        }
        private void DISKcombox_SelectedIndexChanged(object sender, EventArgs e)
        {
            updateSpace();
        }

        private void dirBtn_Click(object sender, EventArgs e)
        {
            string info;
            if (select.SelectedItem == null)
                info = "复制整个目录中的文件";
            else
                 info= select.SelectedItem.ToString();
           if (info.Equals("复制整个目录中的文件"))
            {
                FolderBrowserDialog dilog = new FolderBrowserDialog();
                dilog.Description = "请选择文件夹";
                if (dilog.ShowDialog() == DialogResult.OK || dilog.ShowDialog() == DialogResult.Yes)
                {
                    fromtextBox.Text = dilog.SelectedPath;
                }

            }
            else
            {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Multiselect = true;//该值确定是否可以选择多个文件
                dialog.Title = "请选择文件";
                dialog.Filter = "所有文件(*.*)|*.*";
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    string file = dialog.FileName;
                    fromtextBox.Text = file;
                }
            }
           
        }

        private void fileBtn_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dilog = new FolderBrowserDialog();
            dilog.Description = "请选择文件夹";
            if (dilog.ShowDialog() == DialogResult.OK || dilog.ShowDialog() == DialogResult.Yes)
            {
                totextBox.Text = dilog.SelectedPath;
            }
        
        }

        private void copyBtn_Click(object sender, EventArgs e)
        {
            if(fromtextBox.Text=="")
            {
                MessageBox.Show("请选择要复制的文件");
                return;
            }
            if (totextBox.Text == "")
            {
                MessageBox.Show("请选择复制到的位置");
                return;
            }
            string from = fromtextBox.Text + '\0';
            string to = totextBox.Text + '\0';
           InteropSHFileOperation interopSHFileOperation = new InteropSHFileOperation(from, to);
            bool flag = interopSHFileOperation.Execute();
            if (flag)
                MessageBox.Show("复制成功");
            else
                MessageBox.Show("复制失败");
            updateSpace();
        }

        private void delBtn_Click(object sender, EventArgs e)
        {
            if (deltextBox.Text == "")
            {
                MessageBox.Show("请选择要删除的文件");
                return;
            }
            string file = deltextBox.Text;
            DialogResult result = MessageBox.Show("是否确定删除文件", "删除文件", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (result == DialogResult.OK)
            {
                bool flag = DeleteFile(file);
                if (flag)
                    MessageBox.Show("删除成功");
                else
                    MessageBox.Show("删除失败");
            }
            else
            {
                MessageBox.Show("取消删除文件");
            }
            updateSpace();
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            UIntPtr hKey = UIntPtr.Zero;

            int KEY_ALL_ACCESS = (STANDARD_RIGHTS_ALL | KEY_QUERY_VALUE | KEY_SET_VALUE | KEY_CREATE_SUB_KEY | KEY_ENUMERATE_SUB_KEYS
                            | KEY_NOTIFY | KEY_CREATE_LINK) & (~SYNCHRONIZE);
            int retVal = RegOpenKeyEx(HKEY_LOCAL_MACHINE, @"SYSTEM\CurrentControlSet\Services\USBSTOR", 0, KEY_ALL_ACCESS, out hKey);
            if (retVal == 0)
            {
                int size = 0;
                IntPtr pData = IntPtr.Zero;
                size = Marshal.SizeOf(typeof(Int32));
                pData = Marshal.AllocHGlobal(size);
                Marshal.WriteInt32(pData, 4);
                StringBuilder sb = new StringBuilder();
                retVal = (int)RegSetValueEx(hKey, "Start", 0, RegistryValueKind.DWord, pData, 4);
                RegCloseKey(hKey);

            }
            MessageBox.Show("禁用U盘成功");
         
        }

        private void openDisk_Click(object sender, EventArgs e)
        {
            UIntPtr hKey = UIntPtr.Zero;

            int KEY_ALL_ACCESS = (STANDARD_RIGHTS_ALL | KEY_QUERY_VALUE | KEY_SET_VALUE | KEY_CREATE_SUB_KEY | KEY_ENUMERATE_SUB_KEYS
                            | KEY_NOTIFY | KEY_CREATE_LINK) & (~SYNCHRONIZE);
            int retVal = RegOpenKeyEx(HKEY_LOCAL_MACHINE, @"SYSTEM\CurrentControlSet\Services\USBSTOR", 0, KEY_ALL_ACCESS, out hKey);
            if (retVal == 0)
            {
                int size = 0;
                IntPtr pData = IntPtr.Zero;
                size = Marshal.SizeOf(typeof(Int32));
                pData = Marshal.AllocHGlobal(size);
                Marshal.WriteInt32(pData, 2);
                StringBuilder sb = new StringBuilder();
                retVal = (int)RegSetValueEx(hKey, "Start", 0, RegistryValueKind.DWord, pData, 4);
                RegCloseKey(hKey);

            }
            MessageBox.Show("开启U盘");
        }

        private void button3_Click(object sender, EventArgs e)
        {
           MessageBox.Show("进程名：U_disk_Mange " + "\n"+"进程ID为："+ GetCurrentProcessId().ToString());
        }
      
        private void delfileBtn_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Multiselect = true;//该值确定是否可以选择多个文件
            dialog.Title = "请选择文件";
            dialog.Filter = "所有文件(*.*)|*.*";
            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                string file = dialog.FileName;
                deltextBox.Text = file;
            }
        }

        private void select_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
