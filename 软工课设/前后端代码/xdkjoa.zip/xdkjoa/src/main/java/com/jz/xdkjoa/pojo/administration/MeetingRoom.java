package com.jz.xdkjoa.pojo.administration;

public class MeetingRoom {
    private  String meetingroom_num;
    private int people_num;
    private String place;

    public MeetingRoom(String meetingroom_num, int people_num, String place) {
        this.meetingroom_num = meetingroom_num;
        this.people_num = people_num;
        this.place = place;
    }
    public MeetingRoom(){}

    public String getMeetingroom_num() {
        return meetingroom_num;
    }

    public void setMeetingroom_num(String meetingroom_num) {
        this.meetingroom_num = meetingroom_num;
    }

    public int getPeople_num() {
        return people_num;
    }

    public void setPeople_num(int people_num) {
        this.people_num = people_num;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    @Override
    public String toString() {
        return "MeetingRoom{" +
                "meetingroom_num='" + meetingroom_num + '\'' +
                ", people_num=" + people_num +
                ", place='" + place + '\'' +
                '}';
    }
}
