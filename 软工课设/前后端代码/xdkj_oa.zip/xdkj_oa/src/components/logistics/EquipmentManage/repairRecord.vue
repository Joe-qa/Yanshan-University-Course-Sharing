<template>
	<div style="display: flex;flex-direction: column;justify-content: center;">
		<div style="margin-right: auto;">
		<el-button @click="dialogFormVisible = true" type="primary" icon="el-icon-circle-plus-outline">添加</el-button>
		<el-button type="primary" icon="el-icon-upload" @click="exportExcel()">
			导出</el-button>
		</div>
		<div>
		<el-table ref="multipleTable" :data="repairMsgList" tooltip-effect="dark" 
			@selection-change="handleSelectionChange" id="outExcel">
			<el-table-column prop="repair_num" label="编号" width="120">
			</el-table-column>
			<el-table-column prop="repair_type" label="类型" width="120">
			</el-table-column>
			<el-table-column prop="equipment_num" label="物品编号" width="150">
			</el-table-column>
			<el-table-column prop="repair_money" label="维修金额" width="150">
			</el-table-column>
			<el-table-column prop="repair_description" label="损害说明" width="150">
			</el-table-column>
			<el-table-column prop="job_num" label="员工工号" width="120">
			</el-table-column>
			<!-- <el-table-column prop="jobName" label="报修人" width="120">
			</el-table-column> -->
			<el-table-column prop="repair_date" :formatter="dateFormatter" label="报修日期" width="120">
			</el-table-column>
			<el-table-column prop="take_date" :formatter="dateFormatter" label="取回日期" width="120">
			</el-table-column>
		</el-table>
		</div>
		<!--分页控件 -->
				<div class="block" style="justify-content: center; display: flex;  " >
					<el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
						:current-page="currentPage" :page-sizes="[5, 10]" :page-size="pageSize"
						layout="total, sizes, prev, pager, next, jumper" :total="repairMsg.length">
					</el-pagination>
				</div>
		<el-dialog title="维修信息" :visible.sync="dialogFormVisible">
			<el-form :model="repair" :rules="rules" ref="repair" label-width="80px" class="demo-ruleForm">
				<el-form-item label="物品编号" prop="equipment_num">
					<el-input v-model="repair.equipment_num"></el-input>
				</el-form-item>
				<el-form-item label="物品名" prop="repair_type">
					<el-input v-model="repair.repair_type"></el-input>
				</el-form-item>
				<el-form-item label="维修金额" prop="repair_money">
					<el-input v-model="repair.repair_money"></el-input>
				</el-form-item>
				<el-form-item label="员工工号" prop="job_num">
					<el-input v-model="repair.job_num"></el-input>
				</el-form-item>
				<!-- <el-form-item label="报修人" prop="staffname">
					<el-input v-model="repair.staffname"></el-input>
				</el-form-item> -->

				<el-form-item label="报修时间" required>
					<el-col :span="11">
						<el-form-item prop="repair_date">
							<el-date-picker v-model="repair.repair_date" type="date" placeholder="选择报修日期">
							</el-date-picker>
						</el-form-item>
					</el-col>
				</el-form-item>
				<el-form-item label="取回时间" required>
					<el-col :span="11">
						<el-form-item prop="take_date">
							<el-date-picker v-model="repair.take_date" type="date" placeholder="选择取回日期">
							</el-date-picker>
						</el-form-item>
					</el-col>
				</el-form-item>

				<el-form-item label="损害说明" prop="repair_description">
					<el-input type="textarea" v-model="repair.repair_description"></el-input>
				</el-form-item>
				<!-- <el-form-item>
					<el-button type="primary" @click="submitForm()">报修</el-button>
					<el-button @click="resetForm()">重置</el-button>
				</el-form-item> -->
			</el-form>

			<div slot="footer" class="dialog-footer">
				<el-button @click="reset">取消报修</el-button>
				<el-button :plain="true" type="primary" @click="addRepairRecord('repair')">确定报修</el-button>
			</div>
		</el-dialog>

	</div>
</template>
<script>
	export default {
		inject:['reload'],//页面刷新
		created() {
			let that = this
			this.$axios({
				method: 'post',
				url: 'http://localhost:8888/RepairMsg/showRepairRecord'
			}).then(function(response) {
				that.repairMsg = response.data
				that.repairMsgList=that.repairMsg.slice(0,that.pageSize);
			})

		},
		
		data() {
			return {
				repairMsgList:[],
				currentPage:1,
				pageSize:5,
				repairMsg: [],
				multipleSelection: [],
				dialogFormVisible: false,
				repair: {
					equipment_num: '',
					job_num: '',
					repair_type: '',
					repair_money: '',
					repair_description: '',
					take_date: '',
					repair_date: '',
					// staffname: ''
				},
				rules: {
					equipment_num: [{
							required: true,
							message: '请输入物品编号',
							trigger: 'blur'
						},
						//{ min: 3, max: 5, message: '长度在 3 到 5 个字符', trigger: 'blur' }
					],
					repair_type: [{
						required: true,
						message: '请输入物品名',
						trigger: 'blur'
					}, ],
					job_num: [{
						required: true,
						message: '请输入员工工号',
						trigger: 'blur'
					}, ],
					repair_money: [{
						required: true,
						message: '请输入维修金额',
						trigger: 'blur'
					}, ],
					repair_description: [{
						required: true,
						message: '请填写维修原因',
						trigger: 'blur'
					}],
					take_date:[{
						required: true,
						message: '请填写取回日期',
						trigger: 'blur'
					}],
					repair_date:[{
						required: true,
						message: '请填写报修日期',
						trigger: 'blur'
					}]
				}
			}
		},

		methods: {
			exportExcel: function() {
				let tables = document.querySelector("#outExcel") //根据id选取到要导出的表格
				let table_book = this.$XLSX.utils.table_to_book(tables)
				let table_write = this.$XLSX.write(table_book, {
					bookType: "xlsx",
					bookSST: true,
					type: "array"
				})
				try {
					this.$FileSaver.saveAs(new Blob([table_write], {
						type: "application/octet-stream"
					}), "emps.xlsx")
				} catch (e) {
					console.log(e, table_write)
				}
				return table_write
			},
			addRepairRecord(formName) {
				this.$refs[formName].validate((valid) => {
				          if (valid) {
				            alert('submit!');
							let that = this
							console.log(that.repair)
							this.$axios({
								method: 'post',
								url: 'http://localhost:8888/RepairMsg/addRepairRecord',
								data: that.repair
							}).then(function(res) {
								console.log(res)
								that.dialogFormVisible = false
								that.$message({
									showClose: true,
									message: '添加成功',
									type: 'success'
								})
								that.reload()
							})
				          } else {
				            console.log('error submit!!');
				            return false;
				          }
				        });
				
			},
			//取消借车
			reset() {
				let that = this
				that.dialogFormVisible = false
			},
			//date日期转换
			dateFormatter(row) {
				let datetime = row.repair_date;
				if (datetime) {
					datetime = new Date(datetime);
					let y = datetime.getFullYear() + '-';
					let mon = datetime.getMonth() + 1 + '-';
					let d = datetime.getDate();
					return y + mon + d;
				}
				return ''
			},
			handleSelectionChange(val) {
				this.multipleSelection = val;
			},
			//每页条数切换
			handleSizeChange(pageSize) {
				this.pageSize = pageSize;
				this.handleCurrentChange(this.currentPage);
			},
			//页码切换
			handleCurrentChange(currentPage) {
				this.currentPage = currentPage;
				this.currentChangePage(this.repairMsg, currentPage);
			},
			//分页实现
			currentChangePage(list, currentPage) {
				let from = (currentPage - 1) * this.pageSize;
				let to = currentPage * this.pageSize;
				this.repairMsgList = this.repairMsg.slice(from, to);
			},
			
		}
	}
</script>
