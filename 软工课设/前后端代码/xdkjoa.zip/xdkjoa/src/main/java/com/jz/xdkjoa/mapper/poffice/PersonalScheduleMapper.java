package com.jz.xdkjoa.mapper.poffice;

import com.jz.xdkjoa.pojo.administration.BusinessCalendar;
import com.jz.xdkjoa.pojo.poffice.PersonalSchedule;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface PersonalScheduleMapper {
    List<PersonalSchedule> showPersonalSchedule(Integer job_num, String schedule_type);
    void addPersonalSchedule(PersonalSchedule personalSchedule);
    void updatePersonalSchedule(PersonalSchedule personalSchedule);
    void delPersonalSchedule(int schedule_id);
    List<PersonalSchedule> showBusinessSchedule(Integer job_num);
    List<Integer> showDepartNum(Integer job_num);
    List<BusinessCalendar> showBusinessCalendar(Integer depart_num);
}
