package com.jz.xdkjoa.controllers.logistics;

import com.jz.xdkjoa.pojo.logistics.CarMsg;
import com.jz.xdkjoa.service.logistics.CarMsgService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
//springboot=spring+MVC
/**
 * 车辆操作的控制类
 * @Author zxq
 * @Date 2021-6-19 09:41
 */
@CrossOrigin
@RestController
@RequestMapping("/CarMsg")
public class CarMsgController {
    @Autowired
    CarMsgService carmsgService;

    @PostMapping("CarMsgList")
    public List showAllCarMsg(){
        List<CarMsg> list=carmsgService.getCarMsgsBiz();
        for(CarMsg e:list){
            System.out.println(e.toString());
        }
        return list;//返回视图
    }

    @GetMapping("showByState")
    public List showByState(String situation){
        List<CarMsg> list=carmsgService.showByStateBiz(situation);
        for(CarMsg e:list){
            System.out.println(e.toString());
        }
        return list;
    }

    @GetMapping("showByCarNum")
    public List showByCarNum(String car_num){
        List<CarMsg> list=carmsgService.showByCarNumBiz(car_num);
        for(CarMsg e:list){
            System.out.println(e.toString());
        }
        return list;
    }

    @GetMapping("addCar")
    public String addCar(){
        CarMsg carmsg=new CarMsg();
        carmsg.setCar_num("云F1111D");
        carmsg.setSituation("使用中");
        carmsg.setDepartment("财务部");
        carmsg.setCar_model("2021款 S 480 4MATIC");
        carmsgService.addCarBiz(carmsg);
        return "hello";
    }

//    @GetMapping("updateCarState")
//    public String updateCarState(String car_num){
//        carmsgService.updateCarStateBiz(car_num);
//        return "车辆状态改变成功";
//    }

}
