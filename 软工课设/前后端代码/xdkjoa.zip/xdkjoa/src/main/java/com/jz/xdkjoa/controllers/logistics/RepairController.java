package com.jz.xdkjoa.controllers.logistics;

import com.jz.xdkjoa.pojo.logistics.Repair;
import com.jz.xdkjoa.service.logistics.RepairService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.xml.crypto.Data;
import java.util.List;

/**
 * @Author zxq
 * @Date 2021-6-19 10:27
 */
@CrossOrigin
@RestController
@RequestMapping("/RepairMsg")
public class RepairController {
    @Autowired
    RepairService repairService;

    @PostMapping("addRepairRecord")
    public String addRepairRecord(@RequestBody Repair repair){
//        Repair repair=new Repair();
//        repair.setEquipment_num(1);
//        repair.setJob_num(1);
//        repair.setRepair_date("2021-6-18 10:00");
//        repair.setRepair_description("屏幕损坏");
//        repair.setRepair_money(5000.00);
//        repair.setRepair_type("设备");
//        repair.setTake_date("2021-6-19 13:25");
        System.out.println(repair.toString());
        repairService.addRepairRecordBiz(repair);
        return "添加维修记录成功";
    }

    @GetMapping("delRepairRecord")
    public String delRepairRecord(Integer repair_num){
        repairService.delRepairRecordBiz(repair_num);
        return "hello";
    }

    @PostMapping("showRepairRecord")
    public List showRepairRecord(){
        List<Repair> list=repairService.showRepairRecordBiz();
        for(Repair e:list){
            System.out.println(e.toString());
        }
        return list;
    }

    @GetMapping("updateRepairRecord")
    public String updateRepairRecord(Repair repair){
//        Repair repair=new Repair();
//        repair.setEquipment_num(1);
//        repair.setJob_num(1);
//        Data data=new Data;
//        repair.setRepair_date();
//        repair.setRepair_description("屏幕损坏");
//        repair.setRepair_money(5000.00);
//        repair.setRepair_type("设备");
//        repair.setTake_date("2021-6-19 13:25");
        repairService.updateRepairRecordBiz(repair);
        return "hello";

    }
}
