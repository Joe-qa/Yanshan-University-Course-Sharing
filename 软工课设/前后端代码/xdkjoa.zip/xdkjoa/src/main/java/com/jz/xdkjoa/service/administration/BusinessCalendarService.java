package com.jz.xdkjoa.service.administration;

import com.jz.xdkjoa.pojo.administration.BusinessCalendar;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public interface BusinessCalendarService {
    void addHeadlineBiz(BusinessCalendar headline);
    void delCalendarBiz(int schedule_num);
    List<BusinessCalendar> showBusinessCalendarBiz();
    void updateCalendarBiz(BusinessCalendar calendar);
}
