package com.jz.xdkjoa.controllers.pmanagement;

import com.jz.xdkjoa.pojo.pmanagement.Staff;
import com.jz.xdkjoa.service.pmanagement.StaffService;
import com.jz.xdkjoa.util.MD5;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;


import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/staff")
public class StaffController {

    @Autowired
    StaffService staffService;

    @PostMapping("stafflist")
    public List showStaffs()
    {
        List<Staff> list=staffService.showStaffsBiz();
        return list;
    }

    @PostMapping("addstaff")
    public String addStaff(@RequestBody Staff staff)
    {
        staffService.addStaffBiz(staff);
        System.out.println(staff.toString());
        return "hello";
    }

    @GetMapping("delstaff")
    public String delStaff(Integer job_num)
    {
        staffService.delStaffBiz(job_num);
        return "hello";
    }

    @PostMapping("updatestaff")
    public String updateStaff(@RequestBody  Staff staff)
    {
        staffService.updateStaffBiz(staff);
        return "hello";
    }

    @GetMapping("showStaffById")
    public Staff showStaffById(@RequestParam  Integer job_num)
    {
        Staff staff=staffService.showStaffByIdBiz(job_num);
        return staff;
    }

    @PostMapping("showStaffByName")
    public List<Staff> showStaffByName(@RequestBody Map<String,String> params)
    {
        System.out.println(params.get("staff_name")+","+params.get("depart_num"));
        Integer depart_num=null;
        if(params.get("depart_num")!=null&&!"".equals(params.get("depart_num"))){
            depart_num=Integer.parseInt(params.get("depart_num"));
        }
        List<Staff> list=staffService.showStaffByNameBiz(params.get("staff_name"),depart_num);
        return list;
    }
    @PostMapping("showStaffByDept")
    public List showStaffByDept(@RequestParam String depart_name)
    {
        List<Staff> list=staffService.showStaffByDeptBiz(depart_name);
        for (Staff s:list)
        {
            System.out.println(s.getStaff_name());
        }
        return list;
    }
    @GetMapping("validateStaff")
    public String validateStaff(String account,String staff_password){
        MD5 md5=new MD5();
        String md5pwd=md5.MD5Encode(staff_password);
        List<Staff> list=staffService.validateStaff(account);
        if(list.size()==0){
            return "此账号不存在";
        }
        else{
            Staff staff=list.get(0);
            if(staff.getStaff_password().equals(md5pwd)){
                return "登录成功";
            }
            else
            {
                return "密码错误";
            }
        }
    }

    @GetMapping("findStaffByAccount")
    public Staff showStaffByAccount(String account){
        return staffService.validateStaff(account).get(0);
    }

    @PostMapping("addstaffimage")
    public String addStaffImage(String image,Integer job_num){
        staffService.saveImageBiz(image,job_num);
        return "success";
    }

    @GetMapping("findstaffbydepartment")
    public List findStaffByDepartment(Integer depart_num){
        return staffService.findStaffByDepartmentBiz(depart_num);
    }
}
