package com.jz.xdkjoa.pojo.logistics;
/**
 * 与数据库中的CarMsg表做映射
 */

public class CarMsg {
    private String car_num;
    private String situation;
    private String department;
    private String car_model;

    public CarMsg(){
    }
    public CarMsg(String car_num, String situation, String department, String car_model) {
        this.car_num = car_num;
        this.situation = situation;
        this.department = department;
        this.car_model = car_model;
    }

    @Override
    public String toString() {
        return "CarMsg{" +
                "car_num='" + car_num + '\'' +
                ", situation=" + situation +
                ", department='" + department + '\'' +
                ", car_model='" + car_model + '\'' +
                '}';
    }

    public String getCar_num() {
        return car_num;
    }

    public void setCar_num(String car_num) {
        this.car_num = car_num;
    }

    public String getSituation() {
        return situation;
    }

    public void setSituation(String situation) {
        this.situation = situation;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getCar_model() {
        return car_model;
    }

    public void setCar_model(String car_model) {
        this.car_model = car_model;
    }
}
