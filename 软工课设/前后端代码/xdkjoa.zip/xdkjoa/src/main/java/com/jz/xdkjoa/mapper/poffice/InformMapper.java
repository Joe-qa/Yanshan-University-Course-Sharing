package com.jz.xdkjoa.mapper.poffice;

import com.jz.xdkjoa.pojo.poffice.Inform;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface InformMapper {

    /**
     *
     * @param job_num
     * @param inform_state
     * @param inform_type_name
     * 通过状态查看通告新闻
     * @return
     */
    List<Inform> showInformByState(Integer job_num, String inform_state, String inform_type_name);
    /**
     *修改通知公告状态  包括通知公告的关注状态和删除状态
     */
    void updateInform(Inform inform);
    void delInform(int news_id);
    void addInfrom(Inform inform);
}
