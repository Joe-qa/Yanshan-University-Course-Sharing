package com.jz.xdkjoa.service.logistics;

import com.jz.xdkjoa.pojo.logistics.Repair;

import java.util.List;

public interface RepairService {
    void addRepairRecordBiz(Repair repair);
    void delRepairRecordBiz(Integer repair_num);
    List<Repair> showRepairRecordBiz();
    void updateRepairRecordBiz(Repair repair);
}
