package com.jz.xdkjoa.pojo.administration;

import java.util.Date;

public class MeetingRecord {
    private int meeting_record_id;
    private int booking_num;
    private String meeting_content;
    private String detailrecord;
    private Date meetingtime;
    private int job_num;
    private  String meetingroom_num;

    public MeetingRecord(int meeting_record_id, int booking_num, String meeting_content, String detailrecord, Date meetingtime, int job_num, String meetingroom_num) {
        this.meeting_record_id = meeting_record_id;
        this.booking_num = booking_num;
        this.meeting_content = meeting_content;
        this.detailrecord = detailrecord;
        this.meetingtime = meetingtime;
        this.job_num = job_num;
        this.meetingroom_num = meetingroom_num;
    }
    public MeetingRecord(){}

    public int getMeeting_record_id() {
        return meeting_record_id;
    }

    public void setMeeting_record_id(int meeting_record_id) {
        this.meeting_record_id = meeting_record_id;
    }

    public int getBooking_num() {
        return booking_num;
    }

    public void setBooking_num(int booking_num) {
        this.booking_num = booking_num;
    }

    public String getMeeting_content() {
        return meeting_content;
    }

    public void setMeeting_content(String meeting_content) {
        this.meeting_content = meeting_content;
    }

    public String getDetailrecord() {
        return detailrecord;
    }

    public void setDetailrecord(String detailrecord) {
        this.detailrecord = detailrecord;
    }

    public Date getMeetingtime() {
        return meetingtime;
    }

    public void setMeetingtime(Date meetingtime) {
        this.meetingtime = meetingtime;
    }

    public int getJob_num() {
        return job_num;
    }

    public void setJob_num(int job_num) {
        this.job_num = job_num;
    }

    public String getMeetingroom_num() {
        return meetingroom_num;
    }

    public void setMeetingroom_num(String meetingroom_num) {
        this.meetingroom_num = meetingroom_num;
    }

    @Override
    public String toString() {
        return "MeetingRecord{" +
                "meeting_record_id=" + meeting_record_id +
                ", booking_num=" + booking_num +
                ", meeting_content='" + meeting_content + '\'' +
                ", detailrecord='" + detailrecord + '\'' +
                ", meetingtime=" + meetingtime +
                ", job_num=" + job_num +
                ", meetingroom_num='" + meetingroom_num + '\'' +
                '}';
    }
}
