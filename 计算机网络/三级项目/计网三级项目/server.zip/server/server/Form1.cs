﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace server
{
    public partial class Form1 : Form
    {
        int[] area = { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        int[] temp = { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        List<Color> Colorlist = new List<Color>();
        Color []col=new Color [9];
  

        public Form1()
        {
            InitializeComponent();
        }
        Socket tSocket;
        private void Form1_Load(object sender, EventArgs e)
        {
            Control.CheckForIllegalCrossThreadCalls = false;

            Colorlist.AddRange(GetFullColorList(4));
            textBox1.BackColor = Colorlist[0];
            textBox2.BackColor = Colorlist[1];
            textBox3.BackColor = Colorlist[2];
            textBox4.BackColor = Colorlist[3];
            IPAddress ip = IPAddress.Parse("127.0.0.1");
            IPEndPoint point = new IPEndPoint(ip, int.Parse("8090"));
            Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                socket.Bind(point);
                socket.Listen(10);
                ShowMsg("服务器开始监听");
                Thread thread = new Thread(AcceptInfo);
                thread.IsBackground = true;
                thread.Start(socket);
            }
            catch (Exception ex)
            {
                ShowMsg(ex.Message);
            }
            
        }
   
        void AcceptInfo(object o)
        {
            Socket socket = o as Socket;
            while (true)
            {
                try
                {
                   tSocket = socket.Accept();
                    string point = tSocket.RemoteEndPoint.ToString();
                    ShowMsg(point + "连接成功! ");
                    Thread th = new Thread(ReceiveMsg);
                    th.IsBackground = true;
                    th.Start(tSocket);
                }
                catch(Exception ex)
                {
                    ShowMsg(ex.Message);
                    break;
                }
            }
        }
        void ReceiveMsg(object o)
        {
            Socket client = o as Socket;
            while (true)
            {
                //try
               //{
                    byte[] buffer = new byte[1024 * 1024];
                    int n = client.Receive(buffer);
                    string words = Encoding.UTF8.GetString(buffer, 0, n);
                    int index = int.Parse(words.Substring(1, 1));
                    int num = int.Parse(words.Substring(9));
                     area[index - 1] = num;
                    heat();
                    ShowMsg("客户端"+client.RemoteEndPoint.ToString() + ":" + words);

                //}
                //catch(Exception ex)
                //{
                  // ShowMsg(ex.Message);
                //   break;
                //}
            }
        }
        void heat()
        {
            for (int i = 0; i < area.Length; i++)
            {
                if (area[i] > 25)
                {
                    col[i] = Colorlist[0];
                   
                }
                else if (area[i] > 20)
                {
                    col[i] = Colorlist[1];
                }
                else if (area[i] > 15)
                {
                    col[i] = Colorlist[2];
                }
                else
                {
                    col[i] = Colorlist[3];
                }
                if (area[i] == 0)
                {
                    col[i] = Color.White;
                }

            }
            pictureBox1.BackColor = col[0];
            pictureBox2.BackColor = col[1];
            pictureBox3.BackColor = col[2];
            pictureBox4.BackColor = col[3];
            pictureBox5.BackColor = col[4];
            pictureBox6.BackColor = col[5];
            pictureBox7.BackColor = col[6];
            pictureBox8.BackColor = col[7];
            pictureBox9.BackColor = col[8];
           
        }
        void ShowMsg(string msg)
        {
            txtLog.AppendText(msg + "\r\n");
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                string index = comboBox1.SelectedItem.ToString();
                
                string msg =index+" "+ txtMsg.Text;
                ShowMsg(msg);
                byte[] buffer = Encoding.UTF8.GetBytes(msg);
                tSocket.Send(buffer);
            }
            catch(Exception ex)
            {
                ShowMsg(ex.Message);
            }
        }
        public static List<Color> GetSingleColorList(Color srcColor, Color desColor, int count)
        {
            List<Color> colorFactorList = new List<Color>();
            int redSpan = desColor.R - srcColor.R;
            int greenSpan = desColor.G - srcColor.G;
            int blueSpan = desColor.B - srcColor.B;
            for (int i = 0; i < count; i++)
            {
                Color color = Color.FromArgb(
                    srcColor.R + (int)((double)i / count * redSpan),
                    srcColor.G + (int)((double)i / count * greenSpan),
                    srcColor.B + (int)((double)i / count * blueSpan)
                );
                colorFactorList.Add(color);
            }
            return colorFactorList;
        }
        public static List<Color> GetFullColorList(int totalCount)
        {
            List<Color> colorList = new List<Color>();
            if (totalCount > 0)
            {
                colorList.AddRange(GetSingleColorList(Color.Red, Color.Yellow, totalCount / 5 + (totalCount % 5 > 0 ? 1 : 0)));
                colorList.AddRange(GetSingleColorList(Color.Yellow, Color.Lime, totalCount / 5 + (totalCount % 5 > 1 ? 1 : 0)));
                colorList.AddRange(GetSingleColorList(Color.Lime, Color.Cyan, totalCount / 5 + (totalCount % 5 > 2 ? 1 : 0)));
                colorList.AddRange(GetSingleColorList(Color.Cyan, Color.Blue, totalCount / 5 + (totalCount % 5 > 3 ? 1 : 0)));
                colorList.AddRange(GetSingleColorList(Color.Blue, Color.Magenta, totalCount / 5 + (totalCount % 5 > 4 ? 1 : 0)));
            }
            return colorList;
        }

    }
}
