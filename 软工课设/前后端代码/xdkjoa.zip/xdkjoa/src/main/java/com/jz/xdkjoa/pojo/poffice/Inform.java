package com.jz.xdkjoa.pojo.poffice;

import com.jz.xdkjoa.pojo.pmanagement.Staff;

import java.sql.Date;
import java.sql.Time;

public class Inform {
    private int news_id;
    private String inform_type_name;
    private String inform_des;
    private Date inform_receive_date;
    private String inform_state;
    private int job_num;
    private String inform_concrete_des;

    private Staff staff;

    public Staff getStaff() {
        return staff;
    }

    public void setStaff(Staff staff) {
        this.staff = staff;
    }

    public Inform() {
    }

    public Inform(int news_id, String inform_type_name, String inform_des,  Date inform_receive_date, String inform_state, int job_num, String inform_concrete_des, Staff staff) {
        this.news_id = news_id;
        this.inform_type_name = inform_type_name;
        this.inform_des = inform_des;
        this.inform_receive_date = inform_receive_date;
        this.inform_state = inform_state;
        this.job_num = job_num;
        this.inform_concrete_des = inform_concrete_des;
        this.staff = staff;
    }

    @Override
    public String toString() {
        return "Inform{" +
                "news_id=" + news_id +
                ", inform_type_name='" + inform_type_name + '\'' +
                ", inform_des='" + inform_des + '\'' +
                ", inform_receive_date=" + inform_receive_date +
                ", inform_state='" + inform_state + '\'' +
                ", job_num=" + job_num +
                ", inform_concrete_des='" + inform_concrete_des + '\'' +
                ", staff=" + staff +
                '}';
    }

    public int getNews_id() {
        return news_id;
    }

    public void setNews_id(int news_id) {
        this.news_id = news_id;
    }

    public String getInform_type_name() {
        return inform_type_name;
    }

    public void setInform_type_name(String inform_type_name) {
        this.inform_type_name = inform_type_name;
    }

    public String getInform_des() {
        return inform_des;
    }

    public void setInform_des(String inform_des) {
        this.inform_des = inform_des;
    }

    public Date getInform_receive_date() {
        return inform_receive_date;
    }

    public void setInform_receive_date(Date inform_receive_date) {
        this.inform_receive_date = inform_receive_date;
    }

    public String getInform_state() {
        return inform_state;
    }

    public void setInform_state(String inform_state) {
        this.inform_state = inform_state;
    }

    public int getJob_num() {
        return job_num;
    }

    public void setJob_num(int job_num) {
        this.job_num = job_num;
    }

    public String getInform_concrete_des() {
        return inform_concrete_des;
    }

    public void setInform_concrete_des(String inform_concrete_des) {
        this.inform_concrete_des = inform_concrete_des;
    }
}
