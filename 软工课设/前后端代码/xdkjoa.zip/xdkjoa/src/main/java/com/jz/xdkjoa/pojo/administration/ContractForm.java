package com.jz.xdkjoa.pojo.administration;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.jz.xdkjoa.pojo.pmanagement.Staff;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.datetime.standard.Jsr310DateTimeFormatAnnotationFormatterFactory;

import java.util.Date;

public class ContractForm {
    private int contract_num;
    private int job_num;
    private String contractheadline;
    private String firstparty;
    private String secondparty;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @JsonFormat(timezone = "GMT+8",pattern = "yyyy-MM-dd")
    private Date signdate;
    private double reward;
    private String contractstate;
    private Staff staff;

    public Staff getStaff() {
        return staff;
    }

    public void setStaff(Staff staff) {
        this.staff = staff;
    }

    public ContractForm(int contract_num, int job_num, String contractheadline, String firstparty, String secondparty, Date signdate, double reward, String contractstate) {
        this.contract_num = contract_num;
        this.job_num = job_num;
        this.contractheadline = contractheadline;
        this.firstparty = firstparty;
        this.secondparty = secondparty;
        this.signdate = signdate;
        this.reward = reward;
        this.contractstate = contractstate;
    }
    public ContractForm(){}

    public int getContract_num() {
        return contract_num;
    }

    public void setContract_num(int contract_num) {
        this.contract_num = contract_num;
    }

    public int getJob_num() {
        return job_num;
    }

    public void setJob_num(int job_num) {
        this.job_num = job_num;
    }

    public String getContractheadline() {
        return contractheadline;
    }

    public void setContractheadline(String contractheadline) {
        this.contractheadline = contractheadline;
    }

    public String getFirstparty() {
        return firstparty;
    }

    public void setFirstparty(String firstparty) {
        this.firstparty = firstparty;
    }

    public String getSecondparty() {
        return secondparty;
    }

    public void setSecondparty(String secondparty) {
        this.secondparty = secondparty;
    }

    public Date getSigndate() {
        return signdate;
    }

    public void setSigndate(Date signdate) {
        this.signdate = signdate;
    }

    public double getReward() {
        return reward;
    }

    public void setReward(double reward) {
        this.reward = reward;
    }

    public String getContractstate() {
        return contractstate;
    }

    public void setContractstate(String contractstate) {
        this.contractstate = contractstate;
    }

    @Override
    public String toString() {
        return "ContractForm{" +
                "contract_num=" + contract_num +
                ", job_num=" + job_num +
                ", contractheadline='" + contractheadline + '\'' +
                ", firstparty='" + firstparty + '\'' +
                ", secondparty='" + secondparty + '\'' +
                ", signdate=" + signdate +
                ", reward=" + reward +
                ", contractstate='" + contractstate + '\'' +
                '}';
    }
}
