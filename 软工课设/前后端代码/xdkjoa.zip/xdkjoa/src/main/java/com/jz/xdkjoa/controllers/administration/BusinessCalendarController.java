package com.jz.xdkjoa.controllers.administration;


import com.jz.xdkjoa.pojo.administration.BusinessCalendar;
import com.jz.xdkjoa.service.administration.BusinessCalendarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/headline")
public class BusinessCalendarController {
//    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");//设置日期格式
//          System.out.println(df.format(new Date()));// new Date()为获取当前系统时间
    @Autowired(required = false)
    BusinessCalendarService businessCalendarService;
    @PostMapping("addheadline")
    public String addHeadline(@RequestBody  BusinessCalendar headline){

        businessCalendarService.addHeadlineBiz(headline);
        return "success";
    }
    @PostMapping("delcalendar")
    public String delCalendar( int schedule_num){
        businessCalendarService.delCalendarBiz( schedule_num);
        return "success";
    }
    @PostMapping("showcalendar")
    public List<BusinessCalendar> showBusinessCalendar(){
//        System.out.println(headline.toString());
        List<BusinessCalendar> list =businessCalendarService.showBusinessCalendarBiz();
        return list;
    }
    @PostMapping("updatecalendar")
    public String updateCalendar(@RequestBody BusinessCalendar calendar){
        System.out.println(calendar);
        businessCalendarService.updateCalendarBiz(calendar);
        return "success";
    }

}
