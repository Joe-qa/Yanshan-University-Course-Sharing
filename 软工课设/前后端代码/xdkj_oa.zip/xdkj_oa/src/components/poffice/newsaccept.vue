<template>
	<el-main style="margin-top:0px;padding: 0px;">
		<div style="display: flex;flex-direction: row;">

			<el-button type="primary" icon="el-icon-delete" @click="deleteRows()">删除
			</el-button>
			<el-button type="primary" icon="el-icon-delete" @click="completeDel()">彻底删除</el-button>
			<!-- 通知公告选择 -->
			<el-select style="margin-left: 850px;min-width: 150px;" v-model="value" @change="getValue">
				<el-option v-for="item in options" :key="item.value" :label="item.label" :value="item">
					<!--遍历获取到的select列表data 使用v-for要加key，避免遍历出错 option的显示值，用户看到的值 option实际值，发送到后台的值-->
				</el-option>
			</el-select>
		</div>
		<!-- 关联了一个tempcollect的数据 -->
		<el-table ref="multipleTable" :data="tempcollect" tooltip-effect="dark" style="width: 100%"
			@selection-change="handleSelectionChange">>
			<el-table-column type="selection" width="55">
			</el-table-column>
			<el-table-column prop="news_id" label="编号" width="150">
			</el-table-column>
			<el-table-column prop="inform_type_name" label="类型" width="150">
			</el-table-column>
			</el-table-column>
			<el-table-column prop="inform_des" label="主题" width="550">
			</el-table-column>
			<el-table-column label="收到日期" width="150">
				<template slot-scope="scope">{{ scope.row.inform_receive_date }}</template>
			</el-table-column>
			<el-table-column fixed="right" label="操作" width="100">
				<template slot-scope="scope">
					<el-button type="text" size="small"
						@click="handleClick(scope.row,scope.$index);toDetail(scope.row)">查看
					</el-button>
					<el-button type="text" size="small" @click="handleClick(scope.row,scope.$index);addCol(scope.row)">
						收藏
					</el-button>
				</template>
			</el-table-column>
		</el-table>
		<!-- 分页控件 -->
		<div class="block" style="justify-content: center; display: flex; margin-top: 10px;">
			<el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
				:current-page="currentPage" :page-sizes="[5, 10, 15]" :page-size="pageSize"
				layout="total, sizes, prev, pager, next, jumper" :total="collect.length">
			</el-pagination>
		</div>
		<!-- 弹框内容设置 -->
		<el-dialog title="具体内容" :visible.sync="dialogFormVisible">
			{{detail}}
			<div slot="footer" class="dialog-footer">
				<el-button @click="cancel($canceled)">取 消</el-button>
				<el-button type="primary" @click="save()">确 定</el-button>
			</div>
		</el-dialog>

	</el-main>
</template>

<script>
	export default {
		created() {
			let that = this
			this.$axios({
				method: 'get',
				url: 'http://localhost:8888/staff/findStaffByAccount?account=' + that.getCookie("account")
			}).then(function(response) {
				that.$axios({
					method: 'get', //信息比较单一 用get  信息数量比较大，并且涉及安全性 用post
					url: 'http://localhost:8888/inform/showinform?job_num=' + response.data.job_num +
						'&inform_state=未关注&inform_type_name=通知'
				}).then(function(res) {
					//console.log(res)
					that.collect = res.data;
					that.tempcollect = that.collect.slice(0, that.pageSize);
				})
			})
			//如果没有这句代码，select中初始化会是空白的，默认选中就无法实现
			this.value = this.options[0].label;
		},
		data() {
			return {
				//从后端获取的查询数据
				collect: [],
				//多选结果
				multipleSelection: [],
				//分页
				currentPage: 1,
				pageSize: 5,
				tempcollect: [],
				//多选框
				options: [{
					value: '选项1',
					label: '通知'
				}, {
					value: '选项2',
					label: '公告'
				}],
				value: '',
				dialogTableVisible: false,
				//弹出框的可见与否
				dialogFormVisible: false
			}
		},
		methods: {
			getCookie: function(key) {
				if (document.cookie.length > 0) {
					var start = document.cookie.indexOf(key + '=')
					if (start !== -1) {
						start = start + key.length + 1
						var end = document.cookie.indexOf(';', start)
						if (end === -1) end = document.cookie.length
						return unescape(document.cookie.substring(start, end))
					}
				}
				return ''
			},
			//添加关注的操作
			addCol(row, index) {
				let that = this;
				row.inform_state = "已关注";
				this.inform = row;
				this.$axios({
					method: 'post',
					url: 'http://localhost:8888/inform/updateinform',
					data: this.inform,
					headers: {
						'Content-Type': 'application/json;charset=utf-8' //改这里就好了
					}
				}).then(res => {
					that.$message({
						message: '恭喜您，收藏成功！！！！',
						type: 'success',
						offset: 300
					});
				}).catch(function(error) {
					console.log(error)
				});
				this.timer = setTimeout(() => { //设置延迟执行
					this.$router.go(0);
				}, 0.1);
				that.$message({
					message: '恭喜您，收藏成功！！！！',
					type: 'success',
					offset: 300
				});
			},
			//对查看弹出框的操作
			toDetail(row) {
				this.detail = row.inform_concrete_des;
				this.dialogFormVisible = true;
			},
			cancel() {
				this.dialogFormVisible = false
			},
			save() {
				this.dialogFormVisible = false
			},
			handleClick(row, index) {
				console.log(row, index);
			},

			//对于选择改变的操作，获取选择的对象
			handleSelectionChange(val) {
				this.multipleSelection = val;
				console.log(this.multipleSelection);

			},
			//每页条数切换
			handleSizeChange(pageSize) {
				this.pageSize = pageSize;
				this.handleCurrentChange(this.currentPage);
			},
			//页码切换
			handleCurrentChange(currentPage) {
				this.currentPage = currentPage;
				this.currentChangePage(this.collect, currentPage);
			},
			//分页实现
			currentChangePage(list, currentPage) {
				let from = (currentPage - 1) * this.pageSize;
				let to = currentPage * this.pageSize;
				this.tempcollect = this.collect.slice(from, to);
			},
			//彻底删除
			completeDel() {
				this.$confirm('此操作将永久删除, 是否继续?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning'
				}).then(() => {
					for (let i of this.multipleSelection) {
						let that = this
						let news_id = i.news_id;
						this.$axios({
							method: 'post',
							url: 'http://localhost:8888/inform/delinform?news_id=' + news_id,
						}).then(function(res) {
							console.log(res)
							that.collect = res.data
							that.tempcollect = that.collect.slice(0, that.pageSize);
						}).catch(function(error) {
							console.log(error)
						})
					};
					this.timer = setTimeout(() => { //设置延迟执行
						this.$router.go(0);
					}, 1);
					that.$message({
						message: '彻底删除成功！！！！',
						type: 'success',
						offset: 300
					});
				})
			},
			//删除行
			deleteRows() {
				for (let i of this.multipleSelection) {
					i.inform_state = "已删除";
					this.inform = i;
					this.$axios({
						method: 'post',
						url: 'http://localhost:8888/inform/updateinform',
						data: this.inform,
						headers: {
							'Content-Type': 'application/json;charset=utf-8' //改这里就好了
						}
					}).then(res => {
						that.$message({
							message: '删除成功！！！！',
							type: 'success',
							offset: 300
						});
					}).catch(function(error) {
						console.log(error)
					})
				};
				this.timer = setTimeout(() => { //设置延迟执行
					this.$router.go(0);
				}, 1);
				that.$message({
					message: '删除成功！！！！',
					type: 'success',
					offset: 300
				});
			},

			//通知、公告类型的选择
			getValue: function(value) {
				let that = this;
				this.$axios({
						method: 'get',
						url: 'http://localhost:8888/staff/findStaffByAccount?account=' + that.getCookie("account")
					}).then(function(response) {
						that.$axios({
							method: 'get',
							url: 'http://localhost:8888/inform/showinform?job_num=' + response.data
								.job_num +
								'&inform_state=未关注&inform_type_name=' + value.label,
						}).then(function(res) {
							console.log(res);
							that.collect = res.data;
							that.tempcollect = that.collect.slice(0, that.pageSize);
						})

					}),
					console.log(value.label);
			}
		}
	}
</script>
