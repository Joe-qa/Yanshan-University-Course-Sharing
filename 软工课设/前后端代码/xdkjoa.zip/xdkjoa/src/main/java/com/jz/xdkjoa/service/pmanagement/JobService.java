package com.jz.xdkjoa.service.pmanagement;

import com.jz.xdkjoa.pojo.pmanagement.Job;

import java.util.List;

public interface JobService {

    void addJobBiz(Job job);
    Job showJobByNameBiz(String post_name);
    void updateJobBiz(Job job);
    void delJobBiz(Integer post_num);
    List<Job> showJobBiz();

}
