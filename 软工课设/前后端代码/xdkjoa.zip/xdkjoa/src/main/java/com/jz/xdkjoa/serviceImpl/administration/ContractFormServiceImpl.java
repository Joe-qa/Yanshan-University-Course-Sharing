package com.jz.xdkjoa.serviceImpl.administration;

import com.jz.xdkjoa.mapper.administration.ContractFormMapper;
import com.jz.xdkjoa.pojo.administration.ContractForm;
import com.jz.xdkjoa.service.administration.ContractFormService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

@Service
public class ContractFormServiceImpl implements ContractFormService {
    @Autowired(required = false)
    ContractFormMapper contractformmapper;
    //增加合同表的一条信息
    @Override
    public void addContractBiz(ContractForm contract) {
        contractformmapper.addContract(contract);
    }
    //删除合同表的一条信息
    @Override
    public void delContractBiz(int contract_num){contractformmapper.delContract(contract_num);}
    //查询合同表的一条信息
    @Override
    public List<ContractForm> findContractBiz( String contractstate) { return contractformmapper.findContract(contractstate);}
    //显示出合同表
    @Override
    public List<ContractForm> showContractBiz (){return contractformmapper.showContract();}

}
