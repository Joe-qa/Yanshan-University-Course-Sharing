package com.jz.xdkjoa.serviceImpl.pmanagement;

import com.jz.xdkjoa.mapper.pmanagement.RightMapMapper;
import com.jz.xdkjoa.pojo.pmanagement.RightMap;
import com.jz.xdkjoa.service.pmanagement.RightMapService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RightMapServiceImpl implements RightMapService {
    @Autowired(required = false)
    RightMapMapper rightMapMapper;

    @Override
    public List<RightMap> findRightBiz(String account) {
        return rightMapMapper.findRight(account);
    }
}
