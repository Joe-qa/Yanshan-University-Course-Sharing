import Vue from 'vue'
import Router from 'vue-router'
import Login from '../components/login.vue'
import ElementUI from 'element-ui';
import Index from '../components/index.vue'
import Main from '../components/main.vue'
import NOTfound from '../components/404.vue'
import Editcontract from '../components/administration/editcontract.vue'
import Businesscalendar from '../components/administration/businesscalendar.vue'
import Contract from '../components/administration/contract.vue'
import Newsaccept from '../components/poffice/newsaccept.vue'
import Newsrubbish from '../components/poffice/newsrubbish.vue'
import Newscollect from '../components/poffice/newscollect.vue'
import allCar from '../components/logistics/CarManage/allCar.vue'
import FreeCar from '../components/logistics/CarManage/freeCar.vue'
import useCar from '../components/logistics/CarManage/useCar.vue'
import equipmentMsg from '../components/logistics/EquipmentManage/EquimentMsg.vue'
import repairRecord from '../components/logistics/EquipmentManage/repairRecord.vue'
import historyRecord from '../components/logistics/CarManage/historyRecord.vue'
import addStaff1 from '../components/pmanagement/addStaff1.vue'
import addStaff2 from '../components/pmanagement/addStaff2.vue'
import 'element-ui/lib/theme-chalk/index.css';
import ShowStaff from '../components/pmanagement/showStaff.vue'
import ShowJob from '../components/pmanagement/showJob.vue'
import Mytask from '../components/poffice/mytask.vue'
import Weektask from '../components/poffice/weektask.vue'
import Monthlook from '../components/poffice/monthlook.vue'
import Tree from '../components/pmanagement/departmentTree.vue'
import Sendnotice from '../components/administration/sendnotice.vue'

Vue.use(ElementUI);


Vue.use(Router)

export default new Router({
	routes: [{
			path: '/',
			redirect: '/login'
		},

		{
			path: '/login',

			name: 'login',
			component: Login
		},

		{
			path: '/index',
			name: 'index',
			component: Index,
			children: [{
					path: '/',
					redirect: '/main'
				}, {
					path: '/main',
					name: "main",
					component: Main
				},
				{
					path: 'businesscalendar',
					name: 'businesscalendar',
					component: Businesscalendar
				},
				{
					path: 'contract',
					name: 'contract',
					component: Contract
				},
				{
					path: 'editcontract',
					name: 'editcontract',
					component: Editcontract
				},
				{
					path: 'newsaccept',
					name: 'newsaccept',
					component: Newsaccept
				},
				{
					path: 'newsrubbish',
					name: 'newsrubbish',
					component: Newsrubbish
				},
				{
					path: 'newscollect',
					name: 'newscollect',
					component: Newscollect
				},
				{
					path: 'allCar',
					name: 'allCar',
					component: allCar,
				},
				{
					path: 'freeCar',
					name: 'freeCar',
					component: FreeCar
				},

				{
					path: 'useCar',
					name: 'useCar',
					component: useCar
				},
				{
					path: 'historyRecord',
					name: 'historyRecord',
					component: historyRecord
				},
				{
					path: 'equipmentMsg',
					name: 'equipmentMsg',
					component: equipmentMsg
				},
				{
					path: 'repairRecord',
					name: 'repairRecord',
					component: repairRecord
				},
				{
					path: 'showJob',
					name: 'showJob',
					component: ShowJob
				},
				{
					path: 'addStaff1',
					name: 'addStaff1',
					component: addStaff1
				},
				{
					path: 'addStaff2',
					name: 'addStaff2',
					component: addStaff2
				},
				{
					path: 'showStaff',
					name: 'showStaff',
					component: ShowStaff
				},
				{
					path: 'departmentTree',
					name: 'departmentTree',
					component: Tree
				},
				{
					path: 'mytask',
					name: 'mytask',
					component: Mytask
				},
				{
					path: 'weektask',
					name: 'weektask',
					component: Weektask
				},


				{
					path: 'monthlook',
					name: 'monthlook',
					component: Monthlook
				},
				{
					path:'sendnotice',
					name:'sendnotice',
					component:Sendnotice
				}
			]
		},
		{
			path: '*',
			name: 'NOTfound',
			component: NOTfound,
		}
	],
	mode: 'history',
})
