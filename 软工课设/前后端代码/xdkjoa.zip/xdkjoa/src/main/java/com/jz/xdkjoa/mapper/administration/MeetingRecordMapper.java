package com.jz.xdkjoa.mapper.administration;

public interface MeetingRecordMapper {
}
