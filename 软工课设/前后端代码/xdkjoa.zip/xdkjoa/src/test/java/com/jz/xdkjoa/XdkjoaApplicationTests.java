package com.jz.xdkjoa;
import com.jz.xdkjoa.controllers.administration.ContractFormController;
import com.jz.xdkjoa.controllers.logistics.CarRecordController;
import com.jz.xdkjoa.controllers.pmanagement.DepartmentController;
import com.jz.xdkjoa.controllers.pmanagement.StaffController;
import com.jz.xdkjoa.mapper.pmanagement.DepartmentMapper;
import com.jz.xdkjoa.mapper.pmanagement.RightMapMapper;
import com.jz.xdkjoa.mapper.pmanagement.StaffMapper;
import com.jz.xdkjoa.pojo.pmanagement.Job;
import com.jz.xdkjoa.pojo.pmanagement.Staff;
import com.jz.xdkjoa.service.pmanagement.JobService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
class XdkjoaApplicationTests {

    @Autowired(required = false)
    StaffController staffController;
    @Test
    void showAllStaff()
    {
        System.out.println(staffController.showStaffs());
    }

    @Test
    void addStaff()
    {
        Staff staff=new Staff();
        staff.setStaff_name("张三");
        staff.setJob_num(18);
        staff.setPost_num(6);
        staff.setDepart_num(3);
        staff.setAccount("201811040568");
        staff.setStaff_password("123456");
        staff.setGender("男");
        staff.setStaff_type("正式员工");
        staff.setIdentity_num("130524200105211538");
        staff.setEmail("58233@qq.com");
        staff.setIn_office("是");
        staffController.addStaff(staff);
    }

    @Test
    void delStaff()
    {
        staffController.delStaff(18);
    }

    @Autowired(required = false)
    JobService jobService=null;
    @Test
    void showJobByName()
    {
        System.out.println(jobService.showJobByNameBiz("总经理"));
    }

    @Test
    void updateJob()
    {
        Job job=new Job();
        job.setPost_num(6);
        job.setPost_name("职员");
        job.setPost_type("非研发");
        job.setPost_level(5);
        job.setSuper_post("总监");
        job.setResponsibilities("为资本家的幸福生活奋斗");
        job.setEntry_requirement("本科生");
        job.setPost_overview("为资本家的幸福生活奋斗");
        job.setVacation(8);
        jobService.updateJobBiz(job);
    }

    @Test
    void delJob()
    {
        jobService.delJobBiz(13);
    }

    @Autowired
    DepartmentController departmentController;
    @Test
    void showAllDep()
    {
        System.out.println(departmentController.showAllDepartmentsBiz());
    }
}
