<template>
	<div>
		<el-form :inline="true" ref="form1" label-width="80px">
		<!-- 	<el-form-item label="起草人">
				<el-select v-model="value1" clearable placeholder="请选择起草人" required="true">
					<el-option v-for="item in options1" :key="item.value" :label="item.label" :value="item.value">
					</el-option>
				</el-select>
			</el-form-item> -->
			<el-form-item label="合同状态">
				<el-select v-model="value" clearable placeholder="请选择合同状态" required="true">
					<el-option v-for="item in options" :key="item.value" :label="item.label" :value="item.value">
					</el-option>
				</el-select>
			</el-form-item>
			<el-form-item>
				<el-button type="primary" @click="search()">点击查询</el-button>
			</el-form-item>
			<el-form-item>
				<el-button type="primary" @click="addcontract()">新增合同</el-button>
			</el-form-item>
			<el-form-item>
				<el-button type="primary" @click="exportExcel()">数据导出</el-button>
			</el-form-item>
		</el-form>
		<el-scrollbar style="height: 100%;">
			<el-table :data="tableDatalist" v-model="tableData" id="outExcel">
				<el-table-column prop="contract_num" label="合同编号">
				</el-table-column>
				<el-table-column prop="staff.staff_name" label="起草人">
				</el-table-column>
				<el-table-column prop="contractheadline" label="合同主题">
				</el-table-column>
				<el-table-column prop="firstparty" label="甲方">
				</el-table-column>
				<el-table-column prop="secondparty" label="乙方">
				</el-table-column>
				<el-table-column prop="signdate" label="合同签署日期">
				</el-table-column>
				<el-table-column prop="reward" label="金额">
				</el-table-column>
				<el-table-column prop="contractstate" label="合同状态">
				</el-table-column>

				<el-table-column label="操作">
					<template slot-scope="scope">
						<!-- <el-button type="danger"  size="mini"@click="deleted()">删除数据</el-button> -->
						<el-button-group>
							<el-upload class="upload-demo" action="http://localhost:8888/upload/save"
								:on-change="handleChange" :on-success="onSuccess" :on-error="onError"
								:before-upload="beforeupload" :file-list="fileList">
								<el-button type="primary" size="mini">上传合同</el-button>
								<a :href="urlPath" download="" target="_blank" style="color: #000000;">下载</a>
							</el-upload>
							<!-- <el-button type="primary" size="mini">预览下载</el-button> -->
							<el-button type="danger" size="mini" @click="deleted(scope.$index,tableData,scope.row)">删除数据
							</el-button>
						</el-button-group>
					</template>
				</el-table-column>
			</el-table>
		</el-scrollbar>
		<!--分页实现-->
		<div class="paginationClass" style="text-align: center;">
			<el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
				:current-page="currentPage" :page-sizes="[5,10,15]" :page-size="pageSize"
				layout="total, sizes, prev, pager, next, jumper" :total="tableData.length">
			</el-pagination>
		</div>

		<el-dialog title="新增合同" :visible.sync="dialogFormVisible">
			<el-form :model="form" :rules="rules" ref="form" label-width="100px">
				<!-- <el-form-item label="合同编号" prop="contract_num">
					<el-input v-model="form.contract_num" placeholder="请输入合同编号" autocomplete="off"></el-input>
				</el-form-item> -->
				<el-form-item label="员工" prop="job_num">
					<el-select v-model="form.job_num" placeholder="请选择员工" autocomplete="off">
						<el-option v-for="item in staff" :key="item.job_num" :label="item.staff_name" :value="item.job_num">
					</el-option>
					</el-select>
				</el-form-item>
				<el-form-item label="合同主题" prop="contractheadline">
					<el-input v-model="form.contractheadline" placeholder="请输入主题" autocomplete="off"></el-input>
				</el-form-item>

				<el-form-item label="甲方" prop="firstparty">
					<el-input v-model="form.firstparty" placeholder="请输入甲方" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="乙方" prop="secondparty">
					<el-input v-model="form.secondparty" placeholder="请输入乙方" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="签署日期" prop="signdate">
					<el-date-picker type="date" placeholder="请选择签署日期" value-format="yyyy-MM-dd" v-model="form.signdate">
					</el-date-picker>
				</el-form-item>
				<el-form-item label="金额" prop="reward">
					<el-input v-model="form.reward" placeholder="请输入金额" autocomplete="off"></el-input>
				</el-form-item>
				<el-form-item label="合同状态" prop="contractstate">
					<el-select v-model="form.contractstate" placeholder="请选择合同状态">
						<el-option label="已完成" value="已完成"></el-option>
						<el-option label="未完成" value="未完成"></el-option>
					</el-select>
				</el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click="cancel($canceled)">取 消</el-button>
				<el-button type="primary" @click="save()">确 定 </el-button>
			</div>
		</el-dialog>


	</div>
</template>

<script>
	export default {
		inject: ['reload'],
		created() {
			let that = this
			// this.$axios({
			// 	method:''
			// })
			this.$axios({
				method: 'post',
				url: 'http://localhost:8888/contract/showcontract'
			}).then(function(response) {
				that.tableData = response.data
				that.tableDatalist = that.tableData.slice(0, that.pageSize);
				for(let o in response.data){
					console.log(response.data[o].job_num)
					that.$axios({
						method:'get',
						url:'http://localhost:8888/staff/showStaffById?job_num='+response.data[o].job_num
					}).then(function(response){
						that.options1.push({
							'value':response.data.job_num,
							'label':response.data.staff_name
						})
					})
				}
			}),
			this.$axios({
				method:'post',
				url:'http://localhost:8888/staff/stafflist'
			}).then(function(response){
				that.staff=response.data
				console.log(response)
			})
			
		},
		data() {
			return {
				staff:[],
				input0: '',
				input: '',
				urlPath: '',
				currentPage: 1,
				pageSize: 5,
				tableDatalist: [],
				tableData: [],
				value: '',
				options1: [],
				options: [{
						value: '已完成',
						label: '已完成'
					},
					{
						value: '未完成',
						label: '未完成'
					}
				],
				dialogTableVisible: false,
				dialogFormVisible: false,
				form: {
					contract_num: '',
					job_num: '',
					contractheadline: '',
					firstparty: '',
					secondparty: '',
					signdate: '',
					reward: '',
					contractstate: ''
				},
				rules: {
					// contract_num: [{
					// 	required: true,
					// 	message: '请输入合同编号',
					// 	trigger: 'blur'
					// }],
					job_num: [{
						required: true,
						message: '请选择员工',
						trigger: 'change'
					}],
					contractheadline: [{
						required: true,
						message: '请输入合同主题',
						trigger: 'blur'
					}],
					firstparty: [{
						required: true,
						message: '请输入甲方',
						trigger: 'blur'
					}],
					secondparty: [{
						required: true,
						message: '请输入乙方',
						trigger: 'blur'
					}],
					signdate: [{
						required: true,
						message: '请选择合同签署日期',
						trigger: 'change'
					}],
					reward: [{
						required: true,
						message: '请输入合同金额',
						trigger: 'blur'
					}],
					contractstate: [{
							required: true,
							message: '请选择合同状态',
							trigger: 'change'
						}

					]
				},
			}
		},
		methods: {
			exportExcel: function() {
				let tables = document.querySelector("#outExcel") //根据id选取到要导出的表格
				let table_book = this.$XLSX.utils.table_to_book(tables)
				let table_write = this.$XLSX.write(table_book, {
					bookType: "xlsx",
					bookSST: true,
					type: "array"
				})
				try {
					this.$FileSaver.saveAs(new Blob([table_write], {
						type: "application/octet-stream"
					}), "contract.xlsx")
				} catch (e) {
					console.log(e, table_write)
				}
				return table_write
			},
			handleSizeChange: function(pageSize) {
				this.pageSize = pageSize
				this.handleCurrentChange(this.currentPage)

			},
			handleCurrentChange: function(currentPage) {
				this.currentPage = currentPage
				this.currentChangePage(this.tableData, currentPage)
			},
			currentChangePage(list, currentPage) {
				let from = (currentPage - 1) * this.pageSize
				let to = currentPage * this.pageSize
				this.tableDatalist = this.tableData.slice(from, to)

			},
			onSuccess(response, file, fileList) {
				this.urlPath = "http://localhost:8888/upload/" + response
			},

			addcontract() {
				this.dialogFormVisible = true
			},
			search() {
				console.log(this.value)
				let that = this
				this.$axios({
					method: 'get',
					url: 'http://localhost:8888/contract/findcontract?contractstate='+this.value
				}).then(function(response) {
					that.tableData = response.data
					console.log('>>>>>'+response.data)
					that.tableDatalist = that.tableData.slice(0, that.pageSize);

				})
			},
			cancel() {
				this.dialogFormVisible = false
			},
			save() {
				let that = this
				this.$axios({
					method: 'post',
					url: 'http://localhost:8888/contract/addcontract',
					data: that.form
				}).then(function(res) {
					console.log(res)
					if (res.data == "success") {
						that.$message.success('添加成功')
						that.reload()
					} else {
						that.$message.error('添加失败')
					}

				})
				this.dialogFormVisible = false
			},
			deleted(index, rows, row) {
				this.$confirm('此操作将永久删除此条合同记录, 是否继续?', '提示', {
					confirmButtonText: '确定',
					cancelButtonText: '取消',
					type: 'warning',
				}).then(() => {
					let contract_num = row.contract_num
					let that = this
					console.log('>>>>>', contract_num)
					this.$axios({
						method: 'post',
						url: 'http://localhost:8888/contract/delcontract?contract_num=' + contract_num
					}).then(function(res) {
						console.log(res.data)
						if (res.data == "success") {
							that.$message.success('删除成功')
							that.reload()
						} else {
							that.$message.error('删除失败')
						}

					})
				})

			}
		},
	}
</script>

<style>

</style>
