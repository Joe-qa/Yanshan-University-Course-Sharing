<template>
	<div style="display: flex;flex-direction: column;align-items: center;">
		<div style="margin-left: 10px; margin-right: auto;">
			<el-button type="primary" icon="el-icon-upload" @click="exportExcel()">
				导出</el-button>
		</div>
		<div>
		<el-table ref="multipleTable" :data="equipmentMsgList" tooltip-effect="dark" style="width: 100%"
			@selection-change="handleSelectionChange" id="outExcel">
			<el-table-column prop="equipment_num" label="设备编号" width="200">
			</el-table-column>
			<el-table-column prop="equipment_name" label="设备名" width="200">
			</el-table-column>
			
			<el-table-column prop="equipment_life" label="使用年限" width="200">
			</el-table-column>
			<el-table-column prop="use_situation" label="使用情况" width="200">
			</el-table-column>
			<el-table-column prop="equipment_situation" label="设备情况" width="250">
			</el-table-column>
		</el-table>
		</div>
		<div class="block" style="justify-content: center; display: flex;  " >
			<el-pagination @size-change="handleSizeChange" @current-change="handleCurrentChange"
				:current-page="currentPage" :page-sizes="[5, 10, 20]" :page-size="pageSize"
				layout="total, sizes, prev, pager, next, jumper" :total="equipmentMsg.length">
			</el-pagination>
		</div>

	</div>
</template>
<script>
	export default {
		created() {
			let that = this
			this.$axios({
				method: 'post',
				url: 'http://localhost:8888/EquipmentMsg/showAllEquipment'
			}).then(function(response) {
				console.log(response)
				that.equipmentMsg = response.data
				console.log(that.equipmentMsg)
				that.equipmentMsgList=that.equipmentMsg.slice(0,that.pageSize);
			})
		},
		data() {
			return {
				equipmentMsgList:[],
				currentPage:1,
				pageSize:5,
				equipmentMsg: [],
				multipleSelection: []
			}
		},

		methods: {
			exportExcel: function() {
				let tables = document.querySelector("#outExcel") //根据id选取到要导出的表格
				let table_book = this.$XLSX.utils.table_to_book(tables)
				let table_write = this.$XLSX.write(table_book, {
					bookType: "xlsx",
					bookSST: true,
					type: "array"
				})
				try {
					this.$FileSaver.saveAs(new Blob([table_write], {
						type: "application/octet-stream"
					}), "emps.xlsx")
				} catch (e) {
					console.log(e, table_write)
				}
				return table_write
			},
			toggleSelection(rows) {
				if (rows) {
					rows.forEach(row => {
						this.$refs.multipleTable.toggleRowSelection(row);
					});
				} else {
					this.$refs.multipleTable.clearSelection();
				}
			},
			handleSelectionChange(val) {
				this.multipleSelection = val;
			},
			//每页条数切换
			handleSizeChange(pageSize) {
				this.pageSize = pageSize;
				this.handleCurrentChange(this.currentPage);
			},
			//页码切换
			handleCurrentChange(currentPage) {
				this.currentPage = currentPage;
				this.currentChangePage(this.equipmentMsg, currentPage);
			},
			//分页实现
			currentChangePage(list, currentPage) {
				let from = (currentPage - 1) * this.pageSize;
				let to = currentPage * this.pageSize;
				this.equipmentMsgList = this.equipmentMsg.slice(from, to);
			},
		}
	}
</script>
