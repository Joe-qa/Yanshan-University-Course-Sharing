package com.jz.xdkjoa.controllers.administration;

import com.jz.xdkjoa.pojo.administration.ContractForm;
import com.jz.xdkjoa.service.administration.ContractFormService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.beans.AppletInitializer;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
@CrossOrigin
@RestController
@RequestMapping("/contract")
public class ContractFormController {
    @Autowired(required = false)
    ContractFormService contractFormService;
    @PostMapping("/addcontract")
    public String addContract(@RequestBody  ContractForm contract){
        contractFormService.addContractBiz(contract);
        return "success";
    }
    @PostMapping("/delcontract")
    public String delContract(@RequestParam int contract_num){
        contractFormService.delContractBiz(contract_num);
        return "success";
    }
    @GetMapping("/findcontract")
    public  List<ContractForm> findContract ( String contractstate) {

        List<ContractForm> list= contractFormService.findContractBiz(contractstate);
        System.out.println(list);
        return list;

    }
    @PostMapping ("/showcontract")
    public List<ContractForm> showContract(){
        List<ContractForm> list =contractFormService.showContractBiz();
        return list;
    }
}
