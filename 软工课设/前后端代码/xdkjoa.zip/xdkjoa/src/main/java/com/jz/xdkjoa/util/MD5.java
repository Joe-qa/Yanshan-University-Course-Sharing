package com.jz.xdkjoa.util;

import java.net.ProxySelector;
import java.security.MessageDigest;

public class MD5 {
    public String MD5Encode(String origin) {
        String resultString = null;

        try {
            resultString = new String(origin);
            MessageDigest md = MessageDigest.getInstance("MD5");
            resultString = byteArrayToString(md.digest(resultString.getBytes()));
        } catch (Exception ex) {

        }
        return resultString;
    }
    public String byteArrayToString(byte[] b) {
        StringBuffer resultSb = new StringBuffer();
        for (int i = 0; i < b.length; i++) {
            resultSb.append(byteToHexString(b[i]));
        }
        return resultSb.toString();
    }

    public String byteToHexString(byte b) {
        int n = b;
        if (n < 0)
            n = 256 + n;
//            int d1 = n / 16;
//            int d2 = n % 16;
        return n%32+"";
    }

    public static void main(String[] args) {
        //111111

        MD5 md5=new MD5();
        String str=md5.MD5Encode("123456");
        System.out.println(str);
    }


}
