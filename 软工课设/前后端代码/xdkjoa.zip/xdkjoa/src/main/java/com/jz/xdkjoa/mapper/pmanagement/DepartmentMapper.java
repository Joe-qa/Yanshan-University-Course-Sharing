package com.jz.xdkjoa.mapper.pmanagement;

import com.jz.xdkjoa.pojo.pmanagement.Department;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface DepartmentMapper {
    String findNameByNum(Integer depart_num);
    List<Department> showAllDepartments();

}
