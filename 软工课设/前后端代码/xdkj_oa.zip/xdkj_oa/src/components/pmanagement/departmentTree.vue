<template>
	<div style="text-align: center;vertical-align: middle; margin-top: 120px;">
		<vue2-org-tree :data="data" :horizontal="true" :label-class-name="labelClassName" collapsable
			@on-expand="onExpand" @on-node-mouseover="onMouseover" @on-node-mouseout="onMouseout" />
		<div v-show="BasicSwich" class="floating">
			<p>ID:{{BasicInfo.id}}</p>
			<p>Name:{{BasicInfo.label}}</p>
			<p>Responsibilities:{{BasicInfo.responsibilities}}</p>
		</div>
		<el-button type="primary" style="position: fixed; top: 100px;left: 250px; margin: 20rpx;font-size: 20rpx;"
			@click="allexpand">全部展开</el-button>
		<el-button type="primary" style="position: fixed; top: 100px;left: 350px; margin: 20rpx;font-size: 20rpx;"
			@click="notexpand">全部折叠</el-button>
	</div>
</template>
<script>
	export default {
		data() {
			return {
				labelClassName: "bg-color-orange",
				BasicSwich: false,
				BasicInfo: {
					id: null,
					label: null,
					responsibilities: null
				},
				data: {
					id: 0,
					label: "小岛科技有限公司",
					responsibilities: "",
					children: [{
						id: 1,
						label: "总经理",
						responsibilities: "负责公司的各项活动和运营",
						children: [{
							id: 3,
							label: "人事总监",
							responsibilities: "统筹规划集团人力资源战略，制定适应公司发展的中长期人才战略规划及整体人力资源规划",
							},
							{
							id: 4,
							label: "行政总监",
							responsibilities: "管理行政事务",
							},
							{
							id: 5,
							label: "研发部总监",
							responsibilities: "负责制定集团研发技术发展的战略方针，并协助集团总裁完成研发计划和各项技术经济指标",
							},
							{
							id: 2,
							label: "副总经理",
							responsibilities: "协助总经理",
							children: [{
									id: 6,
									label: "营销总监",
									responsibilities: "市场变化分析、市场占有率调查、竞争环境分析"
								},
								{
									id: 7,
									label: "安保总监",
									responsibilities: "健全安全生产的规章制度和安全生产标准化的建设以及做好安全生产报表、计划、总结上报和公司安全台账工作"
								},
								{
									id: 8,
									label: "后勤总监",
									responsibilities: "管理公司的后勤事务"
								}
							]
						}]
					}]
				}
			}
		},
		created() {
			// let that = this
			// this.$axios({
			// 	method: 'get',
			// 	url: 'http://localhost:8888/job/findalljob'
			// }).then(function(response) {
			// 	// console.log(that.data.children.children)
			// 	// for (let o in response.data) {
			// 	// 	if (response.data[o].post_level == 3) {
			// 	// 		that.data.children.children.push({
			// 	// 			'id': response.data[o].post_num,
			// 	// 			'label': response.data[o].post_name,
			// 	// 			'responsibilities': response.data[o].responsibilities
			// 	// 		})
			// 	// 	}
			// 	// }
			// 	// console.log(response.data)


			// 	// // this.data.children.children.children.push({id:,})
			// 	// console.log(response.data[0].post_name)
			// })

		},
		methods: {
			collapse(list) {
				var _this = this;
				list.forEach(function(child) {
					if (child.expand) {
						child.expand = false;
					}
					child.children && _this.collapse(child.children);
				});
			},
			onExpand(e, data) {
				if ("expand" in data) {
					data.expand = !data.expand;
					if (!data.expand && data.children) {
						this.collapse(data.children);
					}
				} else {
					this.$set(data, "expand", true);
				}
			},
			toggleExpand(data, val) {
				var _this = this;
				if (Array.isArray(data)) {
					data.forEach(function(item) {
						_this.$set(item, "expand", val);
						if (item.children) {
							_this.toggleExpand(item.children, val);
						}
					});
				} else {
					this.$set(data, "expand", val);
					if (data.children) {
						_this.toggleExpand(data.children, val);
					}
				}
			},
			allexpand() {
				this.toggleExpand(this.data, true)
			},
			notexpand() {
				this.toggleExpand(this.data, false)
			},
			onMouseout(e, data) {
				this.BasicSwich = false
			},
			onMouseover(e, data) {
				this.BasicInfo = data;
				this.BasicSwich = true;
				var floating = document.getElementsByClassName('floating')[0];
				floating.style.left = e.clientX - 200 + 'px';
				floating.style.top = e.clientY - 150 + 'px';
			},
		}
	}
</script>
<style>
	.bg-color-orange {
		color: #ffffff;
		background-color: orange;
	}

	.floating {
		background: rgba(0, 0, 0, 0.7);
		width: 160px;
		height: 100px;
		position: absolute;
		color: #fff;
		padding-top: 15px;
		border-radius: 15px;
		padding-left: 15px;
		box-sizing: border-box;
		left: 0;
		top: 0;
		transition: all 0.3s;
		z-index: 999;
		text-align: left;
		font-size: 12px;
	}
</style>
