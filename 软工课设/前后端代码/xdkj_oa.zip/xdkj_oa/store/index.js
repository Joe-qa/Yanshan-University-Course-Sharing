import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
	//全局state对象，用于存储所有组件的公共对象
  state:localStorage.getItem('state')?JSON.parse(localStorage.getItem('state')) : {
	  account:''
  },
  getters:{
	  getUser(state){
		  return state.account;
		  
	  }
  },
  mutations: {
	  updateUser(state,account){
		  state.account=account;
	  }
  },
  actions: {
	  asyncUpdateUser(context,account){
		  context.commit("updateUser",account);
		  
	  }
  },
  modules: {
  }
})
