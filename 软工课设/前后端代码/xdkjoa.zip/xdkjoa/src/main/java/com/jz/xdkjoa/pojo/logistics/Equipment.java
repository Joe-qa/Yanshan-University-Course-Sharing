package com.jz.xdkjoa.pojo.logistics;

public class Equipment {
    private int equipment_num;
    private String use_situation;
    private String equipment_situation;
    private String equipment_name;
    private int equipment_life;

    public Equipment() {
    }

    public Equipment(int equipment_num, String use_situation, String equipment_situation, String equipment_name, int equipment_life) {
        this.equipment_num = equipment_num;
        this.use_situation = use_situation;
        this.equipment_situation = equipment_situation;
        this.equipment_name = equipment_name;
        this.equipment_life = equipment_life;
    }

    @Override
    public String toString() {
        return "Equipment{" +
                "equipment_num=" + equipment_num +
                ", use_situation='" + use_situation + '\'' +
                ", equipment_situation=" + equipment_situation +
                ", equipment_name='" + equipment_name + '\'' +
                ", equipment_life=" + equipment_life +
                '}';
    }

    public int getEquipment_num() {
        return equipment_num;
    }

    public void setEquipment_num(int equipment_num) {
        this.equipment_num = equipment_num;
    }

    public String getUse_situation() {
        return use_situation;
    }

    public void setUse_situation(String use_situation) {
        this.use_situation = use_situation;
    }

    public String getEquipment_situation() {
        return equipment_situation;
    }

    public void setEquipment_situation(String equipment_situation) {
        this.equipment_situation = equipment_situation;
    }

    public String getEquipment_name() {
        return equipment_name;
    }

    public void setEquipment_name(String equipment_name) {
        this.equipment_name = equipment_name;
    }

    public int getEquipment_life() {
        return equipment_life;
    }

    public void setEquipment_life(int equipment_life) {
        this.equipment_life = equipment_life;
    }
}
