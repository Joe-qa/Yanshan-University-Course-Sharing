package com.jz.xdkjoa.controllers.pmanagement;

import com.jz.xdkjoa.pojo.pmanagement.Job;
import com.jz.xdkjoa.service.pmanagement.JobService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/job")
public class JobController {

    @Autowired
    JobService jobService;

    @PostMapping("/addjob")
    public String addJob(@RequestBody Job job)
    {
        job.toString();
        jobService.addJobBiz(job);
        return "ok";
    }

    @PostMapping("/showjob")
    public Job showJobByName(@RequestParam  String post_name)
    {
        Job job=jobService.showJobByNameBiz(post_name);
        return job;
    }

    @PostMapping("/showalljob")
    public List<Job> showJob()
    {
        List<Job> list=jobService.showJobBiz();
        return list;
    }

    @GetMapping("/deljob")
    public String delJob(@RequestParam  Integer post_num)
    {
        jobService.delJobBiz(post_num);
        return "ok";
    }

    @PostMapping("/updatejob")
    public String updateJob(@RequestBody Job job)
    {
        jobService.updateJobBiz(job);
        return "ok";
    }
}
