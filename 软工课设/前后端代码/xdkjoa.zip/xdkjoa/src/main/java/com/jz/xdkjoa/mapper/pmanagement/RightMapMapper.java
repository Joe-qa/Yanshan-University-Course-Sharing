package com.jz.xdkjoa.mapper.pmanagement;

import com.jz.xdkjoa.pojo.pmanagement.RightMap;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
@Mapper
public interface RightMapMapper {
    List<RightMap> findRight(String account);
}
