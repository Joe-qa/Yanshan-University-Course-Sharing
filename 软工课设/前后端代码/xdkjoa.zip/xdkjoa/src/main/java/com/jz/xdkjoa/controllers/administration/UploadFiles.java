package com.jz.xdkjoa.controllers.administration;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.Random;

@CrossOrigin
@RestController
@RequestMapping("/upload")
public class UploadFiles {
    @PostMapping("save")
    public String upload(MultipartFile file, HttpServletRequest req)
    {

        String realPath=req.getServletContext().getRealPath("/upload");
        try{
            File path = new File(realPath);
            if(!path.exists())
                path.mkdir();//新建目录
            String str=new Date().getTime()+""+new Random().nextInt();
            String originName=file.getOriginalFilename();
            String ext=originName.substring(originName.lastIndexOf("."));
            String newName=str+ext;
            System.out.println(realPath+"/"+newName);
            file.transferTo(new File(realPath,newName));
            return newName;
        }catch (IOException e){
            e.printStackTrace();
            return "上传失败";
        }
    }
}
