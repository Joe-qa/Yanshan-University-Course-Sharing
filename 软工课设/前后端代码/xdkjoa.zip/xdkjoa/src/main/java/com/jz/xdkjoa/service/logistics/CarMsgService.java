package com.jz.xdkjoa.service.logistics;

import com.jz.xdkjoa.pojo.logistics.CarMsg;

import java.util.List;

public interface CarMsgService {
    List<CarMsg> getCarMsgsBiz();
    List<CarMsg> showByStateBiz(String situation);
    List<CarMsg> showByCarNumBiz(String car_num);
    void addCarBiz(CarMsg carmsg);
    void updateCarStateBiz(String car_num);
}
